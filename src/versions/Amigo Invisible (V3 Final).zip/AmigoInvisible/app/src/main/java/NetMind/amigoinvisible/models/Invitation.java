package NetMind.amigoinvisible.models;

import java.util.Map;
/**
 * Modelo que representa una invitación pendiente para unirse a un grupo.
 * Contiene el ID del grupo, su nombre y los datos del miembro invitado (nombre, email, etc.).
 */
public class Invitation {
    private String groupId;
    private String groupName;
    private Map<String, Object> datosMiembro;
    /**
     * Constructor requerido por Firestore para deserialización automática.
     */
    public Invitation() {}

    /**
     * Constructor principal para crear una invitación.
     *
     * @param groupId       ID único del grupo.
     * @param groupName     Nombre legible del grupo.
     * @param datosMiembro  Mapa con datos asociados al miembro (nombre, email...).
     */
    public Invitation(String groupId, String groupName, Map<String, Object> datosMiembro) {
        this.groupId = groupId;
        this.groupName = groupName;
        this.datosMiembro = datosMiembro;
    }

    // Getters
    public String getGroupId() {
        return groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public Map<String, Object> getDatosMiembro() {
        return datosMiembro;
    }
}

