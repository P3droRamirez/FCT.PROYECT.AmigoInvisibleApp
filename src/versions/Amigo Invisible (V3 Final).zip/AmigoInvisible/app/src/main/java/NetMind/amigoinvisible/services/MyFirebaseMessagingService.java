package NetMind.amigoinvisible.services;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.activities.GroupDetailActivity;

/**
 * Servicio personalizado para manejar los mensajes push recibidos por Firebase Cloud Messaging (FCM).
 * Muestra notificaciones al usuario incluso cuando la aplicación está en primer plano.
 */
public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "FCMService";

    /**
     * Se ejecuta cuando se recibe un mensaje FCM.
     *
     * @param remoteMessage Objeto con los datos del mensaje recibido.
     */
    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        String title = remoteMessage.getData().get("title");
        String body = remoteMessage.getData().get("body");
        String groupId = remoteMessage.getData().get("groupId");

        if (title != null && body != null && groupId != null) {
            mostrarNotificacion(title, body, groupId);
        }
    }

    /**
     * Se ejecuta cuando se genera un nuevo token FCM.
     * Este token debe actualizarse en la base de datos de Firestore.
     *
     * @param token El nuevo token generado por FCM.
     */
    @Override
    public void onNewToken(@NonNull String token) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            FirebaseFirestore.getInstance().collection("users").document(user.getUid()).update("fcmToken", token);
        }
    }

    /**
     * Crea y muestra una notificación personalizada con los datos recibidos.
     *
     * @param titulo  Título de la notificación.
     * @param mensaje Cuerpo del mensaje.
     * @param groupId ID del grupo para abrir al tocarla.
     */
    @SuppressLint("MissingPermission")
    private void mostrarNotificacion(String titulo, String mensaje, String groupId) {
        // Crear canal para Android 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel canal = new NotificationChannel("default_channel", "Notificaciones generales", NotificationManager.IMPORTANCE_DEFAULT);
            canal.setDescription("Canal para notificaciones generales");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(canal);
        }

        // Intent para abrir el grupo al tocar la notificación
        Intent intent = new Intent(this, GroupDetailActivity.class);
        intent.putExtra("groupId", groupId);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Crear notificación
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default_channel").setSmallIcon(R.drawable.ic_notification).setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.logo_notificacion)) // Recurso en drawable
                .setContentTitle(titulo).setContentText(mensaje).setContentIntent(pendingIntent).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManagerCompat.from(this).notify(1, builder.build());
    }
}
