package NetMind.amigoinvisible.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.List;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.models.WishlistItem;

/**
 * Adaptador para la visualización y gestión de la lista de deseos del usuario
 * dentro de un grupo en un RecyclerView.
 * Cada elemento de la lista puede ser pulsado para abrir una búsqueda en Amazon
 * relacionada con ese deseo. Además, incluye un botón para eliminar el ítem tanto
 * visualmente como en la base de datos de Firestore
 */
public class WishlistAdapter extends RecyclerView.Adapter<WishlistAdapter.ViewHolder> {

    private final List<WishlistItem> deseos;
    private final Context context;
    private final String groupId;
    private final FirebaseFirestore db = FirebaseFirestore.getInstance();

    /**
     * Constructor del adaptador.
     *
     * @param deseos   Lista de deseos actual del usuario.
     * @param context  Contexto de la actividad o fragmento.
     * @param groupId  ID del grupo donde pertenece el usuario.
     */
    public WishlistAdapter(List<WishlistItem> deseos, Context context, String groupId) {
        this.deseos = deseos;
        this.context = context;
        this.groupId = groupId;
    }
    /**
     * Crea y retorna un nuevo ViewHolder inflado desde el XML.
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_wishlist, parent, false);
        return new ViewHolder(vista);
    }
    /**
     * Asocia cada deseo al ViewHolder, con acciones para búsqueda y eliminación.
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WishlistItem item = deseos.get(position);
        holder.textView.setText(item.getTitle());

        // Acciones al hacer clic sobre el texto
        holder.textView.setOnClickListener(v -> {
            if (item.getUrl() != null && !item.getUrl().trim().isEmpty()) {
                // Abrir enlace directo si hay URL
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(item.getUrl()));
                context.startActivity(i);
            } else {
                // Búsqueda en Amazon si no hay URL
                String query = Uri.encode(item.getTitle() + " Amazon");
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.amazon.es/s?k=" + query));
                context.startActivity(intent);
            }
        });

        // Eliminar ítem
        holder.deleteIcon.setOnClickListener(v -> {
            deseos.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, deseos.size());

            db.collection("groups").document(groupId)
                    .update("wishlist", deseos)
                    .addOnFailureListener(e ->
                            Toast.makeText(context, R.string.mensaje_error_deseo, Toast.LENGTH_SHORT).show()
                    );
        });
    }

    /**
     * Devuelve la cantidad actual de deseos en la lista.
     */
    @Override
    public int getItemCount() {
        return deseos.size();
    }

    /**
     * ViewHolder que representa cada ítem de la lista de deseos.
     */
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        ImageView deleteIcon;

        ViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textWishItem);
            deleteIcon = itemView.findViewById(R.id.btnDeleteWish);
        }
    }
}
