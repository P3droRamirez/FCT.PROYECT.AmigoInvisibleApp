package NetMind.amigoinvisible.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.models.Message;

/**
 * Adaptador personalizado  que gestiona la visualización
 * de mensajes en una interfaz de tipo chat. Se adapta según si el mensaje fue enviado
 * o recibido por el usuario actual.
 */
public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TIPO_ENVIADO = 1;
    private static final int TIPO_RECIBIDO = 2;

    private final List<Message> listaMensajes;
    private final String idUsuarioActual;

    /**
     * Constructor del adaptador.
     *
     * @param listaMensajes Lista de mensajes a mostrar.
     */
    public MessageAdapter(List<Message> listaMensajes) {
        this.listaMensajes = listaMensajes;
        this.idUsuarioActual = FirebaseAuth.getInstance().getCurrentUser().getUid();
    }

    /**
     * Determina si el mensaje debe mostrarse como enviado o recibido.
     *
     * @param posicion Índice del mensaje en la lista.
     * @return Tipo de vista (enviado o recibido).
     */
    @Override
    public int getItemViewType(int posicion) {
        Message mensaje = listaMensajes.get(posicion);
        return mensaje.getSenderId().equals(idUsuarioActual) ? TIPO_ENVIADO : TIPO_RECIBIDO;
    }

    /**
     * Infla la vista del mensaje según su tipo.
     *
     * @param padre     ViewGroup padre del RecyclerView.
     * @param tipoVista Tipo de mensaje (enviado o recibido).
     * @return ViewHolder correspondiente al tipo de mensaje.
     */
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup padre, int tipoVista) {
        View vista;
        if (tipoVista == TIPO_ENVIADO) {
            vista = LayoutInflater.from(padre.getContext()).inflate(R.layout.item_mensaje_enviado, padre, false);
            return new ViewHolderMensajeEnviado(vista);
        } else {
            vista = LayoutInflater.from(padre.getContext()).inflate(R.layout.item_mensaje_recibido, padre, false);
            return new ViewHolderMensajeRecibido(vista);
        }
    }

    /**
     * Asocia el texto del mensaje con el TextView correspondiente.
     *
     * @param holder    ViewHolder correspondiente (enviado o recibido).
     * @param posicion  Posición del mensaje en la lista.
     */
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int posicion) {
        Message mensaje = listaMensajes.get(posicion);
        if (holder instanceof ViewHolderMensajeEnviado) {
            ((ViewHolderMensajeEnviado) holder).textoMensaje.setText(mensaje.getContent());
        } else if (holder instanceof ViewHolderMensajeRecibido) {
            ((ViewHolderMensajeRecibido) holder).textoMensaje.setText(mensaje.getContent());
        }
    }

    /**
     * Devuelve la cantidad total de mensajes en la lista.
     *
     * @return Número total de ítems.
     */
    @Override
    public int getItemCount() {
        return listaMensajes.size();
    }

    /**
     * ViewHolder para mensajes enviados por el usuario.
     */
    public static class ViewHolderMensajeEnviado extends RecyclerView.ViewHolder {
        TextView textoMensaje;

        public ViewHolderMensajeEnviado(@NonNull View itemView) {
            super(itemView);
            textoMensaje = itemView.findViewById(R.id.messageText);
        }
    }

    /**
     * ViewHolder para mensajes recibidos de otros usuarios.
     */
    public static class ViewHolderMensajeRecibido extends RecyclerView.ViewHolder {
        TextView textoMensaje;

        public ViewHolderMensajeRecibido(@NonNull View itemView) {
            super(itemView);
            textoMensaje = itemView.findViewById(R.id.messageText);
        }
    }
}
