package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.ArrayList;
import java.util.List;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.InvitationsAdapter;
import NetMind.amigoinvisible.models.Invitation;
import NetMind.amigoinvisible.utils.InvitationUtils;

/**
 * Fragmento que muestra las invitaciones pendientes del usuario a diferentes grupos.
 * Permite aceptar o rechazar dichas invitaciones.
 */
public class InvitationsFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView emptyMessage;
    private InvitationsAdapter adapter;
    private final List<Invitation> listaInvitaciones = new ArrayList<>();
    private ListenerRegistration listener;

    public InvitationsFragment() {}

    /**
     * Infla el layout XML del fragmento
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_invitations, container, false);
    }

    /**
     * Se llama tras crearse la vista del fragmento. Configura RecyclerView y lanza la escucha.
     *
     * @param view Vista ya inflada.
     * @param savedInstanceState Estado previo guardado, si existe.
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recycler_invitations);
        emptyMessage = view.findViewById(R.id.empty_message);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Se establece el adaptador, que recibirá las funciones para aceptar y rechazar
        adapter = new InvitationsAdapter(listaInvitaciones, this::aceptarInvitacion, this::rechazarInvitacion);
        recyclerView.setAdapter(adapter);

        escucharInvitaciones();
    }

    /**
     * Escucha en tiempo real las invitaciones del usuario autenticado mediante InvitationUtils.
     * Actualiza la lista y muestra el mensaje si está vacía.
     */
    private void escucharInvitaciones() {
        FirebaseUser usuario = FirebaseAuth.getInstance().getCurrentUser();
        if (usuario == null || usuario.getEmail() == null) return;

        // Delegamos la lógica a InvitationUtils
        listener = InvitationUtils.escucharInvitaciones(
                usuario.getEmail(),
                invitaciones -> {
                    listaInvitaciones.clear();
                    listaInvitaciones.addAll(invitaciones);
                    adapter.notifyDataSetChanged();
                    actualizarMensajeVacio();
                }
        );
    }

    /**
     * Acepta una invitación seleccionada, añade al usuario al grupo correspondiente
     * y actualiza la vista redirigiendo al fragmento de grupos.
     *
     * @param invitacion Invitación a aceptar.
     */
    private void aceptarInvitacion(Invitation invitacion) {
        FirebaseUser usuario = FirebaseAuth.getInstance().getCurrentUser();
        if (usuario == null) return;

        InvitationUtils.aceptarInvitacion(
                invitacion,
                usuario,
                () -> {
                    Toast.makeText(getContext(), R.string.msg_aceptada_ok, Toast.LENGTH_SHORT).show();
                    listaInvitaciones.remove(invitacion);
                    adapter.notifyDataSetChanged();
                    actualizarMensajeVacio();

                    // Redirige a la vista de grupos tras aceptar
                    requireActivity().getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.fragment_container, new ViewGroupsFragment())
                            .commit();
                },
                error -> Toast.makeText(getContext(), error, Toast.LENGTH_SHORT).show()
        );
    }

    /**
     * Rechaza una invitación, eliminando el documento en Firestore.
     *
     * @param invitacion Invitación a rechazar.
     */
    private void rechazarInvitacion(Invitation invitacion) {
        FirebaseUser usuario = FirebaseAuth.getInstance().getCurrentUser();
        if (usuario == null || usuario.getEmail() == null) return;

        InvitationUtils.rechazarInvitacion(
                invitacion,
                usuario.getEmail(),
                () -> {
                    Toast.makeText(getContext(), R.string.msg_invitacion_rechazada, Toast.LENGTH_SHORT).show();
                    listaInvitaciones.remove(invitacion);
                    adapter.notifyDataSetChanged();
                    actualizarMensajeVacio();
                },
                error -> Toast.makeText(getContext(), error, Toast.LENGTH_SHORT).show()
        );
    }
    /**
     * Muestra u oculta el mensaje de "no invitaciones" dependiendo del estado de la lista.
     */
    private void actualizarMensajeVacio() {
        emptyMessage.setVisibility(listaInvitaciones.isEmpty() ? View.VISIBLE : View.GONE);
    }
    /**
     * Detiene el listener activo cuando la vista se destruye para evitar fugas de memoria.
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (listener != null) listener.remove();
    }
}
