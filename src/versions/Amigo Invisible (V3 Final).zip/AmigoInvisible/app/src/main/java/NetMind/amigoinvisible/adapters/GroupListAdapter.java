package NetMind.amigoinvisible.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.activities.GroupDetailActivity;
import NetMind.amigoinvisible.models.Group;

/**
 * Adaptador personalizado para mostrar una lista de grupos en un RecyclerView.
 * Cada grupo se muestra como una tarjeta con nombre, presupuesto e imagen.
 */
public class GroupListAdapter extends RecyclerView.Adapter<GroupListAdapter.GroupViewHolder> {

    private List<Group> listaGrupos;

    /**
     * Constructor
     *
     * @param listaGrupos Lista de grupos a mostrar
     */
    public GroupListAdapter(List<Group> listaGrupos) {
        this.listaGrupos = listaGrupos;
    }

    /**
     * Infla la vista de cada tarjeta del grupo
     */
    @NonNull
    @Override
    public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_group_card, parent, false);
        return new GroupViewHolder(vista);
    }

    /**
     * Asocia los datos del grupo a cada vista del item.
     */
    @Override
    public void onBindViewHolder(@NonNull GroupViewHolder holder, int position) {
        Group grupo = listaGrupos.get(position);

        holder.nombreGrupo.setText(grupo.getName());

        String presupuestoTexto = holder.itemView.getContext().getString(
                R.string.texto_presupuesto_grupo, grupo.getBudgetLimit()
        );
        holder.presupuestoGrupo.setText(presupuestoTexto);

        // Cargar imagen del grupo con Glide o imagen por defecto
        if (grupo.getImageUrl() != null && !grupo.getImageUrl().isEmpty()) {
            Glide.with(holder.itemView.getContext())
                    .load(grupo.getImageUrl())
                    .placeholder(R.drawable.ic_groups)
                    .into(holder.imagenGrupo);
        } else {
            holder.imagenGrupo.setImageResource(R.drawable.ic_groups);
        }

        // Al hacer clic en la tarjeta, abrir el detalle del grupo
        holder.itemView.setOnClickListener(v -> {
            Context contexto = v.getContext();
            Intent intent = new Intent(contexto, GroupDetailActivity.class);
            intent.putExtra("groupId", grupo.getId());
            contexto.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return listaGrupos.size();
    }

    /**
     * ViewHolder que contiene las vistas de cada tarjeta
     */
    public static class GroupViewHolder extends RecyclerView.ViewHolder {
        TextView nombreGrupo, presupuestoGrupo;
        ImageView imagenGrupo;

        public GroupViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreGrupo = itemView.findViewById(R.id.txtGroupName);
            presupuestoGrupo = itemView.findViewById(R.id.txtGroupBudget);
            imagenGrupo = itemView.findViewById(R.id.imageGroupCard);
        }
    }
}
