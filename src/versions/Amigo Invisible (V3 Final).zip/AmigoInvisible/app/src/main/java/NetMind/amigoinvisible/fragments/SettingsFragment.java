package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.widget.Toast;
import androidx.preference.EditTextPreference;
import androidx.preference.PreferenceFragmentCompat;
import NetMind.amigoinvisible.R;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.preference.ListPreference;
import androidx.preference.SwitchPreferenceCompat;

/**
 * Fragmento de configuración de usuario.
 * Permite modificar preferencias como el nombre, tema visual, notificaciones y otras opciones de interfaz.
 */
public class SettingsFragment extends PreferenceFragmentCompat {

    /**
     * Carga las preferencias definidas en XML y configura los listeners de cambio.
     *
     * @param savedInstanceState Estado previo de la instancia, si existe.
     * @param rootKey            Clave raíz para la jerarquía de preferencias (normalmente null).
     */
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        // Carga las preferencias desde el archivo XML
        setPreferencesFromResource(R.xml.settings, rootKey);

        // Preferencia: nombre de usuario editable
        EditTextPreference preferenciaNombreUsuario = findPreference("username");

        if (preferenciaNombreUsuario != null) {
            preferenciaNombreUsuario.setOnPreferenceChangeListener((preference, nuevoValor) -> {
                String nuevoNombre = nuevoValor.toString();
                String mensaje = getString(R.string.nombre_usuario_actualizado, nuevoNombre);
                Toast.makeText(getContext(), mensaje, Toast.LENGTH_SHORT).show();
                return true; // Guarda el nuevo valor
            });
        }

        // Preferencia: selector de tema (claro, oscuro, sistema)
        ListPreference tema = findPreference("color_theme");

        if (tema != null) {
            tema.setOnPreferenceChangeListener((preference, newValue) -> {
                String valor = (String) newValue;
                switch (valor) {
                    case "light":
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                        break;
                    case "dark":
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                        break;
                    case "system":
                    default:
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                        break;
                }
                return true; // Guarda la preferencia
            });
        }

        // Preferencia: notificaciones activadas/desactivadas
        SwitchPreferenceCompat notificaciones = findPreference("notifications_enabled");
        if (notificaciones != null) {
            notificaciones.setOnPreferenceChangeListener((preference, newValue) -> {
                boolean activadas = (boolean) newValue;
                Toast.makeText(getContext(),
                        activadas ? getString(R.string.notificaciones_activadas) : getString(R.string.notificaciones_desactivadas),
                        Toast.LENGTH_SHORT).show();

                // Aquí puedes cancelar o programar notificaciones según estado
                return true;
            });
        }
    }
}
