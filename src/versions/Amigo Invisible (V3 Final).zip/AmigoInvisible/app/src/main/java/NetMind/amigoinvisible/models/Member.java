package NetMind.amigoinvisible.models;

import java.util.List;
import java.util.Map;

/**
 * Modelo que representa un miembro dentro de un grupo.
 * Contiene su nombre, email y la lista de deseos personalizada.
 */
public class Member {
    private String id;
    private String name;
    private String email;
    private List<Map<String, Object>> wishlist;
    private List<String> excludedUserIds;

    /**
     * Constructor requerido por Firestore para deserialización automática.
     */
    public Member() {}

    public Member(String id, String name, String email, List<String> excludedUserIds) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.excludedUserIds = excludedUserIds;
    }
    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public List<Map<String, Object>> getWishlist() { return wishlist; }
    public List<String> getExcludedUserIds() { return excludedUserIds; }
}
