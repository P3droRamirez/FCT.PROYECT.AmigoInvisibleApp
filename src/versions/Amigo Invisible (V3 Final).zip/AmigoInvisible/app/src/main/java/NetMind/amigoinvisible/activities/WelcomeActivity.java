package NetMind.amigoinvisible.activities;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.fragments.CreateGroupFragment;
import NetMind.amigoinvisible.fragments.InvitationsFragment;
import NetMind.amigoinvisible.fragments.SettingsFragment;
import NetMind.amigoinvisible.fragments.ViewGroupsFragment;
import NetMind.amigoinvisible.services.TokenManager;
import NetMind.amigoinvisible.utils.FirebaseUtils;
import NetMind.amigoinvisible.utils.UsuarioUtils;

/**
 * Actividad principal tras el login.
 * Muestra la navegación lateral (Drawer) y permite gestionar grupos, ajustes, invitaciones,
 * así como actualizar la imagen de perfil del usuario.
 */
public class WelcomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private FirebaseAuth authFirebase;
    private FirebaseUser usuarioActual;
    private FirebaseFirestore baseDatos;
    private StorageReference referenciaAlmacenamiento;
    private TextView textoBienvenida;
    private ImageView imagenPerfil;

    private ActivityResultLauncher<String> selectorImagen;

    /**
     * Inicializa la actividad y carga la vista por defecto (mis grupos),
     * junto con el token FCM para recibir notificaciones push.
     *
     * @param savedInstanceState estado previo si la actividad fue recreada.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        inicializarFirebase();
        configurarToolbar();
        configurarDrawer();
        configurarSelectorImagen();

        // Solo cargamos fragmento si aún no está restaurado
        if (savedInstanceState == null) {
            // Empareja usuario con sus posibles invitaciones y carga el fragmento inicial
            new android.os.Handler().postDelayed(() -> {
                usuarioActual = FirebaseAuth.getInstance().getCurrentUser();
                if (usuarioActual != null) {
                    FirebaseUtils.emparejarUsuarioConGrupos(usuarioActual, () -> {
                        runOnUiThread(() -> {
                            cargarFragmento(new ViewGroupsFragment());
                        });
                    });
                }
            }, 500);
        }
        TokenManager.actualizarTokenFCM();
    }


    /**
     *  * Inicializa las herramientas de Firebase que vamos a usar:
     *  * - Autenticación (para saber qué usuario está conectado)
     *  * - Firestore (para acceder a la base de datos)
     *  * - Storage (para guardar imágenes de perfil)
     */
    private void inicializarFirebase() {
        authFirebase = FirebaseAuth.getInstance();
        usuarioActual = authFirebase.getCurrentUser();
        baseDatos = FirebaseFirestore.getInstance();
        referenciaAlmacenamiento = FirebaseStorage.getInstance().getReference("profile_pictures");
    }

    /**
     * Configura la Toolbar y el botón de apertura del Drawer
     */
    private void configurarToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
    }

    /**
     * Configura el menú lateral (Drawer) y muestra los datos del usuario autenticado:
     * nombre, correo e imagen de perfil.
     */
    private void configurarDrawer() {
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Muestra la información del usuario logueado
        View headerView = navigationView.getHeaderView(0);
        textoBienvenida = headerView.findViewById(R.id.nav_header_name);
        TextView textoCorreo = headerView.findViewById(R.id.nav_header_email);
        imagenPerfil = headerView.findViewById(R.id.profile_image);

        imagenPerfil.setOnClickListener(v -> {
            Toast.makeText(this, R.string.mensaje_seleccionar_imagen, Toast.LENGTH_SHORT).show();
            selectorImagen.launch("image/*");
        });
        // Rellena con los datos del usuario actual
        if (usuarioActual != null) {
            String nombre = usuarioActual.getDisplayName() != null ? usuarioActual.getDisplayName() : getString(R.string.usuario_generico);
            textoBienvenida.setText(getString(R.string.bienvenido_usuario, nombre));
            textoCorreo.setText(usuarioActual.getEmail());

            if (usuarioActual.getPhotoUrl() != null) {
                Glide.with(getApplicationContext()).load(usuarioActual.getPhotoUrl()).circleCrop().into(imagenPerfil);
            }
        }
    }

    /**
     * Configura el selector de imagen para actualizar la foto de perfil del usuario.
     * Utiliza {@link UsuarioUtils#actualizarFotoPerfil}.
     */
    private void configurarSelectorImagen() {
        selectorImagen = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (usuarioActual != null && uri != null) {
                        UsuarioUtils.actualizarFotoPerfil(usuarioActual, uri, this, imagenPerfil);
                    }
                }
        );
    }

    /**
     * Al volver a la actividad (por ejemplo, después de ajustes), recarga el fragmento si era necesario.
     */
    @Override
    protected void onResume() {
        super.onResume();
        Fragment actual = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        if (actual instanceof ViewGroupsFragment) {
            getSupportFragmentManager().beginTransaction().remove(actual).commitNow();
            cargarFragmento(new ViewGroupsFragment());
        }
    }

    /**
     * Carga un fragmento en el contenedor principal.
     *
     * @param fragmento Fragmento a mostrar.
     */
    private void cargarFragmento(Fragment fragmento) {
        FragmentTransaction transaccion = getSupportFragmentManager().beginTransaction();
        transaccion.replace(R.id.fragment_container, fragmento);
        transaccion.commit();
    }

    /**
     * Maneja la selección de ítems en el menú lateral (Drawer).
     *
     * @param item Elemento del menú seleccionado.
     * @return true si el evento ha sido manejado.
     */
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_my_groups) {
            cargarFragmento(new ViewGroupsFragment());
        } else if (id == R.id.nav_create_group) {
            cargarFragmento(new CreateGroupFragment());
        } else if (id == R.id.nav_settings) {
            cargarFragmento(new SettingsFragment());
        } else if (id == R.id.nav_logout) {
            mostrarDialogoCerrarSesion();
        } else if (id == R.id.nav_invitations) {
            cargarFragmento(new InvitationsFragment());
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    /**
     * Muestra un diálogo para confirmar el cierre de sesión del usuario.
     * Si acepta, cierra sesión y vuelve al login.
     */
    private void mostrarDialogoCerrarSesion() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.txt_titulo_cerrar_sesion)
                .setMessage(R.string.txt_mensaje_cerrar_sesion)
                .setPositiveButton(R.string.txt_mensajePositivo, (dialog, which) -> {
                    authFirebase.signOut();
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                })
                .setNegativeButton(R.string.txt_mensajeNegativo, null)
                .show();
    }
}