package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.*;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.WishlistAdapter;
import NetMind.amigoinvisible.models.WishlistItem;

/**
 * Actividad que permite a un usuario gestionar su lista de deseos dentro de un grupo específico.
 * Utiliza un campo de autocompletado y una lista dinámica conectada a Firestore.
 */
public class WishlistActivity extends AppCompatActivity {

    private AutoCompleteTextView campoDeseo;
    private Button botonAgregar;
    private RecyclerView recyclerView;
    private WishlistAdapter adapter;

    private final List<WishlistItem> deseos = new ArrayList<>();
    private EditText campoUrl;

    private FirebaseFirestore db;
    private String idGrupo;
    private String userId;

    /**
     * Metodo principal de la actividad. Carga los componentes visuales,
     * configura la lógica de interacción y sincroniza con Firestore.
     *
     * @param savedInstanceState Estado anterior si se ha restaurado.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);
        // Validación básica del intent
        idGrupo = getIntent().getStringExtra("groupId");
        if (idGrupo == null || idGrupo.isEmpty()) {
            Toast.makeText(this, R.string.error_id_grupo_invalido, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        // Inicialización de Firebase y usuario
        db = FirebaseFirestore.getInstance();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        // Asignación de vistas
        campoDeseo = findViewById(R.id.inputWishItem);
        botonAgregar = findViewById(R.id.btnAddWish);
        recyclerView = findViewById(R.id.wishlistRecyclerView);
        campoUrl = findViewById(R.id.inputWishUrl);
        // Configuración inicial
        configurarAutoCompletado();
        configurarRecyclerView();
        cargarListaDesdeFirestore();
        // Acción del botón
        botonAgregar.setOnClickListener(v -> agregarDeseo());
    }

    /**
     * Configura el campo de entrada con sugerencias cargadas desde recursos (strings.xml).
     * El umbral para mostrar sugerencias es 1 caracter.
     */
    private void configurarAutoCompletado() {
        String[] sugerencias = getResources().getStringArray(R.array.wishlist_suggestions);
        ArrayAdapter<String> adaptador = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, sugerencias);
        campoDeseo.setAdapter(adaptador);
        campoDeseo.setThreshold(1);
    }
    /**
     * Configura el RecyclerView y su adaptador personalizado para mostrar los deseos del usuario.
     */
    private void configurarRecyclerView() {
        adapter = new WishlistAdapter(deseos, this, idGrupo);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
    /**
     * Valida el deseo ingresado por el usuario y, si es válido, lo añade a la lista local y lo sincroniza con Firestore.
     * También actualiza la interfaz visual y borra el campo de entrada.
     */
    private void agregarDeseo() {
        String texto = campoDeseo.getText().toString().trim();
        String url = ((EditText) findViewById(R.id.inputWishUrl)).getText().toString().trim();

        if (TextUtils.isEmpty(texto)) {
            Toast.makeText(this, R.string.mensaje_deseo_vacio, Toast.LENGTH_SHORT).show();
            return;
        }

        WishlistItem nuevo = new WishlistItem(texto, url.isEmpty() ? null : url);
        deseos.add(nuevo);
        campoDeseo.setText("");
        ((EditText) findViewById(R.id.inputWishUrl)).setText("");
        adapter.notifyDataSetChanged();
        guardarListaEnFirestore();
        Toast.makeText(this, R.string.mensaje_deseo_añadido, Toast.LENGTH_SHORT).show();
    }



    /**
     * Guarda la lista de deseos actualizada del usuario en Firestore bajo su documento en la colección de miembros del grupo.
     * Si ocurre un error, se notifica con un Toast.
     */
    private void guardarListaEnFirestore() {
        List<Map<String, Object>> listaParaFirestore = new ArrayList<>();
        for (WishlistItem item : deseos) {
            listaParaFirestore.add(item.toMap());
        }

        db.collection("groups")
                .document(idGrupo)
                .collection("members")
                .document(userId)
                .update("wishlist", listaParaFirestore)
                .addOnFailureListener(e ->
                        Toast.makeText(this, R.string.mensaje_error_deseo, Toast.LENGTH_SHORT).show());
    }


    /**
     * Recupera la lista de deseos previamente almacenada en Firestore.
     * Si existe, se carga en la lista local y se actualiza el adaptador.
     */
    private void cargarListaDesdeFirestore() {
        db.collection("groups")
                .document(idGrupo)
                .collection("members")
                .document(userId)
                .get()
                .addOnSuccessListener(document -> {
                    deseos.clear();
                    if (document.contains("wishlist")) {
                        List<Map<String, Object>> datos = (List<Map<String, Object>>) document.get("wishlist");
                        for (Map<String, Object> entry : datos) {
                            String title = (String) entry.get("title");
                            String url = (String) entry.get("url");
                            deseos.add(new WishlistItem(title, url));
                        }
                    }
                    adapter.notifyDataSetChanged();
                });
    }

}
