package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.utils.UsuarioUtils;

/**
 * Actividad que gestiona el proceso de registro de un nuevo usuario.
 * Permite ingresar nombre, correo electrónico y contraseña, realizando validaciones
 * antes de enviar los datos a Firebase mediante una clase utilitaria.
 */
public class RegisterActivity extends AppCompatActivity {

    /** Campo de texto para ingresar el nombre del usuario. */
    private EditText campoNombre;

    /** Campo de texto para ingresar el correo electrónico del usuario. */
    private EditText campoCorreo;

    /** Campo de texto para ingresar la contraseña del usuario. */
    private EditText campoContrasena;


    /**
     * Metodo principal que se ejecuta al crear la actividad.
     * Inicializa los componentes de UI y configura el botón de registro.
     *
     * @param savedInstanceState estado anterior de la actividad si fue restaurada.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Referencias a los campos de entrada de datos
        campoNombre = findViewById(R.id.editTextName);
        campoCorreo = findViewById(R.id.editTextEmail);
        campoContrasena = findViewById(R.id.editTextPassword);
        Button botonRegistrar = findViewById(R.id.btnRegister);

        // Acción al pulsar el botón "Registrarse"
        botonRegistrar.setOnClickListener(v -> {
            String nombre = campoNombre.getText().toString().trim();
            String correo = campoCorreo.getText().toString().trim();
            String contrasena = campoContrasena.getText().toString().trim();

            // Validación: campos obligatorios no pueden estar vacíos
            if (nombre.isEmpty() || correo.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(this, R.string.mensaje_campos_obligatorios, Toast.LENGTH_SHORT).show();
                return;
            }
            // Validación: formato de correo electrónico válido
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                Toast.makeText(this, R.string.mensaje_correo_invalido, Toast.LENGTH_SHORT).show();
                return;
            }
            // Validación: contraseña con al menos 6 caracteres
            if (contrasena.length() < 6) {
                Toast.makeText(this, R.string.mensaje_requisitos_contrasena, Toast.LENGTH_SHORT).show();
                return;
            }

            // Registro delegado a clase utilitaria que gestiona la lógica con Firebase
            UsuarioUtils.registrarNuevoUsuario(nombre, correo, contrasena, this);
        });
    }
}
