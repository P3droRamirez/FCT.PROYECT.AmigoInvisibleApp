package NetMind.amigoinvisible.activities;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.auth.api.identity.GetSignInIntentRequest;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.SignInCredential;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.utils.UsuarioUtils;

/**
 * Actividad principal de la aplicación que gestiona el inicio de sesión del usuario.
 * Ofrece autenticación por correo electrónico y Google. Si el usuario ya ha iniciado sesión previamente,
 * se le redirige automáticamente a la pantalla de bienvenida.
 */
public class MainActivity extends AppCompatActivity {

    /** Etiqueta para logs. */
    private static final String TAG = "MainActivity";

    /** Instancia de FirebaseAuth para gestionar la autenticación. */
    private FirebaseAuth firebaseAuth;

    /** Campos de entrada de correo y contraseña. */
    private EditText campoCorreo, campoContrasena;

    /** Launcher utilizado para gestionar el flujo de login con Google. */
    private ActivityResultLauncher<IntentSenderRequest> lanzadorLoginGoogle;

    /**
     * Metodo principal que se ejecuta al iniciar la actividad.
     * Inicializa la interfaz, configura listeners, comprueba sesión activa
     * y crea el canal de notificaciones para dispositivos Android 8 o superior.
     *
     * @param savedInstanceState estado guardado de la instancia anterior, si existe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "default_channel",
                    "Notificaciones de Amigo Invisible",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Notificaciones de sorteos y asignaciones");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        inicializarComponentesUI();
        configurarListeners();
        configurarLanzadorGoogle();


        // // Inicializar autenticación de Firebase. Si ya hay sesión activa, ir a bienvenida
        firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() != null) {
            irAPantallaBienvenida();
        }

        // Obtener token FCM (útil para notificaciones push)
        UsuarioUtils.obtenerTokenFirebase(this);
    }

    /**
     * Inicializa los componentes de la interfaz gráfica, como los campos de texto.
     */
    private void inicializarComponentesUI() {
        campoCorreo = findViewById(R.id.emailInput);
        campoContrasena = findViewById(R.id.passwordInput);
    }

    /**
     * Configura los botones de login, Google Sign-In y registro con sus respectivos listeners.
     */
    private void configurarListeners() {
        findViewById(R.id.btnLogIn).setOnClickListener(v -> iniciarSesionConCorreo());
        findViewById(R.id.btnEmailSignIn).setOnClickListener(v -> iniciarSesionConCorreo());
        findViewById(R.id.btnGoogleSignIn).setOnClickListener(v -> iniciarSesionConGoogle());

        // Texto "¿No tienes cuenta? Regístrate" con efecto clic solo en "Regístrate"
        TextView txtRegistrate = findViewById(R.id.txtRegistrate);
        txtRegistrate.setOnClickListener(v -> {
            Log.d(TAG, "Click en 'Regístrate'");
            startActivity(new Intent(MainActivity.this, RegisterActivity.class));
        });
    }

    /**
     * Configura el lanzador de actividad que se usará para manejar la autenticación con Google.
     * Este metodo usa la API de actividad para obtener el resultado del intento de login.
     */
    private void configurarLanzadorGoogle() {
        lanzadorLoginGoogle = registerForActivityResult(
                new ActivityResultContracts.StartIntentSenderForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        procesarResultadoGoogle(result.getData());
                    }
                }
        );
    }

    /**
     * Inicia el proceso de inicio de sesión con Google utilizando el ID de cliente definido en strings.xml.
     * Se lanza el intent proporcionado por la API de Google Identity.
     */
    private void iniciarSesionConGoogle() {
        GetSignInIntentRequest request = GetSignInIntentRequest.builder()
                .setServerClientId(getString(R.string.default_web_client_id))
                .build();

        Identity.getSignInClient(this)
                .getSignInIntent(request)
                .addOnSuccessListener(pendingIntent -> {
                    IntentSenderRequest intentRequest = new IntentSenderRequest.Builder(pendingIntent.getIntentSender()).build();
                    lanzadorLoginGoogle.launch(intentRequest);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, getString(R.string.error_google_sign_in), Toast.LENGTH_SHORT).show();
                    Log.e(TAG, getString(R.string.error_google_sign_in), e);
                });
    }

    /**
     * Procesa los datos devueltos tras la autenticación con Google.
     * Si el ID token es válido, se genera una credencial para Firebase y se autentica al usuario.
     *
     * @param data Intent devuelto por el flujo de autenticación de Google.
     */
    private void procesarResultadoGoogle(Intent data) {
        try {
            SignInCredential credential = Identity.getSignInClient(this).getSignInCredentialFromIntent(data);
            String idToken = credential.getGoogleIdToken();

            if (idToken != null) {
                AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(idToken, null);
                UsuarioUtils.autenticarConFirebase(firebaseCredential, this, this::irAPantallaBienvenida);
            }
        } catch (ApiException e) {
            Toast.makeText(this, getString(R.string.error_autenticacion_google), Toast.LENGTH_SHORT).show();
            Log.e(TAG, getString(R.string.error_google_sign_in), e);
        }
    }

    /**
     * Inicia sesión utilizando las credenciales introducidas por el usuario (correo y contraseña).
     * Si los campos están vacíos, muestra un mensaje de advertencia.
     * En caso de éxito, redirige a la pantalla de bienvenida.
     */
    private void iniciarSesionConCorreo() {
        String correo = campoCorreo.getText().toString().trim();
        String contrasena = campoContrasena.getText().toString().trim();

        if (TextUtils.isEmpty(correo) || TextUtils.isEmpty(contrasena)) {
            Toast.makeText(this, getString(R.string.mensaje_campos_obligatorios), Toast.LENGTH_SHORT).show();
            return;
        }

        firebaseAuth.signInWithEmailAndPassword(correo, contrasena)
                .addOnSuccessListener(authResult -> {
                    if (firebaseAuth.getCurrentUser() != null) {
                        UsuarioUtils.verificarUsuario(firebaseAuth.getCurrentUser(), this, this::irAPantallaBienvenida);
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, getString(R.string.error_login_correo, e.getMessage()), Toast.LENGTH_LONG).show();
                    Log.e(TAG, getString(R.string.error_login_correo, e.getMessage()), e);
                });
    }

    /**
     * Redirige al usuario a la pantalla principal de bienvenida tras una autenticación exitosa.
     * Esta actividad se termina para evitar volver con el botón "Atrás".
     */
    private void irAPantallaBienvenida() {
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }
}
