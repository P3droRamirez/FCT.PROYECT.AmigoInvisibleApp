package NetMind.amigoinvisible.utils;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.*;

/**
 * Clase utilitaria para el envío de correos electrónicos desde Firebase mediante una colección Firestore.
 * Utiliza una estructura compatible con la extensión de envío de correo (`firebase-extensions/sendgrid`).
 */
public class EmailSender {

    private static final String COLLECTION_NAME = "mail";

    /**
     * Encola un correo a un solo destinatario en Firestore
     * Este metodo es una versión simplificada del metodo que acepta una lista de destinatarios.
     * Internamente convierte el destinatario en una lista de un solo elemento y delega la lógica.
     * @param destinatario Correo del destinatario
     * @param asunto       Asunto del correo
     * @param cuerpoPlano  Versión texto plano del mensaje
     * @param cuerpoHTML   Versión HTML del mensaje
     */
    public static void enviarCorreo(String destinatario, String asunto, String cuerpoPlano, String cuerpoHTML) {
        if (destinatario == null || destinatario.trim().isEmpty()) {
            System.err.println("❌ Dirección de correo vacía o nula. No se enviará el correo.");
            return;
        }

        enviarCorreo(Collections.singletonList(destinatario), asunto, cuerpoPlano, cuerpoHTML);
    }

    /**
     * Envía un correo a múltiples destinatarios.
     * Este metodo crea un documento en la colección "mail" de Firestore que será procesado
     * por una extensión backend (como Firebase Extension para envío de correos).
     * @param destinatarios Lista de correos electrónicos
     * @param asunto        Asunto del correo
     * @param cuerpoPlano   Versión texto plano del mensaje
     * @param cuerpoHTML    Versión HTML del mensaje
     */
    public static void enviarCorreo(List<String> destinatarios, String asunto, String cuerpoPlano, String cuerpoHTML) {
        if (destinatarios == null || destinatarios.isEmpty()) {
            System.err.println("❌ Lista de destinatarios vacía. No se enviará el correo.");
            return;
        }

        Map<String, Object> emailData = construirCorreo(destinatarios, asunto, cuerpoPlano, cuerpoHTML);

        FirebaseFirestore.getInstance()
                .collection(COLLECTION_NAME)
                .add(emailData)
                .addOnSuccessListener(docRef -> {
                    System.out.println("✅ Correo encolado correctamente. ID Firestore: " + docRef.getId());
                    System.out.println("📤 Enviado a: " + String.join(", ", destinatarios));
                })
                .addOnFailureListener(e -> {
                    System.err.println("❌ Error al encolar correo: " + e.getMessage());
                    e.printStackTrace();
                });
    }

    /**
     * Construye el mapa con la estructura del correo según espera la extensión de envío.
     *
     * @param destinatarios Lista de correos electrónicos
     * @param asunto        Asunto del mensaje
     * @param cuerpoPlano   Contenido plano
     * @param cuerpoHTML    Contenido HTML
     * @return Mapa listo para insertar en Firestore
     */
    private static Map<String, Object> construirCorreo(List<String> destinatarios, String asunto, String cuerpoPlano, String cuerpoHTML) {
        Map<String, Object> emailData = new HashMap<>();

        emailData.put("to", destinatarios);

        Map<String, Object> message = new HashMap<>();
        message.put("subject", asunto != null ? asunto : "(Sin asunto)");
        message.put("text", cuerpoPlano != null ? cuerpoPlano : "");
        message.put("html", cuerpoHTML != null ? cuerpoHTML : "");

        emailData.put("message", message);
        return emailData;
    }
}
