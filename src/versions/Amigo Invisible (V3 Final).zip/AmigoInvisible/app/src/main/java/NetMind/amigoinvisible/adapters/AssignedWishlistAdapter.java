package NetMind.amigoinvisible.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.models.WishlistItem;
import java.util.List;


/**
 * Adaptador personalizado para mostrar la lista de deseos del amigo asignado.
 * Cada ítem representa un deseo, y al pulsarlo puede abrirse una URL concreta o una búsqueda en Amazon.
 */
public class AssignedWishlistAdapter extends RecyclerView.Adapter<AssignedWishlistAdapter.ViewHolder> {

    private final List<WishlistItem> lista;
    private final Context context;
    /**
     * Constructor que recibe los datos y contexto necesarios para el adaptador.
     *
     * @param lista   Lista de objetos WishlistItem a mostrar
     * @param context Contexto desde el que se instancia el adaptador
     */
    public AssignedWishlistAdapter(List<WishlistItem> lista, Context context) {
        this.lista = lista;
        this.context = context;
    }
    /**
     * Infla el layout XML de cada ítem de la lista.
     *
     * @param parent   Contenedor padre (RecyclerView)
     * @param viewType Tipo de vista (no se usa en este caso)
     * @return ViewHolder con la vista inflada
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_deseo_asignado, parent, false);
        return new ViewHolder(vista);
    }
    /**
     * Asocia los datos del deseo a su respectiva vista.
     * Si el ítem tiene una URL válida, se abrirá al pulsar. En caso contrario, se lanza una búsqueda en Amazon.
     *
     * @param holder   Contenedor de vistas del ítem
     * @param position Posición actual dentro del RecyclerView
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WishlistItem item = lista.get(position);
        holder.texto.setText(item.getTitle());

        holder.texto.setOnClickListener(v -> {
            String url = item.getUrl();
            if (url != null && !url.trim().isEmpty()) {
                context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } else {
                String query = Uri.encode(item.getTitle() + " Amazon");
                context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.amazon.es/s?k=" + query)));
            }
        });
    }
    /**
     * Devuelve la cantidad de elementos en la lista.
     */
    @Override
    public int getItemCount() {
        return lista.size();
    }
    /**
     * ViewHolder que representa visualmente un deseo.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView texto;
        public ViewHolder(View itemView) {
            super(itemView);
            texto = itemView.findViewById(R.id.textWishItem);
        }
    }
}
