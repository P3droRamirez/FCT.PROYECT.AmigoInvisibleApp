package NetMind.amigoinvisible.utils;

import androidx.annotation.NonNull;

import com.google.firebase.firestore.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import NetMind.amigoinvisible.models.Group;
import NetMind.amigoinvisible.models.Member;

/**
 * Clase utilitaria que contiene toda la lógica relacionada con grupos.
 * Incluye operaciones como realizar el sorteo, guardar resultados, y escuchar actualizaciones en tiempo real.
 */
public class GroupUtils {

    private static final FirebaseFirestore db = FirebaseFirestore.getInstance();

    /**
     * Ejecuta el proceso del sorteo de Amigo Invisible.
     * * 1. Obtiene participantes
     * * 2. Verifica que no se haya sorteado antes
     * * 3. Genera asignaciones aleatorias sin repetir
     * * 4. Guarda las asignaciones
     * * 5. Notifica por email
     *
     * @param groupId   ID del grupo
     * @param onSuccess Callback en caso de éxito
     * @param onError   Callback en caso de error con mensaje
     */
    public static void realizarSorteo(String groupId, Runnable onSuccess, Consumer<String> onError) {
        DocumentReference grupoRef = db.collection("groups").document(groupId);

        obtenerParticipantes(grupoRef, (participantes) -> {
            if (participantes.size() < 2) {
                onError.accept("Debe haber al menos 2 miembros para realizar el sorteo.");
                return;
            }

            verificarSorteoPrevio(grupoRef, yaRealizado -> {
                if (yaRealizado) {
                    onError.accept("El sorteo ya fue realizado para este grupo.");
                    return;
                }

                List<String> receptores = generarAsignaciones(participantes);
                if (receptores == null) {
                    onError.accept("No se pudo generar una asignación válida. Inténtalo nuevamente.");
                    return;
                }

                guardarResultadosYNotificar(grupoRef, participantes, receptores, onSuccess, onError);
            }, onError);

        }, onError);
    }


    /**
     * Recupera la lista de participantes (IDs de usuarios) de un grupo Firestore.
     *
     * @param grupoRef
     * @param onResult
     * @param onError
     */
    private static void obtenerParticipantes(DocumentReference grupoRef,
                                             Consumer<List<String>> onResult,
                                             Consumer<String> onError) {
        grupoRef.collection("members").get()
                .addOnSuccessListener(snapshot -> {
                    List<String> participantes = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        participantes.add(doc.getId());
                    }
                    onResult.accept(participantes);
                })
                .addOnFailureListener(e -> onError.accept("Error al obtener los miembros: " + e.getMessage()));
    }

    /**
     * Verifica si ya existe una colección de asignaciones para ese grupo.
     *
     * @param grupoRef
     * @param onResult
     * @param onError
     */
    private static void verificarSorteoPrevio(DocumentReference grupoRef,
                                              Consumer<Boolean> onResult,
                                              Consumer<String> onError) {
        grupoRef.collection("assignments").get()
                .addOnSuccessListener(snapshot -> onResult.accept(!snapshot.isEmpty()))
                .addOnFailureListener(e -> onError.accept("Error al verificar sorteo previo: " + e.getMessage()));
    }

    /**
     * Genera una asignación aleatoria válida sin asignarse a sí mismo.
     *
     * @param participantes
     * @return
     */
    private static List<String> generarAsignaciones(List<String> participantes) {
        List<String> receptores = new ArrayList<>(participantes);
        Random random = new Random();

        for (int intento = 0; intento < 10; intento++) {
            Collections.shuffle(receptores, random);
            boolean valido = true;

            for (int i = 0; i < participantes.size(); i++) {
                if (participantes.get(i).equals(receptores.get(i))) {
                    valido = false;
                    break;
                }
            }

            if (valido) return receptores;
        }

        return null; // No se logró generar una asignación válida
    }

    /**
     * Guarda las asignaciones en Firestore y envía correos de notificación a cada participante.
     *
     * @param grupoRef
     * @param asignadores
     * @param asignados
     * @param onSuccess
     * @param onError
     */
    private static void guardarResultadosYNotificar(
            DocumentReference grupoRef,
            List<String> asignadores,
            List<String> asignados,
            Runnable onSuccess,
            Consumer<String> onError) {

        AtomicInteger tareasPendientes = new AtomicInteger(asignadores.size());

        for (int i = 0; i < asignadores.size(); i++) {
            final String asignadorId = asignadores.get(i);
            final String asignadoId = asignados.get(i);

            DocumentReference asignadorRef = grupoRef.collection("members").document(asignadorId);
            DocumentReference asignadoRef = grupoRef.collection("members").document(asignadoId);

            System.out.println("📤 Procesando asignador: " + asignadorId + " → asignado: " + asignadoId);

            asignadorRef.get().addOnSuccessListener(asignadorDoc -> {
                asignadoRef.get().addOnSuccessListener(asignadoDoc -> {

                    // Obtener datos del asignador
                    final String emailAsignador = asignadorDoc.getString("email");
                    final String nombreAsignador = Optional.ofNullable(asignadorDoc.getString("name"))
                            .filter(s -> !s.trim().isEmpty()).orElse("(sin nombre)");

                    // Obtener nombre del asignado
                    final String nombreAsignado = Optional.ofNullable(asignadoDoc.getString("name"))
                            .filter(s -> !s.trim().isEmpty()).orElse("(sin nombre)");

                    System.out.println("📨 Email del asignador: " + emailAsignador);
                    System.out.println("👤 Nombre asignador: " + nombreAsignador + ", asignado: " + nombreAsignado);

                    // Preparar batch para guardar asignación
                    WriteBatch batch = db.batch();
                    batch.set(grupoRef.collection("assignments").document(asignadorId),
                            Map.of("assignedTo", asignadoId));
                    batch.update(asignadorRef, "assignedTo", asignadoId);

                    // Commit del batch
                    batch.commit()
                            .addOnSuccessListener(unused -> {
                                if (emailAsignador != null && !emailAsignador.trim().isEmpty()) {
                                    String subject = "🎁 Has sido asignado en el Amigo Invisible";
                                    String text = "Hola " + nombreAsignador + ", te ha tocado: " + nombreAsignado;
                                    String html = "<p>🎁 <strong>Hola " + nombreAsignador + "</strong>,<br>" +
                                            "Tu amigo invisible es: <strong>" + nombreAsignado + "</strong></p>";

                                    System.out.println("✅ Enviando correo a: " + emailAsignador);
                                    EmailSender.enviarCorreo(emailAsignador, subject, text, html);
                                } else {
                                    System.out.println("⚠️ Usuario sin email → UID: " + asignadorId);
                                }

                                // Verifica si es la última tarea pendiente
                                if (tareasPendientes.decrementAndGet() == 0) {
                                    System.out.println("✅ Todas las asignaciones completadas");
                                    onSuccess.run();
                                }
                            })
                            .addOnFailureListener(e -> {
                                String mensajeError = "❌ Error al guardar asignación para " + asignadorId + ": " + e.getMessage();
                                System.err.println(mensajeError);
                                onError.accept(mensajeError);
                            });

                }).addOnFailureListener(e -> {
                    String mensajeError = "❌ Error al leer asignado (" + asignadoId + "): " + e.getMessage();
                    System.err.println(mensajeError);
                    onError.accept(mensajeError);
                });

            }).addOnFailureListener(e -> {
                String mensajeError = "❌ Error al leer asignador (" + asignadorId + "): " + e.getMessage();
                System.err.println(mensajeError);
                onError.accept(mensajeError);
            });
        }
    }

    /**
     * Escucha en tiempo real los grupos en los que participa un usuario concreto.
     * Devuelve en tiempo real la lista de grupos actualizada.
     *
     * @param userId            ID del usuario autenticado.
     * @param onGruposCambiados Callback con la lista actualizada de grupos.
     * @return ListenerRegistration para poder detener la escucha más adelante.
     */
    public static ListenerRegistration escucharGruposDeUsuario(
            @NonNull String userId,
            @NonNull Consumer<List<Group>> onGruposCambiados,
            @NonNull Consumer<Exception> onError
    ) {
        CollectionReference gruposRef = db.collection("groups");

        return gruposRef.addSnapshotListener((snapshot, error) -> {
            if (error != null) {
                onError.accept(error);
                return;
            }

            if (snapshot == null) {
                onGruposCambiados.accept(Collections.emptyList());
                return;
            }

            List<Group> gruposUsuario = new ArrayList<>();

            for (DocumentSnapshot docGrupo : snapshot.getDocuments()) {
                List<String> miembros = (List<String>) docGrupo.get("members");

                if (miembros != null && miembros.contains(userId)) {
                    Group grupo = docGrupo.toObject(Group.class);
                    if (grupo != null) {
                        grupo.setId(docGrupo.getId());
                        gruposUsuario.add(grupo);
                    }
                }
            }

            onGruposCambiados.accept(gruposUsuario);
        });
    }
    /**
     * Versión simplificada de la asignación para pruebas unitarias.
     * Recibe una lista de miembros y genera asignaciones evitando autoasignaciones
     * y respetando exclusiones definidas.
     */
    public static Map<String, String> realizarAsignaciones(List<Member> miembros) {
        List<String> asignadores = new ArrayList<>();
        Map<String, Member> mapaMiembros = new HashMap<>();
        for (Member m : miembros) {
            asignadores.add(m.getId());
            mapaMiembros.put(m.getId(), m);
        }

        Random random = new Random();
        for (int intento = 0; intento < 10; intento++) {
            List<String> receptores = new ArrayList<>(asignadores);
            Collections.shuffle(receptores, random);

            boolean valido = true;
            Map<String, String> resultado = new HashMap<>();

            for (int i = 0; i < asignadores.size(); i++) {
                String asignador = asignadores.get(i);
                String receptor = receptores.get(i);

                if (asignador.equals(receptor)) {
                    valido = false;
                    break;
                }

                Member m = mapaMiembros.get(asignador);
                if (m.getExcludedUserIds() != null && m.getExcludedUserIds().contains(receptor)) {
                    valido = false;
                    break;
                }

                resultado.put(asignador, receptor);
            }

            if (valido) return resultado;
        }

        return null;
    }


}
