package NetMind.amigoinvisible.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.models.Invitation;

/**
 * Adaptador personalizado para mostrar una lista de invitaciones pendientes.
 * Muestra el nombre del grupo y botones para aceptar o rechazar.
 */
public class InvitationsAdapter extends RecyclerView.Adapter<InvitationsAdapter.InvitationViewHolder> {

    /**
     * Interfaz para gestionar la acción de aceptar una invitación.
     */
    public interface OnAcceptClickListener {
        void onAccept(Invitation invitation);
    }

    /**
     * Interfaz para gestionar la acción de rechazar una invitación.
     */
    public interface OnRejectClickListener {
        void onReject(Invitation invitation);
    }

    private final List<Invitation> invitaciones;
    private final OnAcceptClickListener acceptListener;
    private final OnRejectClickListener rejectListener;

    /**
     * Constructor del adaptador
     *
     * @param invitaciones Lista de objetos Invitation a mostrar.
     * @param acceptListener Función a ejecutar cuando se acepta una invitación.
     * @param rejectListener Función a ejecutar cuando se rechaza una invitación.
     */
    public InvitationsAdapter(List<Invitation> invitaciones,
                              OnAcceptClickListener acceptListener,
                              OnRejectClickListener rejectListener) {
        this.invitaciones = invitaciones;
        this.acceptListener = acceptListener;
        this.rejectListener = rejectListener;
    }

    /**
     * Infla la vista del ítem (item_invitation.xml)
     */
    @NonNull
    @Override
    public InvitationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_invitation, parent, false);
        return new InvitationViewHolder(vista);
    }

    /**
     * Asocia los datos a cada item del RecyclerView.
     */
    @Override
    public void onBindViewHolder(@NonNull InvitationViewHolder holder, int position) {
        Invitation invitacion = invitaciones.get(position);
        holder.nombreGrupo.setText(invitacion.getGroupName());

        // Acción al pulsar Aceptar
        holder.botonAceptar.setOnClickListener(v -> {
            if (acceptListener != null) {
                acceptListener.onAccept(invitacion);
            }
        });

        // Acción al pulsar Rechazar
        holder.botonRechazar.setOnClickListener(v -> {
            if (rejectListener != null) {
                rejectListener.onReject(invitacion);
            }
        });
    }

    @Override
    public int getItemCount() {
        return invitaciones.size();
    }

    /**
     * ViewHolder que mantiene las referencias a los elementos de la vista de un ítem.
     */
    public static class InvitationViewHolder extends RecyclerView.ViewHolder {
        TextView nombreGrupo;
        Button botonAceptar, botonRechazar;

        public InvitationViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreGrupo = itemView.findViewById(R.id.txt_nombre_grupo);
            botonAceptar = itemView.findViewById(R.id.btn_aceptar);
            botonRechazar = itemView.findViewById(R.id.btn_rechazar);
        }
    }
}
