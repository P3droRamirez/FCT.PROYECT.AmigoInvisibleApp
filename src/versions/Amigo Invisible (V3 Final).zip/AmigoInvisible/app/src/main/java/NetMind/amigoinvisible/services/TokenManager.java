package NetMind.amigoinvisible.services;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;

/**
 * Clase de servicio encargada de obtener y actualizar el token FCM (Firebase Cloud Messaging)
 * del usuario autenticado, guardándolo en Firestore para el envío de notificaciones personalizadas.
 */
public class TokenManager {
    /**
     * Obtiene el token FCM del usuario actual y lo actualiza en su documento de Firestore.
     * Este token es utilizado para enviar notificaciones push al dispositivo.
     * Si no hay usuario autenticado, el metodo no realiza ninguna acción.
     */
    public static void actualizarTokenFCM() {
        FirebaseUser usuario = FirebaseAuth.getInstance().getCurrentUser();
        if (usuario == null) return;

        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Log.e("FCM_TOKEN", "❌ No se pudo obtener el token", task.getException());
                        return;
                    }
                    String token = task.getResult();
                    Log.d("FCM_TOKEN", "Token FCM obtenido: " + token);

                    FirebaseFirestore.getInstance()
                            .collection("users")
                            .document(usuario.getUid())
                            .update("fcmToken", token)
                            .addOnSuccessListener(aVoid ->
                                    Log.d("FCM_TOKEN", "✅ Token FCM actualizado en Firestore"))
                            .addOnFailureListener(e ->
                                    Log.e("FCM_TOKEN", "❌ Error actualizando token en Firestore", e));
                });
    }
}
