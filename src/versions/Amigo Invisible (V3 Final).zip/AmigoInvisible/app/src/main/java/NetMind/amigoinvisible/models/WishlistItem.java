package NetMind.amigoinvisible.models;
import java.util.HashMap;
import java.util.Map;
/**
 * Modelo de datos que representa un ítem dentro de la lista de deseos de un miembro.
 * Contiene un título (nombre del deseo) y una URL opcional del producto.
 * Se utiliza tanto para mostrar en la UI como para almacenar en Firestore.
 */
public class WishlistItem {
    private String title;
    private String url;
    /**
     * Constructor vacío requerido por Firestore para la deserialización automática.
     */
    public WishlistItem() {}
    /**
     * Constructor personalizado para crear un deseo con nombre y URL.
     *
     * @param title Nombre o descripción del deseo.
     * @param url   URL opcional del producto (puede ser null o vacío).
     */
    public WishlistItem(String title, String url) {
        this.title = title;
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    /**
     * Convierte este objeto en un mapa clave-valor,
     * ideal para subirlo como parte de un array a Firestore.
     *
     * @return Mapa con los campos "title" y "url".
     */
    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("title", title);
        map.put("url", url);
        return map;
    }
}
