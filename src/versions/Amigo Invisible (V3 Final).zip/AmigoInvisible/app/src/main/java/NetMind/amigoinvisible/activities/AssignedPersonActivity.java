package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.AssignedWishlistAdapter;
import NetMind.amigoinvisible.models.WishlistItem;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Actividad que muestra al usuario los datos de la persona que le ha tocado
 * como "amigo invisible" dentro de un grupo específico.
 * Incluye su nombre, foto de perfil (si tiene) y su lista de deseos.
 */
public class AssignedPersonActivity extends AppCompatActivity {

    // Instancia de Firestore
    private FirebaseFirestore db;

    // Datos recibidos por Intent
    private String groupId;
    private String assignedId;

    // Elementos de la interfaz
    private TextView nombreAsignadoTextView;
    private ImageView fotoAsignado;
    private RecyclerView recyclerView;

    // Adaptador y lista de deseos del asignado
    private AssignedWishlistAdapter adapter;
    private final List<WishlistItem> deseosAsignado = new ArrayList<>();

    /**
     * Metodo principal del ciclo de vida de la actividad.
     * Valida los datos recibidos por intent, inicializa la interfaz y carga los datos desde Firestore.
     *
     * @param savedInstanceState Estado guardado de la actividad.
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assigned_person);

        // Obtener parámetros del intent
        groupId = getIntent().getStringExtra("groupId");
        assignedId = getIntent().getStringExtra("assignedId");

        // Enlazar vistas
        nombreAsignadoTextView = findViewById(R.id.textNombreAsignado);
        fotoAsignado = findViewById(R.id.imageAsignado);
        recyclerView = findViewById(R.id.recyclerListaDeseos);

        // Validar los datos mínimos requeridos
        if (groupId == null || assignedId == null) {
            Toast.makeText(this, R.string.error_datos_asignado, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Inicializar Firestore
        db = FirebaseFirestore.getInstance();

        // Configurar RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AssignedWishlistAdapter(deseosAsignado, this);
        recyclerView.setAdapter(adapter);

        // Cargar los datos del miembro asignado
        cargarDatosAsignado();
    }

    /**
     * Realiza una consulta a Firestore para obtener los datos del miembro asignado.
     * Si es exitoso, llama a mostrarDatosAsignado().
     */
    private void cargarDatosAsignado() {
        db.collection("groups")
                .document(groupId)
                .collection("members")
                .document(assignedId)
                .get()
                .addOnSuccessListener(this::mostrarDatosAsignado)
                .addOnFailureListener(e ->
                        Toast.makeText(this, R.string.error_datos_asignado, Toast.LENGTH_SHORT).show());
    }

    /**
     * Muestra los datos del miembro asignado en la interfaz:
     * nombre, imagen de perfil y lista de deseos interactiva.
     *
     * @param doc Documento Firestore con la información del miembro.
     */
    private void mostrarDatosAsignado(DocumentSnapshot doc) {
        String nombre = doc.getString("name");
        String photoUrl = doc.getString("photoUrl");
        Object deseos = doc.get("wishlist");

        nombreAsignadoTextView.setText(getString(R.string.text_asignado_nombre_placeholder, nombre));

        if (photoUrl != null && !photoUrl.isEmpty()) {
            Glide.with(this).load(photoUrl).placeholder(R.drawable.ic_user).into(fotoAsignado);
        }

        TextView textoListaVacia = findViewById(R.id.textListaVacia);
        deseosAsignado.clear();

        if (deseos instanceof List<?>) {
            for (Object item : (List<?>) deseos) {
                if (item instanceof Map) {
                    Map<?, ?> mapa = (Map<?, ?>) item;
                    String titulo = String.valueOf(mapa.get("title"));
                    String url = mapa.get("url") != null ? String.valueOf(mapa.get("url")) : "";
                    deseosAsignado.add(new WishlistItem(titulo, url));
                }
            }

            textoListaVacia.setVisibility(deseosAsignado.isEmpty() ? View.VISIBLE : View.GONE);
            adapter.notifyDataSetChanged();
        } else {
            textoListaVacia.setVisibility(View.VISIBLE);
        }
    }
}
