package NetMind.amigoinvisible.fragments;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import NetMind.amigoinvisible.R;

/**
 * Fragmento encargado de gestionar la creación de nuevos grupos de Amigo Invisible.
 * Permite ingresar el nombre del grupo, límite de participantes, presupuesto y una imagen representativa.
 * Los datos se almacenan en Firebase Firestore y Storage.
 */
public class CreateGroupFragment extends Fragment {

    private EditText campoNombreGrupo, campoMaxParticipantes, campoPresupuesto;
    private ImageView groupImagePreview;
    private Uri imageUriSeleccionada;

    private FirebaseFirestore baseDatos;
    private FirebaseAuth auth;

    private static final int PICK_IMAGE_REQUEST = 101;
    private static final int GRUPOS_CREADOS_MAXIMOS = 3;

    private View vista;

    /**
     * Crea e infla la vista del fragmento.
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        vista = inflater.inflate(R.layout.fragment_create_group, container, false);

        inicializarComponentes();
        configurarEventos();

        return vista;
    }

    /**
     * Inicializa los componentes visuales y servicios de Firebase.
     */
    private void inicializarComponentes() {
        campoNombreGrupo = vista.findViewById(R.id.editTextGroupName);
        campoMaxParticipantes = vista.findViewById(R.id.editTextMaxParticipants);
        campoPresupuesto = vista.findViewById(R.id.editTextBudgetLimit);
        groupImagePreview = vista.findViewById(R.id.groupImagePreview);

        baseDatos = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }

    /**
     * Configura los botones para seleccionar imagen y crear grupo.
     */
    private void configurarEventos() {
        vista.findViewById(R.id.btnSelectImage).setOnClickListener(v -> seleccionarImagen());
        vista.findViewById(R.id.btnFinishGroup).setOnClickListener(v -> crearGrupo());
    }

    /**
     * Lanza el selector de imagen del sistema.
     */
    private void seleccionarImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    /**
     * Procesa el resultado del selector de imágenes y actualiza la vista previa.
     *
     * @param requestCode Código de la petición.
     * @param resultCode  Resultado devuelto.
     * @param data        Datos devueltos (URI de imagen).
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            imageUriSeleccionada = data.getData();
            Glide.with(this).load(imageUriSeleccionada).into(groupImagePreview);
        }
    }

    /**
     * Valida los campos y comienza el proceso de creación del grupo.
     */
    private void crearGrupo() {
        String nombre = campoNombreGrupo.getText().toString().trim();
        String maxStr = campoMaxParticipantes.getText().toString().trim();
        String presupuestoStr = campoPresupuesto.getText().toString().trim();

        if (TextUtils.isEmpty(nombre) || TextUtils.isEmpty(maxStr) || TextUtils.isEmpty(presupuestoStr)) {
            mostrarToast(R.string.error_campos_obligatorios);
            return;
        }

        int maxParticipantes;
        double presupuesto;
        try {
            maxParticipantes = Integer.parseInt(maxStr);
            presupuesto = Double.parseDouble(presupuestoStr);
        } catch (NumberFormatException e) {
            mostrarToast(R.string.error_valores_numericos);
            return;
        }

        String idUsuario = auth.getCurrentUser().getUid();
        verificarLimiteYCrearGrupo(nombre, maxParticipantes, presupuesto, idUsuario);
    }

    /**
     * Comprueba si el usuario ha alcanzado el máximo de grupos creados.
     *
     * @param nombre Nombre del grupo.
     * @param max    Máximo de participantes.
     * @param presupuesto Presupuesto por participante.
     * @param idUsuario ID del usuario autenticado.
     */
    private void verificarLimiteYCrearGrupo(String nombre, int max, double presupuesto, String idUsuario) {
        baseDatos.collection("groups")
                .whereEqualTo("owner", idUsuario)
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.size() >= GRUPOS_CREADOS_MAXIMOS) {
                        mostrarToast(getString(R.string.error_max_grupos, GRUPOS_CREADOS_MAXIMOS));
                        return;
                    }
                    crearGrupoEnFirestore(nombre, max, presupuesto, idUsuario);
                })
                .addOnFailureListener(e -> mostrarToast(R.string.error_verificar_limite));
    }

    /**
     * Guarda los datos básicos del grupo en Firestore.
     */
    private void crearGrupoEnFirestore(String nombre, int max, double presupuesto, String idUsuario) {
        Map<String, Object> datosGrupo = new HashMap<>();
        datosGrupo.put("name", nombre);
        datosGrupo.put("owner", idUsuario);
        datosGrupo.put("maxParticipants", max);
        datosGrupo.put("budgetLimit", presupuesto);
        datosGrupo.put("members", new ArrayList<String>() {{ add(idUsuario); }});
        datosGrupo.put("imageUrl", "");

        baseDatos.collection("groups").add(datosGrupo).addOnSuccessListener(docRef -> {
            subirImagenSiHay(docRef);
            agregarMiembroInicial(docRef, idUsuario);
        }).addOnFailureListener(e -> mostrarToast(R.string.error_crear_grupo));
    }

    /**
     * Si hay imagen seleccionada, la sube al almacenamiento y actualiza la URL en Firestore.
     */
    private void subirImagenSiHay(DocumentReference docRef) {
        if (imageUriSeleccionada == null) return;

        StorageReference storageRef = FirebaseStorage.getInstance().getReference()
                .child("group_images/" + docRef.getId() + ".jpg");

        storageRef.putFile(imageUriSeleccionada)
                .addOnSuccessListener(taskSnapshot ->
                        storageRef.getDownloadUrl()
                                .addOnSuccessListener(uri ->
                                        docRef.update("imageUrl", uri.toString())
                                )
                );
    }

    /**
     * Registra al usuario creador como primer miembro del grupo.
     */
    private void agregarMiembroInicial(DocumentReference docRef, String userId) {
        Map<String, Object> datosMiembro = new HashMap<>();
        datosMiembro.put("name", auth.getCurrentUser().getDisplayName());
        datosMiembro.put("email", auth.getCurrentUser().getEmail());

        docRef.collection("members").document(userId).set(datosMiembro).addOnSuccessListener(unused -> {
            mostrarToast(R.string.mensaje_grupo_creado);
            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new ViewGroupsFragment())
                    .commit();
        });
    }

    /**
     * Muestra un mensaje tipo Toast desde un recurso de strings.
     *
     * @param resId ID del recurso string.
     */
    private void mostrarToast(int resId) {
        Toast.makeText(getContext(), getString(resId), Toast.LENGTH_SHORT).show();
    }

    /**
     * Muestra un mensaje tipo Toast con texto plano.
     *
     * @param mensaje Texto del mensaje.
     */
    private void mostrarToast(String mensaje) {
        Toast.makeText(getContext(), mensaje, Toast.LENGTH_SHORT).show();
    }
}
