package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import java.util.ArrayList;
import java.util.List;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.GroupListAdapter;
import NetMind.amigoinvisible.models.Group;
import NetMind.amigoinvisible.utils.GroupUtils;

/**
 * Fragmento encargado de mostrar en un RecyclerView todos los grupos a los que pertenece el usuario actual.
 * Utiliza Firebase Firestore para recibir actualizaciones en tiempo real y mantener sincronizada la lista.
 */
public class ViewGroupsFragment extends Fragment {

    private FirebaseFirestore baseDatos;
    private GroupListAdapter adaptadorGrupos;
    private final List<Group> listaDatosGrupos = new ArrayList<>();
    private ListenerRegistration listenerGrupos;
    private RecyclerView listaGrupos;

    /**
     * Infla la vista del fragmento y carga los grupos desde Firebase.
     *
     * @param inflater           LayoutInflater para inflar la vista.
     * @param container          Contenedor padre.
     * @param savedInstanceState Estado guardado de la instancia (si existe).
     * @return Vista creada del fragmento.
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View vista = inflater.inflate(R.layout.fragment_view_groups, container, false);

        inicializarRecyclerView(vista);

        baseDatos = FirebaseFirestore.getInstance();
        cargarGruposDelUsuario();

        return vista;
    }

    /**
     * Configura el RecyclerView y su adaptador para visualizar los grupos del usuario.
     *
     * @param vista Vista raíz del fragmento.
     */
    private void inicializarRecyclerView(View vista) {
        listaGrupos = vista.findViewById(R.id.recyclerGroups);
        listaGrupos.setLayoutManager(new LinearLayoutManager(getContext()));
        adaptadorGrupos = new GroupListAdapter(listaDatosGrupos);
        listaGrupos.setAdapter(adaptadorGrupos);
    }
    /**
     * Obtiene y escucha en tiempo real los grupos en los que el usuario autenticado está incluido.
     * Actualiza la interfaz dinámicamente al detectar cambios.
     */
    private void cargarGruposDelUsuario() {
        FirebaseUser usuario = FirebaseAuth.getInstance().getCurrentUser();
        if (usuario == null) {
            Log.w("ViewGroups", "Usuario no autenticado.");
            return;
        }

        String idUsuario = usuario.getUid();

        listenerGrupos = GroupUtils.escucharGruposDeUsuario(
                idUsuario,
                grupos -> {
                    listaDatosGrupos.clear();
                    listaDatosGrupos.addAll(grupos);
                    adaptadorGrupos.notifyDataSetChanged();
                },
                error -> Log.e("ViewGroups", "Error al obtener grupos", error)
        );
    }

    /**
     * Detiene el listener de Firestore cuando se destruye la vista del fragmento
     * para evitar fugas de memoria y llamadas innecesarias.
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (listenerGrupos != null) {
            listenerGrupos.remove();
            listenerGrupos = null;
        }
    }
}
