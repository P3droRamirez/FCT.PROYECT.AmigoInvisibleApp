package NetMind.amigoinvisible.models;
/**
 * Modelo que representa un mensaje dentro del chat del grupo.
 * Cada mensaje contiene el contenido, el remitente, un timestamp y
 * un indicador de anonimato.
 */
public class Message {
    private String senderId;
    private String content;
    private com.google.firebase.Timestamp timestamp;

    private boolean isAnonymous;

    /**
     * Constructor vacío requerido por Firestore.
     */
    public Message() {
    }
    /**
     * Constructor completo para crear un nuevo mensaje.
     *
     * @param senderId    ID del usuario que envía el mensaje.
     * @param content     Texto del mensaje.
     * @param timestamp   Fecha y hora en que se envió.
     * @param isAnonymous Si el mensaje debe mostrarse como anónimo.
     */
    public Message(String senderId, String content, com.google.firebase.Timestamp timestamp, boolean isAnonymous) {
        this.senderId = senderId;
        this.content = content;
        this.timestamp = timestamp;
        this.isAnonymous = isAnonymous;
    }

    // Getters y Setters
    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public boolean isAnonymous() { return isAnonymous; }
    public void setAnonymous(boolean isAnonymous) { this.isAnonymous = isAnonymous; }
    public com.google.firebase.Timestamp getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(com.google.firebase.Timestamp timestamp) {
        this.timestamp = timestamp;
    }

}
