package NetMind.amigoinvisible.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.activities.WelcomeActivity;

/**
 * Clase utilitaria para gestionar autenticación y perfil de usuario
 * Incluye funciones para login, registro, verificación de email,
 * almacenamiento de imagen y obtención de token FCM.
 */
public class UsuarioUtils {

    private static final String TAG = "UsuarioUtils";
    // Campos Firestore para consistencia
    private static final String FIELD_NOMBRE = "nombre";
    private static final String FIELD_CORREO = "correo";
    private static final String FIELD_FOTO = "foto";

    /**
     * Obtiene el token FCM del dispositivo actual y lo muestra por log.
     * Este token se puede usar para enviar notificaciones personalizadas.
     *
     * @param activity Actividad desde donde se realiza la petición (para logs y recursos).
     */
    public static void obtenerTokenFirebase(Activity activity) {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Log.d(TAG, "Token FCM: " + task.getResult());
            } else {
                Log.w(TAG, activity.getString(R.string.error_obtener_token), task.getException());
            }
        });
    }

    /**
     * Autentica al usuario en Firebase usando credenciales externas (por ejemplo, Google).
     * En caso de éxito, llama a {@link #verificarUsuario(FirebaseUser, Activity, Runnable)} para completar el proceso.
     *
     * @param credential Credencial externa (obtenida de Google u otro proveedor).
     * @param activity   Actividad actual para contexto.
     * @param onSuccess  Acción a ejecutar si el login es exitoso.
     */
    public static void autenticarConFirebase(AuthCredential credential, Activity activity, Runnable onSuccess) {
        FirebaseAuth auth = FirebaseAuth.getInstance();

        auth.signInWithCredential(credential).addOnCompleteListener(activity, task -> {
            if (task.isSuccessful() && auth.getCurrentUser() != null) {
                verificarUsuario(auth.getCurrentUser(), activity, onSuccess);
            } else {
                Toast.makeText(activity, activity.getString(R.string.mensaje_error_autenticacion_firebase), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Verifica si el usuario ya está en Firestore. Si no, lo registra.
     * También empareja su correo con posibles invitaciones.
     *
     * @param usuario   Usuario autenticado
     * @param activity  Actividad actual (para navegación y toasts)
     * @param onSuccess Acción a ejecutar cuando termine (pasar a pantalla principal)
     */
    public static void verificarUsuario(@NonNull FirebaseUser usuario, Activity activity, Runnable onSuccess) {
        usuario.reload().addOnSuccessListener(aVoid -> {
            if (!usuario.isEmailVerified()) {
                Toast.makeText(activity, activity.getString(R.string.mensaje_verificar_correo), Toast.LENGTH_LONG).show();
                FirebaseAuth.getInstance().signOut();
                return;
            }

            FirebaseFirestore db = FirebaseFirestore.getInstance();
            DocumentReference refUsuario = db.collection("users").document(usuario.getUid());

            refUsuario.get().addOnSuccessListener(document -> {
                // Crear documento si no existe
                if (!document.exists()) {
                    Map<String, Object> nuevoUsuario = new HashMap<>();
                    nuevoUsuario.put(FIELD_NOMBRE, usuario.getDisplayName() != null ? usuario.getDisplayName() : "");
                    nuevoUsuario.put(FIELD_CORREO, usuario.getEmail());
                    nuevoUsuario.put(FIELD_FOTO, usuario.getPhotoUrl() != null ? usuario.getPhotoUrl().toString() : "");

                    refUsuario.set(nuevoUsuario)
                            .addOnSuccessListener(aVoid2 -> Log.d(TAG, activity.getString(R.string.mensaje_registro_exitoso)))
                            .addOnFailureListener(e -> Log.e(TAG, activity.getString(R.string.mensaje_error_firestore), e));
                }
                // Guardar token de notificaciones FCM
                FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
                    if (token != null && !token.isEmpty()) {
                        refUsuario.update("fcmToken", token)
                                .addOnSuccessListener(aVoid3 -> Log.d(TAG, "✅ Token FCM guardado"))
                                .addOnFailureListener(e -> Log.e(TAG, "❌ Error al guardar token FCM", e));
                    }
                });
                // Asociar al usuario con posibles grupos (invitaciones)
                FirebaseUtils.emparejarUsuarioConGrupos(usuario, onSuccess);
            }).addOnFailureListener(e -> {
                Toast.makeText(activity, activity.getString(R.string.mensaje_error_firestore), Toast.LENGTH_SHORT).show();
                Log.e(TAG, activity.getString(R.string.mensaje_error_firestore), e);
            });
        });
    }

    /**
     * Sube una imagen de perfil al almacenamiento de Firebase y actualiza el perfil del usuario.
     * También actualiza la URL en el documento del usuario en Firestore.
     *
     * @param usuario       Usuario autenticado.
     * @param uriImagen     URI de la imagen seleccionada por el usuario.
     * @param context       Contexto para mostrar mensajes y cargar recursos.
     * @param destinoImagen ImageView donde se mostrará la imagen una vez subida.
     */
    public static void actualizarFotoPerfil(@NonNull FirebaseUser usuario, @NonNull Uri uriImagen, @NonNull Context context, @NonNull ImageView destinoImagen) {

        StorageReference referenciaAlmacen = FirebaseStorage.getInstance().getReference("profile_pictures").child(usuario.getUid() + "/profile.jpg");

        referenciaAlmacen.putFile(uriImagen).addOnSuccessListener(taskSnapshot -> referenciaAlmacen.getDownloadUrl().addOnSuccessListener(uriDescargada -> {

            // Actualizar perfil en FirebaseAuth
            UserProfileChangeRequest actualizarPerfil = new UserProfileChangeRequest.Builder().setPhotoUri(uriDescargada).build();

            usuario.updateProfile(actualizarPerfil).addOnSuccessListener(unused -> {
                Glide.with(context).load(uriDescargada).circleCrop().into(destinoImagen);
                Toast.makeText(context, context.getString(R.string.foto_actualizada), Toast.LENGTH_SHORT).show();

                // Actualizar URL en Firestore
                Map<String, Object> datos = new HashMap<>();
                datos.put("photoUrl", uriDescargada.toString());

                FirebaseFirestore.getInstance().collection("users").document(usuario.getUid()).update(datos);
            });
        })).addOnFailureListener(e -> Toast.makeText(context, context.getString(R.string.error_subida_imagen, e.getMessage()), Toast.LENGTH_SHORT).show());
    }

    /**
     * Registra un nuevo usuario en Firebase Authentication y crea su documento en Firestore.
     * También configura su nombre y redirige a la pantalla de bienvenida.
     *
     * @param nombre     Nombre introducido por el usuario.
     * @param correo     Correo electrónico introducido.
     * @param contrasena Contraseña introducida.
     * @param activity   Actividad desde donde se realiza el registro.
     */
    public static void registrarNuevoUsuario(String nombre, String correo, String contrasena, Activity activity) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        auth.createUserWithEmailAndPassword(correo, contrasena).addOnSuccessListener(authResult -> {
            FirebaseUser usuario = auth.getCurrentUser();
            if (usuario != null) {
                // Actualizar nombre del usuario
                UserProfileChangeRequest actualizarPerfil = new UserProfileChangeRequest.Builder()
                        .setDisplayName(nombre)
                        .build();

                usuario.updateProfile(actualizarPerfil).addOnCompleteListener(profileTask -> {
                    String nombreFinal = profileTask.isSuccessful() ? nombre : "";
                    if (!profileTask.isSuccessful()) {
                        Toast.makeText(activity, R.string.mensaje_error_actualizar_nombre, Toast.LENGTH_SHORT).show();
                    }

                    // Crear documento en Firestore
                    Map<String, Object> datos = new HashMap<>();
                    datos.put("displayName", nombreFinal);
                    datos.put("email", usuario.getEmail());
                    datos.put("photoUrl", null);

                    db.collection("users").document(usuario.getUid()).set(datos)
                            .addOnSuccessListener(unused -> {
                                // Enviar verificación por correo
                                usuario.sendEmailVerification()
                                        .addOnCompleteListener(emailTask -> {
                                            if (emailTask.isSuccessful()) {
                                                Toast.makeText(activity, activity.getString(R.string.mensaje_verificacion_enviada), Toast.LENGTH_LONG).show();
                                                // Cierra sesión hasta que el usuario verifique el correo
                                                auth.signOut();
                                                activity.finish(); // Cierra la actividad de registro y vuelve al login
                                            } else {
                                                Toast.makeText(activity, activity.getString(R.string.mensaje_error_enviar_verificacion), Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(activity, R.string.mensaje_error_firestore, Toast.LENGTH_SHORT).show();
                                Log.e("UsuarioUtils", "Error Firestore", e);
                            });
                });
            }
        }).addOnFailureListener(e -> {
            String mensaje = e.getMessage();
            if (mensaje != null && mensaje.contains("PASSWORD_DOES_NOT_MEET_REQUIREMENTS")) {
                Toast.makeText(activity, activity.getString(R.string.mensaje_requisitos_contrasena), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(activity,
                        activity.getString(R.string.mensaje_error_registro, mensaje),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

}
