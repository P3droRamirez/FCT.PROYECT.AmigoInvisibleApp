package NetMind.amigoinvisible.activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import NetMind.amigoinvisible.utils.GroupUtils;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.MemberAdapter;
import NetMind.amigoinvisible.models.Member;
/**
 * Actividad encargada de mostrar los detalles de un grupo de Amigo Invisible.
 * Permite al usuario ver y gestionar los participantes, realizar el sorteo, acceder al chat,
 * modificar la imagen del grupo (si es propietario), y acceder a su persona asignada.
 */
public class GroupDetailActivity extends AppCompatActivity {

    // UI
    private TextView textoNombreGrupo, textoPresupuestoGrupo, textoContadorGrupo;
    private ImageView imageGroup;
    private MaterialButton botonAgregarMiembro, botonSortear, botonChat, botonWishlist, botonVerAsignado;
    private RecyclerView recyclerMiembros;

    // Firebase
    private FirebaseFirestore baseDatos;
    private FirebaseAuth auth;
    private ListenerRegistration listenerMiembros;

    // Variables
    private String idGrupo;
    private String ownerId;
    private boolean sePuedeAgregar = true;
    private static final int PICK_IMAGE_REQUEST = 102;
    private Uri nuevaImagenUri;
    private MemberAdapter adaptadorMiembros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_detail);

        // Inicializa Firebase y obtiene el ID del grupo
        baseDatos = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        idGrupo = getIntent().getStringExtra("groupId");

        inicializarUI();
        configurarBotones();
        verificarAsignado();
        cargarInformacionGrupo();
        configurarRecyclerView();
    }

    /**
     * Inicializa todos los elementos visuales de la interfaz como TextViews, ImageView, RecyclerView y botones
     */
    private void inicializarUI() {
        textoNombreGrupo = findViewById(R.id.textGroupNameDetail);
        textoPresupuestoGrupo = findViewById(R.id.textGroupBudgetDetail);
        textoContadorGrupo = findViewById(R.id.textGroupCountDetail);
        imageGroup = findViewById(R.id.imageGroupDetail);
        botonAgregarMiembro = findViewById(R.id.btnAddMember);
        botonSortear = findViewById(R.id.btnSort);
        botonChat = findViewById(R.id.btnChat);
        botonWishlist = findViewById(R.id.btnWishlist);
        botonVerAsignado = findViewById(R.id.btnViewAssigned);
        recyclerMiembros = findViewById(R.id.recyclerGroupMembersDetail);

        botonSortear.setVisibility(View.GONE);
        botonVerAsignado.setVisibility(View.GONE);
    }

    /**
     * Establece los listeners de los botones de acción disponibles según el rol del usuario (miembro o propietario)
     */
    private void configurarBotones() {
        botonAgregarMiembro.setOnClickListener(v -> verificarYAgregarMiembro());

        botonSortear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_titulo_confirmar_sorteo))
                .setMessage(getString(R.string.dialog_mensaje_confirmar_sorteo))
                .setPositiveButton(getString(R.string.dialog_boton_realizar), (dialog, which) -> realizarSorteo())
                .setNegativeButton(getString(R.string.dialog_boton_cancelar), null)
                .show());

        botonChat.setOnClickListener(v -> iniciarActividad(GroupChatActivity.class));
        botonWishlist.setOnClickListener(v -> iniciarActividad(WishlistActivity.class));

        imageGroup.setOnClickListener(v -> {
            if (esPropietario()) seleccionarNuevaImagen();
            else Toast.makeText(this, R.string.mensaje_solo_propietario_puede_cambiar_imagen, Toast.LENGTH_SHORT).show();
        });

        botonVerAsignado.setOnClickListener(v -> mostrarAsignado());
    }

    /**
     * Inicia una actividad pasando el ID del grupo
     */
    private void iniciarActividad(Class<?> clase) {
        Intent intent = new Intent(this, clase);
        intent.putExtra("groupId", idGrupo);
        startActivity(intent);
    }

    /**
     * Ejecuta la lógica de sorteo del Amigo Invisible con feedback visual mediante un ProgressDialog
     */
    private void realizarSorteo() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.dialog_realizando_sorteo));
        progressDialog.setCancelable(false);
        progressDialog.show();

        GroupUtils.realizarSorteo(
                idGrupo,
                () -> runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, R.string.mensaje_sorteo_exito, Toast.LENGTH_LONG).show();
                    botonVerAsignado.setVisibility(View.VISIBLE);
                }),
                error -> runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, getString(R.string.mensaje_sorteo_error, error), Toast.LENGTH_LONG).show();
                })
        );
    }

    /**
     * Verifica si el usuario ya tiene una persona asignada y muestra el botón correspondiente
     */
    private void verificarAsignado() {
        String uid = auth.getCurrentUser().getUid();
        baseDatos.collection("groups")
                .document(idGrupo)
                .collection("members")
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.contains("assignedTo")) {
                        botonVerAsignado.setVisibility(View.VISIBLE);
                    }
                });
    }

    /**
     * Obtiene los datos del amigo invisible asignado al usuario y lanza AssignedPersonActivity
     */
    private void mostrarAsignado() {
        String uid = auth.getCurrentUser().getUid();
        baseDatos.collection("groups").document(idGrupo).collection("members").document(uid)
                .get()
                .addOnSuccessListener(document -> {
                    String assignedId = document.getString("assignedTo");
                    if (assignedId != null && !assignedId.isEmpty()) {
                        Intent intent = new Intent(this, AssignedPersonActivity.class);
                        intent.putExtra("groupId", idGrupo);
                        intent.putExtra("assignedId", assignedId);
                        startActivity(intent);
                    } else {
                        Toast.makeText(this, R.string.no_asignado_todavia, Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, R.string.error_datos_asignado, Toast.LENGTH_SHORT).show());
    }

    /**
     *  Verifica si aún hay cupo para nuevos miembros y lanza AddMemberActivity si procede
     */
    private void verificarYAgregarMiembro() {
        baseDatos.collection("groups").document(idGrupo).collection("members")
                .get()
                .addOnSuccessListener(snapshots -> {
                    int cantidadActual = snapshots.size();
                    baseDatos.collection("groups").document(idGrupo)
                            .get()
                            .addOnSuccessListener(document -> {
                                Long maximo = document.getLong("maxParticipants");
                                if (maximo != null && cantidadActual >= maximo) {
                                    Toast.makeText(this, R.string.mensaje_grupo_completo, Toast.LENGTH_SHORT).show();
                                } else {
                                    iniciarActividad(AddMemberActivity.class);
                                }
                            });
                });
    }

    /**
     * Carga desde Firestore el nombre, presupuesto, imagen y miembros del grupo
     */
    private void cargarInformacionGrupo() {
        baseDatos.collection("groups").document(idGrupo)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        ownerId = document.getString("owner");
                        String nombre = document.getString("name");
                        Double presupuesto = document.getDouble("budgetLimit");
                        Long maxMiembros = document.getLong("maxParticipants");
                        String imageUrl = document.getString("imageUrl");

                        textoNombreGrupo.setText(getString(R.string.text_group_name_placeholder, nombre));
                        textoPresupuestoGrupo.setText(getString(R.string.text_group_budget_placeholder, presupuesto != null ? presupuesto : 0));

                        cargarImagenGrupo(imageUrl);
                        configurarVisibilidadBotonSorteo();

                        // Listener a cambios en miembros
                        listenerMiembros = baseDatos.collection("groups").document(idGrupo).collection("members")
                                .addSnapshotListener((snapshots, error) -> {
                                    if (error != null || snapshots == null) return;
                                    int cantidad = snapshots.size();
                                    textoContadorGrupo.setText(getString(R.string.text_group_count_placeholder, cantidad, maxMiembros != null ? maxMiembros : 0));
                                    sePuedeAgregar = maxMiembros == null || cantidad < maxMiembros;
                                    botonAgregarMiembro.setAlpha(sePuedeAgregar ? 1f : 0.5f);
                                });
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, R.string.error_cargar_datos_grupo, Toast.LENGTH_SHORT).show());
    }

    /**
     * Carga la imagen del grupo desde Firebase Storage usando Glide o pone una por defecto.
     * */
    private void cargarImagenGrupo(String url) {
        if (url != null && !url.isEmpty()) {
            Glide.with(this).load(url).placeholder(R.drawable.ic_groups).into(imageGroup);
        } else {
            imageGroup.setImageResource(R.drawable.ic_groups);
        }
    }

    /**
     * Solo muestra el botón de sorteo si el usuario es el propietario del grupo
     */
    private void configurarVisibilidadBotonSorteo() {
        if (esPropietario()) {
            botonSortear.setVisibility(View.VISIBLE);
        } else {
            botonSortear.setVisibility(View.GONE);
        }
    }

    /**
     * Devuelve true si el UID actual coincide con el del propietario del grupo
     */
    private boolean esPropietario() {
        return auth.getCurrentUser() != null && auth.getCurrentUser().getUid().equals(ownerId);
    }

    /**
     * Abre selector de imagen y lanza un intent para que el propietario elija una nueva imagen del grupo.
     */
    private void seleccionarNuevaImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    /**
     * Sube la imagen seleccionada a Firebase Storage y actualiza Firestore con la nueva URL
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            nuevaImagenUri = data.getData();
            StorageReference storageRef = FirebaseStorage.getInstance().getReference("group_images/" + idGrupo + ".jpg");

            storageRef.putFile(nuevaImagenUri)
                    .addOnSuccessListener(taskSnapshot ->
                            storageRef.getDownloadUrl().addOnSuccessListener(uri ->
                                    baseDatos.collection("groups").document(idGrupo)
                                            .update("imageUrl", uri.toString())
                                            .addOnSuccessListener(unused -> {
                                                Glide.with(this)
                                                        .load(uri)
                                                        .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                                                        .skipMemoryCache(true)
                                                        .placeholder(R.drawable.ic_groups)
                                                        .into(imageGroup);
                                                Toast.makeText(this, R.string.mensaje_imagen_actualizada, Toast.LENGTH_SHORT).show();
                                            })))
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Error al subir la nueva imagen", Toast.LENGTH_SHORT).show());
        }
    }

    /**
     * Configura el RecyclerView para mostrar la lista de miembros usando FirestoreRecyclerAdapter
     */
    private void configurarRecyclerView() {
        Query consulta = baseDatos.collection("groups").document(idGrupo).collection("members");
        FirestoreRecyclerOptions<Member> opciones = new FirestoreRecyclerOptions.Builder<Member>()
                .setQuery(consulta, Member.class)
                .setLifecycleOwner(this)
                .build();

        adaptadorMiembros = new MemberAdapter(opciones, idGrupo);
        recyclerMiembros.setLayoutManager(new LinearLayoutManager(this));
        recyclerMiembros.setAdapter(adaptadorMiembros);
    }

    /**
     * Ciclo de vida: al reanudar, reinicia el adaptador
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (adaptadorMiembros != null) {
            recyclerMiembros.setAdapter(null);
            adaptadorMiembros.stopListening();
            adaptadorMiembros.startListening();
            recyclerMiembros.setAdapter(adaptadorMiembros);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (adaptadorMiembros != null) adaptadorMiembros.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (adaptadorMiembros != null) adaptadorMiembros.stopListening();
        if (listenerMiembros != null) {
            listenerMiembros.remove();
            listenerMiembros = null;
        }
    }
}
