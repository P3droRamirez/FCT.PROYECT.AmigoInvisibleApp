package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.MessageAdapter;
import NetMind.amigoinvisible.models.Message;

/**
 * Actividad encargada de gestionar el chat grupal del Amigo Invisible.
 * Permite a los usuarios enviar mensajes anónimos y visualizar la conversación en tiempo real.
 * Utiliza Firebase Firestore como backend para almacenar y escuchar los mensajes.
 */
public class GroupChatActivity extends AppCompatActivity {

    // Instancia de Firestore para acceso a base de datos
    private FirebaseFirestore db;
    // Identificador del grupo al que pertenece el chat
    private String groupId;
    // Componentes de interfaz
    private RecyclerView recyclerView;
    private MessageAdapter messageAdapter;
    private final List<Message> messagesList = new ArrayList<>();
    private EditText messageInput;
    private Button sendButton;

    /**
     * Metodo de inicialización de la actividad.
     * Obtiene el ID del grupo, configura la interfaz y la conexión a Firebase.
     *
     * @param savedInstanceState estado guardado previamente (no usado aquí).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);

        // Obtener ID del grupo desde el intent
        groupId = getIntent().getStringExtra("groupId");
        if (groupId == null) {
            Toast.makeText(this, getString(R.string.error_group_id_missing), Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        inicializarFirebase();
        inicializarUI();
        cargarMensajes();
        configurarBotonEnviar();
    }

    /**
     * Inicializa la instancia de Firebase Firestore.
     */
    private void inicializarFirebase() {
        db = FirebaseFirestore.getInstance();
    }

    /**
     * Configura los elementos visuales de la interfaz:
     * RecyclerView, campo de texto y botón de envío.
     * También asigna el adaptador y el layout manager.
     */
    private void inicializarUI() {
        recyclerView = findViewById(R.id.recyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);

        messageAdapter = new MessageAdapter(messagesList);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true); // Para que empiece mostrando los últimos mensajes

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(messageAdapter);
    }

    /**
     * Carga y escucha en tiempo real los mensajes del grupo desde Firestore.
     * Cada cambio se refleja automáticamente en el RecyclerView.
     */
    private void cargarMensajes() {
        CollectionReference mensajesRef = db.collection("groups")
                .document(groupId)
                .collection("messages");

        mensajesRef.orderBy("timestamp")
                .addSnapshotListener((QuerySnapshot value, FirebaseFirestoreException error) -> {
                    if (error != null || value == null) return;

                    messagesList.clear();
                    for (DocumentSnapshot doc : value) {
                        Message message = doc.toObject(Message.class);
                        if (message != null) messagesList.add(message);
                    }

                    messageAdapter.notifyDataSetChanged();
                    recyclerView.scrollToPosition(messagesList.size() - 1);
                });
    }

    /**
     * Configura el botón de envío para capturar el mensaje del usuario,
     * limpiarlo y enviarlo a Firestore si no está vacío.
     */
    private void configurarBotonEnviar() {
        sendButton.setOnClickListener(v -> {
            String contenido = messageInput.getText().toString().trim();
            if (!contenido.isEmpty()) {
                enviarMensaje(contenido);
                messageInput.setText("");
            }
        });
    }

    /**
     * Envia un nuevo mensaje de texto al chat.
     * El mensaje se almacena en Firestore bajo la colección del grupo actual.
     *
     * @param contenido Texto del mensaje introducido por el usuario.
     */
    private void enviarMensaje(String contenido) {
        String senderId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        com.google.firebase.Timestamp timestamp = com.google.firebase.Timestamp.now();

        Message nuevoMensaje = new Message(senderId, contenido, timestamp, true);

        db.collection("groups")
                .document(groupId)
                .collection("messages")
                .add(nuevoMensaje)
                .addOnFailureListener(e ->
                        Toast.makeText(this, getString(R.string.error_envio_mensaje), Toast.LENGTH_SHORT).show());
    }
}
