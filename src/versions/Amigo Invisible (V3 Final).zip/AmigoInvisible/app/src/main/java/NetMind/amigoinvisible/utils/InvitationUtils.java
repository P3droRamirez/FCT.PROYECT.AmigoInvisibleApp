package NetMind.amigoinvisible.utils;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;

import java.util.*;
import java.util.function.Consumer;

import NetMind.amigoinvisible.models.Invitation;

/**
 * Clase utilitaria para manejar las invitaciones a grupos del usuario.
 * Ofrece funciones de escucha en tiempo real, aceptación y rechazo.
 */
public class InvitationUtils {
    private static final FirebaseFirestore db = FirebaseFirestore.getInstance();

    /**
     * Escucha en tiempo real las invitaciones para un usuario dado basado en su correo.
     * Cada invitación se representa como un documento en la subcolección "members" con el ID = correo.
     *
     * @param emailUsuario Email del usuario autenticado
     * @param onRecibidas  Callback con lista de invitaciones encontradas
     */
    public static ListenerRegistration escucharInvitaciones(@NonNull String emailUsuario, @NonNull Consumer<List<Invitation>> onRecibidas) {
        return db.collection("groups").addSnapshotListener((snapshot, error) -> {
            if (error != null || snapshot == null) {
                onRecibidas.accept(Collections.emptyList());  // Notifica vacío ante error
                return;
            }

            List<Invitation> invitaciones = new ArrayList<>();
            List<DocumentSnapshot> documentos = snapshot.getDocuments();

            if (documentos.isEmpty()) {
                onRecibidas.accept(invitaciones);  // Vacío, sin grupos
                return;
            }

            final int totalGrupos = documentos.size();
            final int[] procesados = {0};

            for (DocumentSnapshot grupo : documentos) {
                String groupId = grupo.getId();
                String groupName = grupo.getString("name");

                grupo.getReference().collection("members").document(emailUsuario).get().addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        invitaciones.add(new Invitation(groupId, groupName, doc.getData()));
                    }
                }).addOnCompleteListener(task -> {
                    procesados[0]++;
                    if (procesados[0] == totalGrupos) {
                        // Se han terminado de procesar todos los grupos
                        onRecibidas.accept(invitaciones);
                    }
                });
            }
        });
    }


    /**
     * Acepta una invitación existente: transfiere los datos del miembro desde su correo a su UID.
     * También actualiza el array "members" del grupo.
     *
     * @param invitacion Objeto Invitation con la info del grupo.
     * @param usuario    Usuario autenticado que acepta.
     * @param onSuccess  Acción a ejecutar si se acepta exitosamente.
     * @param onError    Callback con mensaje de error en caso de fallo.
     */
    public static void aceptarInvitacion(@NonNull Invitation invitacion, @NonNull FirebaseUser usuario, @NonNull Runnable onSuccess, @NonNull Consumer<String> onError) {
        String uid = usuario.getUid();
        DocumentReference grupoRef = db.collection("groups").document(invitacion.getGroupId());

        grupoRef.get().addOnSuccessListener(grupo -> {
            List<String> miembros = (List<String>) grupo.get("members");
            if (miembros == null) miembros = new ArrayList<>();

            if (!miembros.contains(uid)) {
                miembros.add(uid);
                grupoRef.update("members", miembros).addOnSuccessListener(unused -> {
                    grupoRef.collection("members").document(uid).set(invitacion.getDatosMiembro()).addOnSuccessListener(ignored -> {
                        grupoRef.collection("members").document(usuario.getEmail()).delete();

                        onSuccess.run();
                    }).addOnFailureListener(e -> onError.accept("Error al guardar nuevo miembro: " + e.getMessage()));
                });
            } else {
                onError.accept("Ya eres parte del grupo.");
            }
        }).addOnFailureListener(e -> onError.accept("Error al cargar grupo: " + e.getMessage()));
    }

    /**
     * Rechaza una invitación eliminando el documento asociado al correo en la subcolección "members".
     *
     * @param invitacion   Objeto Invitation con la info del grupo.
     * @param emailUsuario Correo del usuario que rechaza.
     * @param onSuccess    Acción tras la eliminación exitosa.
     * @param onError      Callback con mensaje si ocurre un fallo.
     */
    public static void rechazarInvitacion(@NonNull Invitation invitacion, @NonNull String emailUsuario, @NonNull Runnable onSuccess, @NonNull Consumer<String> onError) {
        db.collection("groups").document(invitacion.getGroupId()).collection("members").document(emailUsuario).delete().addOnSuccessListener(unused -> onSuccess.run()).addOnFailureListener(e -> onError.accept("Error al rechazar invitación: " + e.getMessage()));
    }
}
