package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.MemberAdapter;
import NetMind.amigoinvisible.models.Member;

/**
 * Actividad que permite al usuario añadir participantes manualmente a un grupo.
 * También muestra los miembros añadidos usando un RecyclerView conectado a Firestore.
 */
public class AddMemberActivity extends AppCompatActivity {

    private EditText campoNombre, campoCorreo;
    private FirebaseFirestore baseDatos;
    private FirebaseAuth auth;
    private String idGrupo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_member);

        baseDatos = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        idGrupo = getIntent().getStringExtra("groupId");

        campoNombre = findViewById(R.id.editTextMemberName);
        campoCorreo = findViewById(R.id.editTextMemberEmail);

        findViewById(R.id.btnAddMember).setOnClickListener(v -> aniadirParticipantes());

        RecyclerView recyclerMiembros = findViewById(R.id.recyclerViewMembers);
        recyclerMiembros.setLayoutManager(new LinearLayoutManager(this));

        FirestoreRecyclerOptions<Member> opciones = new FirestoreRecyclerOptions.Builder<Member>()
                .setQuery(baseDatos.collection("groups").document(idGrupo).collection("members"), Member.class)
                .setLifecycleOwner(this)
                .build();

        MemberAdapter adaptador = new MemberAdapter(opciones, idGrupo);
        recyclerMiembros.setAdapter(adaptador);
    }

    /**
     * Añade un nuevo participante a la subcolección 'members' del grupo actual,
     * validando que no supere el máximo de participantes definido.
     */
    private void aniadirParticipantes() {
        String nombre = campoNombre.getText().toString().trim();
        String correo = campoCorreo.getText().toString().trim();

        if (TextUtils.isEmpty(nombre) || TextUtils.isEmpty(correo)) {
            Toast.makeText(this, R.string.mensaje_campos_obligatorios, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!validarCorreo(correo)) {
            Toast.makeText(this, R.string.mensaje_correo_invalido, Toast.LENGTH_SHORT).show();
            return;
        }

        baseDatos.collection("groups").document(idGrupo).get()
                .addOnSuccessListener(grupo -> {
                    Long maximo = grupo.getLong("maxParticipants");
                    List<String> miembros = (List<String>) grupo.get("members");

                    if (miembros != null && maximo != null && miembros.size() >= maximo) {
                        Toast.makeText(this, R.string.mensaje_grupo_completo, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Map<String, Object> datosMiembro = new HashMap<>();
                    datosMiembro.put("name", nombre);
                    datosMiembro.put("email", correo);

                    // Solo se guarda la invitación con el correo, sin modificar el array de miembros
                    baseDatos.collection("groups").document(idGrupo)
                            .collection("members").document(correo)
                            .set(datosMiembro)
                            .addOnSuccessListener(unused -> limpiarCamposYMostrar())
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "Error al añadir miembro: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error al verificar límite de grupo: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    /**
     * Limpia los campos de texto y muestra un mensaje de confirmación.
     */
    private void limpiarCamposYMostrar() {
        Toast.makeText(this, R.string.mensaje_participante_añadido, Toast.LENGTH_SHORT).show();
        campoNombre.setText("");
        campoCorreo.setText("");
    }

    /**
     * Valida que el correo tenga un formato válido usando una expresión regular.
     *
     * @param correo Dirección de correo electrónico introducida por el usuario.
     * @return true si el formato es válido, false en caso contrario.
     */
    private boolean validarCorreo(String correo) {
        String patronCorreo = "[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}";
        return correo.matches(patronCorreo);
    }
}
