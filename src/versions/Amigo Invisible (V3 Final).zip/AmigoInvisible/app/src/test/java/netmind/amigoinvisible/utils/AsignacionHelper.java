package netmind.amigoinvisible.utils;

import java.util.*;
import NetMind.amigoinvisible.models.Member;
/**
 * Clase auxiliar que contiene lógica para generar asignaciones del juego Amigo Invisible.
 * <p>
 * Garantiza que:
 * <ul>
 *     <li>Nadie se autoasigne a sí mismo.</li>
 *     <li>Se respeten las exclusiones individuales definidas por cada miembro.</li>
 * </ul>
 * </p>
 */
public class AsignacionHelper {

    /**
     * Genera asignaciones de Amigo Invisible asegurando:
     * <ul>
     *     <li>Sin autoasignaciones (nadie se asigna a sí mismo).</li>
     *     <li>Respetar restricciones de exclusión definidas en cada {@link Member}.</li>
     * </ul>
     *
     * @param miembros lista de miembros del grupo con sus restricciones (exclusiones)
     * @return mapa donde cada clave (ID del asignador) apunta al ID del asignado,
     *         o {@code null} si no se puede generar una asignación válida tras varios intentos
     */
    public static Map<String, String> generarAsignaciones(List<Member> miembros) {
        List<String> asignadores = new ArrayList<>();
        Map<String, Member> mapaMiembros = new HashMap<>();

        // Crear lista de IDs y mapa para acceso rápido
        for (Member m : miembros) {
            asignadores.add(m.getId());
            mapaMiembros.put(m.getId(), m);
        }
        Random random = new Random();
        // Repetir hasta 10 intentos para encontrar una asignación válida
        for (int intento = 0; intento < 10; intento++) {
            List<String> receptores = new ArrayList<>(asignadores);
            Collections.shuffle(receptores, random);
            boolean valido = true;
            Map<String, String> resultado = new HashMap<>();
            for (int i = 0; i < asignadores.size(); i++) {
                String asignador = asignadores.get(i);
                String receptor = receptores.get(i);
                // Verificar autoasignación
                if (asignador.equals(receptor)) {
                    valido = false;
                    break;
                }
                // Verificar exclusión personalizada
                Member m = mapaMiembros.get(asignador);
                if (m.getExcludedUserIds() != null && m.getExcludedUserIds().contains(receptor)) {
                    valido = false;
                    break;
                }
                resultado.put(asignador, receptor);
            }
            // Si la asignación es válida, devolverla
            if (valido) return resultado;
        }

        // Si no se encontró una asignación válida tras varios intentos
        return null;
    }
}
