package netmind.amigoinvisible.utils;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.*;
import NetMind.amigoinvisible.models.Member;

/**
 * Clase de pruebas unitarias para {@link AsignacionHelper}.
 * <p>Valida que la lógica de asignación:
 * <ul>
 *     <li>Evite autoasignaciones</li>
 *     <li>Respete restricciones personalizadas</li>
 *     <li>Detecte situaciones sin solución posible</li>
 * </ul>
 * </p>
 */
public class AsignacionHelperTest {

    /**
     * Prueba que genera asignaciones válidas cuando no existen exclusiones.
     * <p>
     * Condiciones verificadas:
     * <ul>
     *     <li>Se generan asignaciones para todos los miembros.</li>
     *     <li>Ningún miembro se asigna a sí mismo.</li>
     * </ul>
     */
    @Test
    public void testAsignacionesValidas() {
        List<Member> miembros = Arrays.asList(
                new Member("1", "Ana", "ana@mail.com", List.of()),
                new Member("2", "Luis", "luis@mail.com", List.of()),
                new Member("3", "Pedro", "pedro@mail.com", List.of())
        );

        Map<String, String> asignaciones = AsignacionHelper.generarAsignaciones(miembros);
        assertNotNull("La asignación no debe ser null", asignaciones);
        assertEquals("Debe haber una asignación por miembro", 3, asignaciones.size());

        for (Map.Entry<String, String> entry : asignaciones.entrySet()) {
            assertNotEquals("No debe haber autoasignaciones", entry.getKey(), entry.getValue());
        }
    }

    /**
     * Prueba que se respetan las exclusiones definidas por los miembros.
     * <p>
     * Caso específico: Ana excluye a Luis. La prueba comprueba que no se le asigna.
     */
    @Test
    public void testExclusionesRespetadas() {
        List<Member> miembros = Arrays.asList(
                new Member("1", "Ana", "ana@mail.com", List.of("2")), // Ana no puede tener a Luis
                new Member("2", "Luis", "luis@mail.com", List.of()),
                new Member("3", "Pedro", "pedro@mail.com", List.of())
        );

        Map<String, String> asignaciones = AsignacionHelper.generarAsignaciones(miembros);
        assertNotNull("La asignación no debe ser null", asignaciones);
        assertNotEquals("Ana no debe ser asignada a Luis", "2", asignaciones.get("1"));
    }

    /**
     * Prueba un escenario donde no se puede realizar ninguna asignación válida.
     * <p>
     * Todos los miembros se excluyen mutuamente, por lo que no debe generarse ningún emparejamiento.
     * El metodo debe devolver {@code null}.
     */
    @Test
    public void testAsignacionImposible() {
        List<Member> miembros = Arrays.asList(
                new Member("1", "Ana", "ana@mail.com", List.of("2", "3")),
                new Member("2", "Luis", "luis@mail.com", List.of("1", "3")),
                new Member("3", "Pedro", "pedro@mail.com", List.of("1", "2"))
        );

        Map<String, String> asignaciones = AsignacionHelper.generarAsignaciones(miembros);
        assertNull("No debe haber asignación posible", asignaciones);
    }
}
