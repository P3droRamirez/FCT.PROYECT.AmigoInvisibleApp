package netmind.amigoinvisible.utils;
import java.util.*;
import NetMind.amigoinvisible.models.Member;

/**
 * Clase utilitaria diseñada para pruebas que simula el algoritmo de asignación
 * del Amigo Invisible respetando las reglas básicas:
 * <ul>
 *     <li>No se permite autoasignación (un usuario no puede asignarse a sí mismo).</li>
 *     <li>Se respetan las exclusiones personalizadas definidas por cada miembro.</li>
 * </ul>
 * <p>
 * Esta versión es utilizada exclusivamente en entornos de testeo (como {@code GroupUtilsTest}),
 * permitiendo ejecutar la lógica sin dependencia directa de otras capas como Firebase.
 */
public class GroupUtilsTestable {

    /**
     * Realiza una asignación aleatoria de amigos invisibles asegurando que:
     * <ul>
     *     <li>Nadie se asigne a sí mismo.</li>
     *     <li>Se respeten las exclusiones configuradas en {@code Member.getExcludedUserIds()}.</li>
     * </ul>
     *
     * @param miembros Lista de miembros a asignar entre sí
     * @return Mapa con los pares asignador → asignado, o {@code null} si no se puede generar una asignación válida tras 10 intentos.
     */
    public static Map<String, String> realizarAsignaciones(List<Member> miembros) {
        List<String> asignadores = new ArrayList<>();
        Map<String, Member> mapaMiembros = new HashMap<>();
        for (Member m : miembros) {
            asignadores.add(m.getId());
            mapaMiembros.put(m.getId(), m);
        }

        Random random = new Random();
        for (int intento = 0; intento < 10; intento++) {
            List<String> receptores = new ArrayList<>(asignadores);
            Collections.shuffle(receptores, random);

            boolean valido = true;
            Map<String, String> resultado = new HashMap<>();

            for (int i = 0; i < asignadores.size(); i++) {
                String asignador = asignadores.get(i);
                String receptor = receptores.get(i);

                // No permitir autoasignación
                if (asignador.equals(receptor)) {
                    valido = false;
                    break;
                }

                // Verificar exclusiones
                Member m = mapaMiembros.get(asignador);
                if (m.getExcludedUserIds() != null && m.getExcludedUserIds().contains(receptor)) {
                    valido = false;
                    break;
                }

                resultado.put(asignador, receptor);
            }

            if (valido) return resultado;
        }

        // No se pudo generar una asignación válida tras varios intentos
        return null;
    }
}
