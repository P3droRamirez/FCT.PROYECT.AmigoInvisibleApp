package netmind.amigoinvisible.utils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import static org.junit.Assert.*;
import java.util.*;
import NetMind.amigoinvisible.models.Member;

/**
 * Pruebas unitarias para la clase {@link GroupUtilsTestable}.
 * <p>
 * Estas pruebas verifican el correcto comportamiento del algoritmo de asignación de amigos invisibles,
 * validando que se respeten las reglas como exclusiones y no auto-asignación.
 */
@RunWith(JUnit4.class)
public class GroupUtilsTest {

    /**
     * Verifica que la asignación básica entre dos miembros se realice sin auto-asignación.
     * <p>
     * Se espera que cada miembro reciba a otro diferente como amigo invisible.
     */
    @Test
    public void testAsignacionesBasicas() {
        List<Member> miembros = new ArrayList<>();
        miembros.add(new Member("1", "Ana", "ana@mail.com", List.of()));
        miembros.add(new Member("2", "Luis", "luis@mail.com", List.of()));

        Map<String, String> asignaciones = GroupUtilsTestable.realizarAsignaciones(miembros);

        assertNotNull("Asignaciones no deben ser null", asignaciones);
        assertEquals("Debe haber 2 asignaciones", 2, asignaciones.size());

        for (Map.Entry<String, String> entry : asignaciones.entrySet()) {
            assertNotEquals("Autoasignación detectada", entry.getKey(), entry.getValue());
        }
    }

    /**
     * Verifica que las reglas de exclusión se respeten en la asignación.
     * <p>
     * En este caso, Ana ha excluido a Luis, por lo que nunca debería ser asignada a él.
     */
    @Test
    public void testAsignacionesRespetanExclusiones() {
        List<Member> miembros = new ArrayList<>();
        miembros.add(new Member("1", "Ana", "ana@mail.com", List.of("2"))); // Ana no puede tener a Luis
        miembros.add(new Member("2", "Luis", "luis@mail.com", List.of()));
        miembros.add(new Member("3", "Pedro", "pedro@mail.com", List.of()));

        Map<String, String> asignaciones = GroupUtilsTestable.realizarAsignaciones(miembros);

        assertNotNull("La asignación no debe ser null", asignaciones);
        assertNotEquals("Ana fue asignada a alguien que excluyó", "2", asignaciones.get("1"));
    }

    /**
     * Verifica el caso en que no se puede generar una asignación válida
     * debido a las exclusiones mutuas entre todos los miembros.
     * <p>
     * Se espera que el método devuelva {@code null}.
     */
    @Test
    public void testSinAsignacionPosiblePorExclusiones() {
        List<Member> miembros = new ArrayList<>();
        miembros.add(new Member("1", "Ana", "ana@mail.com", List.of("2", "3")));
        miembros.add(new Member("2", "Luis", "luis@mail.com", List.of("1", "3")));
        miembros.add(new Member("3", "Pedro", "pedro@mail.com", List.of("1", "2")));

        Map<String, String> asignaciones = GroupUtilsTestable.realizarAsignaciones(miembros);

        assertNull("No debería haber una asignación válida", asignaciones);
    }
}
