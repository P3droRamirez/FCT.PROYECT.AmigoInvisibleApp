package netmind.amigoinvisible.utils;

import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import java.util.List;
import java.util.function.Consumer;

/**
 * Pruebas unitarias para verificar el comportamiento de la lógica de guardado
 * de asignaciones en Firebase utilizando funciones simuladas.
 *
 * <p>Utiliza {@link FirebaseUtilsTestable} para simular el guardado de datos en Firestore.
 * Se validan tanto casos exitosos como situaciones de error (listas desbalanceadas).</p>
 */
public class FirebaseUtilsTest {

    private Consumer<Void> mockSuccessCallback;
    private Consumer<String> mockErrorCallback;

    /**
     * Configura los mocks antes de cada prueba.
     * <p>Prepara consumidores simulados para callbacks de éxito y error.</p>
     */
    @Before
    public void setUp() {
        mockSuccessCallback = mock(Consumer.class);
        mockErrorCallback = mock(Consumer.class);
    }

    /**
     * Verifica que la función de éxito se ejecuta correctamente
     * cuando las listas de asignadores y asignados tienen el mismo tamaño.
     * <p>
     * Condiciones comprobadas:
     * <ul>
     *     <li>Se llama a {@code onSuccess}</li>
     *     <li>No se llama a {@code onError}</li>
     * </ul>
     * </p>
     */
    @Test
    public void testGuardarAsignacionesCallbackEjecutado() {
        List<String> asignadores = List.of("1", "2");
        List<String> asignados = List.of("3", "4");

        FirebaseUtilsTestable.simularGuardarAsignaciones(
                asignadores, asignados, mockSuccessCallback, mockErrorCallback
        );

        verify(mockSuccessCallback, times(1)).accept(null);
        verify(mockErrorCallback, never()).accept(anyString());
    }

    /**
     * Verifica que se ejecuta el callback de error cuando las listas
     * de asignadores y asignados tienen tamaños distintos.
     * <p>
     * Condiciones comprobadas:
     * <ul>
     *     <li>Se llama a {@code onError}</li>
     *     <li>No se llama a {@code onSuccess}</li>
     * </ul>
     * </p>
     */
    @Test
    public void testErrorEnAsignaciones() {
        List<String> asignadores = List.of("1", "2");
        List<String> asignados = List.of("3"); // tamaño no coincide

        FirebaseUtilsTestable.simularGuardarAsignaciones(
                asignadores, asignados, mockSuccessCallback, mockErrorCallback
        );

        verify(mockErrorCallback, times(1)).accept(anyString());
        verify(mockSuccessCallback, never()).accept(null);
    }
}
