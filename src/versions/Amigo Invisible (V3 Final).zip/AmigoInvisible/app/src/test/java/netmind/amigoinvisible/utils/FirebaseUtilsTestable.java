package netmind.amigoinvisible.utils;

import java.util.List;
import java.util.function.Consumer;

/**
 * Clase auxiliar para simular el guardado de asignaciones en Firebase
 * en un entorno de pruebas unitarias.
 *
 * <p>Se utiliza para testear la lógica de asignación sin realizar llamadas reales
 * a Firestore. Permite simular éxito o error según el tamaño de las listas de entrada.</p>
 */
public class FirebaseUtilsTestable {

    /**
     * Simula el guardado de asignaciones entre asignadores y asignados.
     * <p>
     * Si ambas listas tienen el mismo tamaño, se considera éxito y se ejecuta el callback
     * {@code onSuccess}. En caso contrario, se ejecuta {@code onError} con un mensaje de error.
     * </p>
     *
     * @param asignadores Lista de IDs de usuarios que asignan.
     * @param asignados Lista de IDs de usuarios asignados.
     * @param onSuccess Callback ejecutado si las listas coinciden en tamaño.
     * @param onError Callback ejecutado si hay error en la validación de datos.
     */
    public static void simularGuardarAsignaciones(
            List<String> asignadores,
            List<String> asignados,
            Consumer<Void> onSuccess,
            Consumer<String> onError
    ) {
        if (asignadores.size() == asignados.size()) {
            onSuccess.accept(null);
        } else {
            onError.accept("Error: tamaño no coincide");
        }
    }
}
