package netmind.amigoinvisible.activities;

import android.widget.Toast;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.activities.MainActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.matcher.ViewMatchers.*;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.Espresso.onView;

/**
 * Clase de pruebas UI para la pantalla principal de inicio de sesión {@link MainActivity}.
 * Utiliza Espresso para verificar la visibilidad de componentes y respuestas a interacciones básicas.
 */
@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    @Rule
    public ActivityScenarioRule<MainActivity> activityRule =
            new ActivityScenarioRule<>(MainActivity.class);

    /**
     * Verifica que los campos de entrada y el botón de login estén visibles al iniciar la actividad.
     * <p>
     * Objetivo: Asegurarse de que el usuario ve correctamente los inputs necesarios para iniciar sesión.
     * </p>
     */
    @Test
    public void camposDeLoginVisibles() {
        onView(withId(R.id.emailInput)).check(matches(isDisplayed()));
        onView(withId(R.id.passwordInput)).check(matches(isDisplayed()));
        onView(withId(R.id.btnLogIn)).check(matches(isDisplayed()));
    }

    /**
     * Verifica que al hacer clic en el botón de login con los campos vacíos,
     * la aplicación no crashea y permanece en la misma pantalla.
     * <p>
     * Nota: No se puede verificar el {@link Toast} directamente sin librerías adicionales como Barista.
     * </p>
     * Objetivo: Garantizar que la lógica de validación de campos vacíos no interrumpe el flujo normal de la app.
     */
    @Test
    public void loginCamposVaciosMuestraToast() {
        onView(withId(R.id.btnLogIn)).perform(click());

        // Verifica que no cambia de actividad y permanece en la misma pantalla
        onView(withId(R.id.emailInput)).check(matches(isDisplayed()));
    }
}
