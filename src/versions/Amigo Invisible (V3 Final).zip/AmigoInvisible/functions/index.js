const {onDocumentCreated} = require("firebase-functions/v2/firestore");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const {getMessaging} = require("firebase-admin/messaging");

initializeApp();

exports.enviarNotificacionesSorteo = onDocumentCreated(
  {
    document: "groups/{groupId}/assignments/{userId}",
    region: "europe-southwest1",
  },
  async (event) => {
    const db = getFirestore();
    const messaging = getMessaging();

    const {groupId, userId} = event.params;
    const assignedId = event.data.data().assignedTo;

    try {
      const userSnap = await db.collection("users").doc(userId).get();
      const fcmToken = userSnap.get("fcmToken");

      if (!fcmToken) {
        console.log(`❌ Usuario sin token FCM: ${userId}`);
        return;
      }

      const groupSnap = await db.collection("groups").doc(groupId).get();
      const groupName = groupSnap.get("name") || "un grupo";

      const assignedSnap = await db
        .collection("groups")
        .doc(groupId)
        .collection("members")
        .doc(assignedId)
        .get();
      const assignedName = assignedSnap.get("name") || "alguien";

      const payload = {
        data: {
          title: "🎁 Sorteo realizado",
          body: `En el grupo ${groupName}, tu amigo invisible es ${assignedName}.`,
          image_url: "app_icon", // clave que tu app usará para mostrar imagen local
          groupId: groupId,
        },
      };

      console.log("🚀 Enviando notificación a:", fcmToken);
      await messaging.sendEachForMulticast({
        tokens: [fcmToken],
        data: payload.data,
      });
      console.log("✅ Notificación enviada correctamente");
    } catch (error) {
      console.error("❌ Error al enviar notificación:", error);
    }
  }
);
