package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.WishlistAdapter;

public class WishlistActivity extends AppCompatActivity {

    // UI
    private AutoCompleteTextView campoDeseo;
    private Button botonAgregar;
    private RecyclerView recyclerView;
    private WishlistAdapter adapter;

    // Datos
    private final List<String> deseos = new ArrayList<>();
    private FirebaseFirestore db;
    private String idGrupo;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);

        // Obtener ID del grupo del intent
        idGrupo = getIntent().getStringExtra("groupId");
        if (idGrupo == null || idGrupo.isEmpty()) {
            Toast.makeText(this, R.string.error_id_grupo_invalido, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Firebase
        db = FirebaseFirestore.getInstance();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Referencias UI
        campoDeseo = findViewById(R.id.inputWishItem);
        botonAgregar = findViewById(R.id.btnAddWish);
        recyclerView = findViewById(R.id.wishlistRecyclerView);

        // Sugerencias de deseos para el autocompletado
        String[] sugerencias = getResources().getStringArray(R.array.wishlist_suggestions);
        ArrayAdapter<String> adaptadorSugerencias = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                sugerencias
        );
        campoDeseo.setAdapter(adaptadorSugerencias);
        campoDeseo.setThreshold(1); // Mostrar sugerencias desde el primer carácter

        // Configuración del RecyclerView
        adapter = new WishlistAdapter(deseos, this, idGrupo);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Cargar deseos previamente guardados
        cargarListaDesdeFirestore();

        // Acción del botón para agregar nuevo deseo
        botonAgregar.setOnClickListener(v -> {
            String texto = campoDeseo.getText().toString().trim();
            if (TextUtils.isEmpty(texto)) {
                Toast.makeText(this, R.string.mensaje_deseo_vacio, Toast.LENGTH_SHORT).show();
                return;
            }
            deseos.add(texto);
            campoDeseo.setText("");
            adapter.notifyDataSetChanged();
            guardarListaEnFirestore();
            Toast.makeText(this, R.string.mensaje_deseo_añadido, Toast.LENGTH_SHORT).show();
        });
    }

    /**
     * Guarda la lista de deseos personalizada en el documento del miembro dentro del grupo.
     */
    private void guardarListaEnFirestore() {
        DocumentReference refMiembro = db.collection("groups")
                .document(idGrupo)
                .collection("members")
                .document(userId);

        refMiembro.update("wishlist", deseos)
                .addOnFailureListener(e ->
                        Toast.makeText(this, R.string.mensaje_error_deseo, Toast.LENGTH_SHORT).show()
                );
    }

    /**
     * Carga la lista de deseos del usuario actual desde Firestore.
     */
    private void cargarListaDesdeFirestore() {
        db.collection("groups")
                .document(idGrupo)
                .collection("members")
                .document(userId)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.contains("wishlist")) {
                        deseos.clear();
                        deseos.addAll((List<String>) Objects.requireNonNull(document.get("wishlist")));
                        adapter.notifyDataSetChanged();
                    }
                });
    }
}
