package NetMind.amigoinvisible.activities;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.fragments.CreateGroupFragment;
import NetMind.amigoinvisible.fragments.SettingsFragment;
import NetMind.amigoinvisible.fragments.ViewGroupsFragment;
import NetMind.amigoinvisible.utils.FirebaseUtils;

public class WelcomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private FirebaseAuth authFirebase;
    private FirebaseUser usuarioActual;
    private FirebaseFirestore baseDatos;
    private StorageReference referenciaAlmacenamiento;

    private TextView textoBienvenida;
    private ImageView imagenPerfil;

    private ActivityResultLauncher<String> selectorImagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        inicializarFirebase();
        configurarToolbar();
        configurarDrawer();

        // Solo cargamos fragmento si aún no está restaurado
        if (savedInstanceState == null) {
            new android.os.Handler().postDelayed(() -> {
                usuarioActual = FirebaseAuth.getInstance().getCurrentUser();
                if (usuarioActual != null) {
                    FirebaseUtils.emparejarUsuarioConGrupos(usuarioActual, () ->
                            runOnUiThread(() -> cargarFragmento(new ViewGroupsFragment()))
                    );
                }
            }, 500);
        }
    }


    /**
     * Configura instancias de Firebase necesarias
     */
    private void inicializarFirebase() {
        authFirebase = FirebaseAuth.getInstance();
        usuarioActual = authFirebase.getCurrentUser();
        baseDatos = FirebaseFirestore.getInstance();
        referenciaAlmacenamiento = FirebaseStorage.getInstance().getReference("profile_pictures");
    }

    /**
     * Configura la Toolbar y el botón de apertura del Drawer
     */
    private void configurarToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
    }

    /**
     * Configura el Drawer (menú lateral) y muestra la información del usuario logueado
     */
    private void configurarDrawer() {
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Muestra la información del usuario logueado
        View headerView = navigationView.getHeaderView(0);
        textoBienvenida = headerView.findViewById(R.id.nav_header_name);
        TextView textoCorreo = headerView.findViewById(R.id.nav_header_email);
        imagenPerfil = headerView.findViewById(R.id.profile_image);

        // Rellena con los datos del usuario actual
        if (usuarioActual != null) {
            String nombre = usuarioActual.getDisplayName() != null ? usuarioActual.getDisplayName() : getString(R.string.usuario_generico);
            textoBienvenida.setText(getString(R.string.bienvenido_usuario, nombre));
            textoCorreo.setText(usuarioActual.getEmail());

            if (usuarioActual.getPhotoUrl() != null) {
                Glide.with(this).load(usuarioActual.getPhotoUrl()).circleCrop().into(imagenPerfil);
            }
        }
    }
    /**
     * Lanza el selector de imagen y sube la imagen seleccionada al storage de Firebase
     */
    private void configurarSelectorImagen() {
        selectorImagen = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                this::subirImagenAFirebase
        );

        imagenPerfil.setOnClickListener(v -> {
            Toast.makeText(this, R.string.mensaje_seleccionar_imagen, Toast.LENGTH_SHORT).show();
            selectorImagen.launch("image/*");
        });
    }

    /**
     * Se ejecuta al volver a la actividad: actualiza el fragmento si es necesario
     */
    @Override
    protected void onResume() {
        super.onResume();
        Fragment actual = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        if (actual instanceof ViewGroupsFragment) {
            getSupportFragmentManager().beginTransaction().remove(actual).commitNow();
            cargarFragmento(new ViewGroupsFragment());
        }
    }

    /**
     * Se ejecuta al destruir la actividad: detiene listeners activos en el fragmento de grupos
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Fragment actual = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        if (actual instanceof ViewGroupsFragment) {
            ViewGroupsFragment fragment = (ViewGroupsFragment) actual;
        }
    }

    /**
     * Carga el fragmento recibido reemplazando el contenedor actual
     */
    private void cargarFragmento(Fragment fragmento) {
        FragmentTransaction transaccion = getSupportFragmentManager().beginTransaction();
        transaccion.replace(R.id.fragment_container, fragmento);
        transaccion.commit();
    }

    /**
     * Maneja los clicks en el menú lateral (Drawer)
     */
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home || id == R.id.nav_my_groups) {
            cargarFragmento(new ViewGroupsFragment());
        } else if (id == R.id.nav_create_group) {
            cargarFragmento(new CreateGroupFragment());
        } else if (id == R.id.nav_settings) {
            cargarFragmento(new SettingsFragment());
        } else if (id == R.id.nav_logout) {
            authFirebase.signOut();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return true;
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    /**
     * Sube la imagen de perfil del usuario a Firebase y actualiza la URL en Firestore y Auth
     */
    private void subirImagenAFirebase(Uri uriImagen) {
        if (uriImagen == null || usuarioActual == null) return;

        StorageReference archivoRef = referenciaAlmacenamiento.child(usuarioActual.getUid() + "/profile.jpg");

        archivoRef.putFile(uriImagen)
                .addOnSuccessListener(taskSnapshot -> archivoRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    // Actualiza FirebaseAuth con nueva imagen
                    UserProfileChangeRequest actualizacionPerfil = new UserProfileChangeRequest.Builder()
                            .setPhotoUri(uri)
                            .build();

                    usuarioActual.updateProfile(actualizacionPerfil)
                            .addOnSuccessListener(unused -> {
                                Glide.with(this).load(uri).circleCrop().into(imagenPerfil);
                                Toast.makeText(this, R.string.foto_actualizada, Toast.LENGTH_SHORT).show();

                                // Actualiza Firestore con nueva URL
                                Map<String, Object> datosActualizados = new HashMap<>();
                                datosActualizados.put("photoUrl", uri.toString());

                                baseDatos.collection("users").document(usuarioActual.getUid()).update(datosActualizados);

                                // Reinicia el adapter si está visible
                                Fragment actual = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
                                if (actual instanceof ViewGroupsFragment) {
                                    ViewGroupsFragment fragment = (ViewGroupsFragment) actual;
                                }
                            });
                }))
                .addOnFailureListener(e ->
                        Toast.makeText(this, getString(R.string.error_subida_imagen, e.getMessage()), Toast.LENGTH_SHORT).show()
                );

    }
}