package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.MemberAdapter;
import NetMind.amigoinvisible.models.Member;

public class AddMemberActivity extends AppCompatActivity {

    private EditText campoNombre, campoCorreo;
    private FirebaseFirestore baseDatos;
    private FirebaseAuth auth;
    private String idGrupo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_member);

        baseDatos = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        idGrupo = getIntent().getStringExtra("groupId");

        campoNombre = findViewById(R.id.editTextMemberName);
        campoCorreo = findViewById(R.id.editTextMemberEmail);

        findViewById(R.id.btnAddMember).setOnClickListener(v -> aniadirParticipantes());

        RecyclerView recyclerMiembros = findViewById(R.id.recyclerViewMembers);
        recyclerMiembros.setLayoutManager(new LinearLayoutManager(this));

        FirestoreRecyclerOptions<Member> opciones = new FirestoreRecyclerOptions.Builder<Member>()
                .setQuery(baseDatos.collection("groups").document(idGrupo).collection("members"), Member.class)
                .setLifecycleOwner(this)
                .build();

        MemberAdapter adaptador = new MemberAdapter(opciones, idGrupo);
        recyclerMiembros.setAdapter(adaptador);
    }

    /**
     * Añade un nuevo participante al grupo, buscando primero si ya es un usuario registrado.
     */
    private void aniadirParticipantes() {
        String nombre = campoNombre.getText().toString().trim();
        String correo = campoCorreo.getText().toString().trim();

        if (TextUtils.isEmpty(nombre) || TextUtils.isEmpty(correo)) {
            Toast.makeText(this, R.string.mensaje_campos_obligatorios, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!validarCorreo(correo)) {
            Toast.makeText(this, R.string.mensaje_correo_invalido, Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar cupo del grupo
        baseDatos.collection("groups").document(idGrupo).get()
                .addOnSuccessListener(grupo -> {
                    Long maximo = grupo.getLong("maxParticipants");

                    baseDatos.collection("groups").document(idGrupo).collection("members")
                            .get()
                            .addOnSuccessListener(miembros -> {
                                if (maximo != null && miembros.size() >= maximo) {
                                    Toast.makeText(this, R.string.mensaje_grupo_completo, Toast.LENGTH_SHORT).show();
                                    return;
                                }

                                // Verificar si el correo ya pertenece a un usuario registrado
                                baseDatos.collection("users")
                                        .whereEqualTo("correo", correo)
                                        .get()
                                        .addOnSuccessListener(usuarios -> {
                                            Map<String, Object> datosMiembro = new HashMap<>();
                                            datosMiembro.put("name", nombre);
                                            datosMiembro.put("email", correo);

                                            String idDocumento;

                                            if (!usuarios.isEmpty()) {
                                                // Usuario registrado → usar UID
                                                idDocumento = usuarios.getDocuments().get(0).getId();
                                            } else {
                                                // Usuario externo → usar ID aleatorio
                                                idDocumento = baseDatos.collection("groups").document(idGrupo)
                                                        .collection("members").document().getId();
                                            }

                                            baseDatos.collection("groups").document(idGrupo)
                                                    .collection("members").document(idDocumento)
                                                    .set(datosMiembro)
                                                    .addOnSuccessListener(unused -> {
                                                        Toast.makeText(this, R.string.mensaje_participante_añadido, Toast.LENGTH_SHORT).show();
                                                        campoNombre.setText("");
                                                        campoCorreo.setText("");
                                                    })
                                                    .addOnFailureListener(e -> {
                                                        Toast.makeText(this, getString(R.string.mensaje_error_guardar, e.getMessage()), Toast.LENGTH_SHORT).show();
                                                        Log.e("AddMemberActivity", "Error al guardar miembro", e);
                                                    });
                                        });
                            });
                });
    }


    private boolean validarCorreo(String correo) {
        String patronCorreo = "[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}";
        return correo.matches(patronCorreo);
    }
}
