package NetMind.amigoinvisible.models;

import java.util.List;

public class Member {
    private String name;
    private String email;
    private List<String> wishlist;

    public Member() {} // Necesario para Firestore

    public String getName() { return name; }
    public String getEmail() { return email; }
    public List<String> getWishlist() { return wishlist; }
}
