package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.MessageAdapter;
import NetMind.amigoinvisible.models.Message;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class GroupChatActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private String groupId; // Usamos groupId ahora en lugar de drawId
    private RecyclerView recyclerView;
    private MessageAdapter messageAdapter;
    private List<Message> messagesList;
    private EditText messageInput;
    private Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);

        // Obtener el ID del grupo que se pasa desde la actividad anterior
        groupId = getIntent().getStringExtra("groupId");
        if (groupId == null) {
            Toast.makeText(this, "El groupId no fue recibido correctamente", Toast.LENGTH_SHORT).show();
            finish();  // Cierra la actividad si el groupId es nulo
        }

        // Verificar si el groupId es nulo
        if (groupId == null) {
            Toast.makeText(this, "Error: No se proporcionó el ID del grupo", Toast.LENGTH_SHORT).show();
            finish(); // Cerrar la actividad si no hay groupId
            return;
        }

        // Inicializar Firestore
        db = FirebaseFirestore.getInstance();

        // Referencia a la colección de mensajes en Firestore
        CollectionReference messagesRef = db.collection("messages").document(groupId).collection("messages");

        // Inicialización de los elementos UI
        recyclerView = findViewById(R.id.recyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);

        messagesList = new ArrayList<>();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        messageAdapter = new MessageAdapter(messagesList);
        recyclerView.setAdapter(messageAdapter);

        // Cargar los mensajes desde Firestore
        loadMessages();

        // Configurar el botón de envío de mensajes
        sendButton.setOnClickListener(v -> {
            String content = messageInput.getText().toString();
            if (!content.isEmpty()) {
                sendMessage(content);
                messageInput.setText(""); // Limpiar el campo de entrada
            }
        });
    }

    private void loadMessages() {
        CollectionReference messagesRef = db.collection("groups")
                .document(groupId)  // Asegúrate de que estás usando el groupId correcto
                .collection("messages");

        // Escuchar los cambios en tiempo real
        messagesRef.orderBy("timestamp")
                .addSnapshotListener((QuerySnapshot value, FirebaseFirestoreException error) -> {
                    if (error != null) {
                        // Maneja el error si es necesario
                        return;
                    }

                    // Limpiar la lista antes de agregar los nuevos mensajes
                    messagesList.clear();

                    // Agregar los nuevos mensajes a la lista
                    for (DocumentSnapshot document : value) {
                        Message message = document.toObject(Message.class);
                        if (message != null) {
                            messagesList.add(message);
                        }
                    }

                    // Notificar al adaptador que los datos han cambiado
                    messageAdapter.notifyDataSetChanged();
                });
    }

    private void sendMessage(String content) {
        String senderId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        boolean isAnonymous = true; // Los mensajes son anónimos por defecto

        // Crear un nuevo mensaje
        Message message = new Message(senderId, content, timestamp, isAnonymous);

        // Agregar el mensaje a la subcolección 'messages' del grupo
        db.collection("groups").document(groupId)
                .collection("messages")
                .add(message)
                .addOnSuccessListener(documentReference -> {
                })
                .addOnFailureListener(e -> {
                    // Manejar error
                    Toast.makeText(GroupChatActivity.this, "Error al enviar el mensaje", Toast.LENGTH_SHORT).show();
                });
    }
}
