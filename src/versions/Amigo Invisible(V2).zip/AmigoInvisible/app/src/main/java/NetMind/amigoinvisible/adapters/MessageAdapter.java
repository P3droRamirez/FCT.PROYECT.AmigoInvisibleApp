package NetMind.amigoinvisible.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.models.Message;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TIPO_ENVIADO = 1;
    private static final int TIPO_RECIBIDO = 2;

    private final List<Message> listaMensajes;
    private final String idUsuarioActual;

    // Constructor que recibe la lista de mensajes
    public MessageAdapter(List<Message> listaMensajes) {
        this.listaMensajes = listaMensajes;
        this.idUsuarioActual = FirebaseAuth.getInstance().getCurrentUser().getUid();
    }

    // Determina el tipo de vista según quién envió el mensaje
    @Override
    public int getItemViewType(int posicion) {
        Message mensaje = listaMensajes.get(posicion);
        return mensaje.getSenderId().equals(idUsuarioActual) ? TIPO_ENVIADO : TIPO_RECIBIDO;
    }

    // Infla el layout correcto según el tipo de mensaje (enviado o recibido)
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup padre, int tipoVista) {
        View vista;
        if (tipoVista == TIPO_ENVIADO) {
            vista = LayoutInflater.from(padre.getContext()).inflate(R.layout.item_mensaje_enviado, padre, false);
            return new ViewHolderMensajeEnviado(vista);
        } else {
            vista = LayoutInflater.from(padre.getContext()).inflate(R.layout.item_mensaje_recibido, padre, false);
            return new ViewHolderMensajeRecibido(vista);
        }
    }

    // Enlaza los datos del mensaje a la vista correspondiente
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int posicion) {
        Message mensaje = listaMensajes.get(posicion);
        if (holder instanceof ViewHolderMensajeEnviado) {
            ((ViewHolderMensajeEnviado) holder).textoMensaje.setText(mensaje.getContent());
        } else if (holder instanceof ViewHolderMensajeRecibido) {
            ((ViewHolderMensajeRecibido) holder).textoMensaje.setText(mensaje.getContent());
        }
    }

    // Devuelve el número total de mensajes
    @Override
    public int getItemCount() {
        return listaMensajes.size();
    }

    // ViewHolder para mensajes enviados
    public static class ViewHolderMensajeEnviado extends RecyclerView.ViewHolder {
        TextView textoMensaje;

        public ViewHolderMensajeEnviado(@NonNull View itemView) {
            super(itemView);
            textoMensaje = itemView.findViewById(R.id.messageText); // ID corregido aquí
        }
    }

    // ViewHolder para mensajes recibidos
    public static class ViewHolderMensajeRecibido extends RecyclerView.ViewHolder {
        TextView textoMensaje;

        public ViewHolderMensajeRecibido(@NonNull View itemView) {
            super(itemView);
            textoMensaje = itemView.findViewById(R.id.messageText); // ID corregido aquí
        }
    }
}
