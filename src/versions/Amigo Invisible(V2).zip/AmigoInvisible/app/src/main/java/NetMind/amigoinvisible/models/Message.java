package NetMind.amigoinvisible.models;

public class Message {
    private String senderId;
    private String content;
    private String timestamp;
    private boolean isAnonymous;

    // Constructor
    public Message(String senderId, String content, String timestamp, boolean isAnonymous) {
        this.senderId = senderId;
        this.content = content;
        this.timestamp = timestamp;
        this.isAnonymous = isAnonymous;
    }
    //Constructor vacio que permite a firestore crear instancias de objetos de una clase cuando lee datos
    public Message() {
    }


    // Getters y Setters
    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    public boolean isAnonymous() { return isAnonymous; }
    public void setAnonymous(boolean isAnonymous) { this.isAnonymous = isAnonymous; }
}
