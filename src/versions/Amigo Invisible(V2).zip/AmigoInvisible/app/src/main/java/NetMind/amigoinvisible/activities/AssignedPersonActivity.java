package NetMind.amigoinvisible.activities;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import NetMind.amigoinvisible.R;

public class AssignedPersonActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private String groupId;
    private String assignedId;

    private TextView nombreAsignadoTextView;
    private TextView listaDeseosTextView;
    private ImageView fotoAsignado;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assigned_person);

        groupId = getIntent().getStringExtra("groupId");
        assignedId = getIntent().getStringExtra("assignedId");

        nombreAsignadoTextView = findViewById(R.id.textNombreAsignado);
        listaDeseosTextView = findViewById(R.id.textListaDeseos);
        fotoAsignado = findViewById(R.id.imageAsignado);

        db = FirebaseFirestore.getInstance();

        if (groupId == null || assignedId == null) {
            Toast.makeText(this, R.string.error_datos_asignado, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        cargarDatosAsignado();
    }

    private void cargarDatosAsignado() {
        db.collection("groups")
                .document(groupId)
                .collection("members")
                .document(assignedId)
                .get()
                .addOnSuccessListener(this::mostrarDatosAsignado)
                .addOnFailureListener(e ->
                        Toast.makeText(this, R.string.error_datos_asignado, Toast.LENGTH_SHORT).show()
                );
    }

    private void mostrarDatosAsignado(DocumentSnapshot doc) {
        String nombre = doc.getString("name");
        String photoUrl = doc.getString("photoUrl");
        Object deseos = doc.get("wishlist");

        nombreAsignadoTextView.setText(getString(R.string.text_asignado_nombre_placeholder, nombre));
        if (photoUrl != null && !photoUrl.isEmpty()) {
            Glide.with(this).load(photoUrl).placeholder(R.drawable.ic_user).into(fotoAsignado);
        }

        if (deseos instanceof java.util.List<?>) {
            StringBuilder lista = new StringBuilder();
            for (Object deseo : (java.util.List<?>) deseos) {
                lista.append("\u2022 ").append(String.valueOf(deseo)).append("\n");
            }
            listaDeseosTextView.setText(lista.toString());
        } else {
            listaDeseosTextView.setText(R.string.text_lista_vacia);
        }
    }
}
