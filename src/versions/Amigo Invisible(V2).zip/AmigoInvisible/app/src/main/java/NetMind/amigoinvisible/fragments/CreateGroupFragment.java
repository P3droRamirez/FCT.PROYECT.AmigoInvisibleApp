package NetMind.amigoinvisible.fragments;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import NetMind.amigoinvisible.R;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CreateGroupFragment extends Fragment {

    private EditText campoNombreGrupo, campoMaxParticipantes, campoPresupuesto;
    private ImageView groupImagePreview;
    private Uri imageUriSeleccionada;
    private FirebaseFirestore baseDatos;
    private FirebaseAuth auth;
    private static final int PICK_IMAGE_REQUEST = 101;

    public CreateGroupFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflador, ViewGroup contenedor, Bundle savedInstanceState) {
        View vista = inflador.inflate(R.layout.fragment_create_group, contenedor, false);

        // Referencias UI
        campoNombreGrupo = vista.findViewById(R.id.editTextGroupName);
        campoMaxParticipantes = vista.findViewById(R.id.editTextMaxParticipants);
        campoPresupuesto = vista.findViewById(R.id.editTextBudgetLimit);
        groupImagePreview = vista.findViewById(R.id.groupImagePreview);
        MaterialButton botonCrearGrupo = vista.findViewById(R.id.btnFinishGroup);
        MaterialButton botonSeleccionarImagen = vista.findViewById(R.id.btnSelectImage);

        baseDatos = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        // Selector de imagen
        botonSeleccionarImagen.setOnClickListener(v -> seleccionarImagen());

        // Acción de crear grupo
        botonCrearGrupo.setOnClickListener(v -> crearGrupo());

        return vista;
    }

    /**
     * Abre el selector de imágenes
     */
    private void seleccionarImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    /**
     * Carga la imagen seleccionada en la vista previa
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            imageUriSeleccionada = data.getData();
            Glide.with(this).load(imageUriSeleccionada).into(groupImagePreview);
        }
    }

    /**
     * Crea un nuevo grupo y añade automáticamente al creador como miembro
     */
    private void crearGrupo() {
        String nombre = campoNombreGrupo.getText().toString().trim();
        String textoMaxParticipantes = campoMaxParticipantes.getText().toString().trim();
        String textoPresupuesto = campoPresupuesto.getText().toString().trim();

        if (TextUtils.isEmpty(nombre) || TextUtils.isEmpty(textoMaxParticipantes) || TextUtils.isEmpty(textoPresupuesto)) {
            Toast.makeText(getContext(), getString(R.string.error_campos_obligatorios), Toast.LENGTH_SHORT).show();
            return;
        }

        int maxParticipantes;
        double presupuesto;
        try {
            maxParticipantes = Integer.parseInt(textoMaxParticipantes);
            presupuesto = Double.parseDouble(textoPresupuesto);
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), getString(R.string.error_valores_numericos), Toast.LENGTH_SHORT).show();
            return;
        }

        String idUsuario = auth.getCurrentUser().getUid();

        // Validar límite de grupos creados por el usuario (máximo 3)
        baseDatos.collection("groups")
                .whereEqualTo("owner", idUsuario)
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.size() >= 3) {
                        Toast.makeText(getContext(), getString(R.string.error_max_grupos, 3), Toast.LENGTH_LONG).show();

                        return;
                    }

                    // Continúa la creación del grupo
                    Map<String, Object> datosGrupo = new HashMap<>();
                    datosGrupo.put("name", nombre);
                    datosGrupo.put("owner", idUsuario);
                    datosGrupo.put("maxParticipants", maxParticipantes);
                    datosGrupo.put("budgetLimit", presupuesto);
                    datosGrupo.put("members", new ArrayList<String>() {{ add(idUsuario); }});
                    datosGrupo.put("imageUrl", "");

                    baseDatos.collection("groups").add(datosGrupo).addOnSuccessListener(docRef -> {
                        String groupId = docRef.getId();

                        if (imageUriSeleccionada != null) {
                            StorageReference storageRef = FirebaseStorage.getInstance().getReference()
                                    .child("group_images/" + groupId + ".jpg");

                            storageRef.putFile(imageUriSeleccionada)
                                    .addOnSuccessListener(taskSnapshot -> storageRef.getDownloadUrl()
                                            .addOnSuccessListener(uri -> docRef.update("imageUrl", uri.toString())));
                        }

                        Map<String, Object> datosMiembro = new HashMap<>();
                        datosMiembro.put("name", auth.getCurrentUser().getDisplayName());
                        datosMiembro.put("email", auth.getCurrentUser().getEmail());

                        docRef.collection("members").document(idUsuario).set(datosMiembro).addOnSuccessListener(unused -> {
                            Toast.makeText(getContext(), getString(R.string.mensaje_grupo_creado), Toast.LENGTH_SHORT).show();
                            requireActivity().getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.fragment_container, new ViewGroupsFragment())
                                    .commit();
                        });

                    }).addOnFailureListener(e ->
                            Toast.makeText(getContext(), getString(R.string.error_crear_grupo), Toast.LENGTH_SHORT).show()
                    );
                })
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Error al verificar límite de grupos.", Toast.LENGTH_SHORT).show());
    }
}

