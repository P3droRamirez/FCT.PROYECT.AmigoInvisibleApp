package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.ArrayList;
import java.util.List;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.GroupListAdapter;
import NetMind.amigoinvisible.models.Group;

public class ViewGroupsFragment extends Fragment {

    // Firestore
    private FirebaseFirestore baseDatos;

    // Adaptador y datos
    private GroupListAdapter adaptadorGrupos;
    private final List<Group> listaDatosGrupos = new ArrayList<>();
    private RecyclerView listaGrupos;

    // Listener para datos en tiempo real
    private ListenerRegistration listenerGrupos;

    public ViewGroupsFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflador, ViewGroup contenedor, Bundle savedInstanceState) {
        View vista = inflador.inflate(R.layout.fragment_view_groups, contenedor, false);

        // Inicializar RecyclerView y adaptador
        listaGrupos = vista.findViewById(R.id.recyclerGroups);
        listaGrupos.setLayoutManager(new LinearLayoutManager(getContext()));
        adaptadorGrupos = new GroupListAdapter(listaDatosGrupos);
        listaGrupos.setAdapter(adaptadorGrupos);

        // Instanciar Firestore y cargar datos
        baseDatos = FirebaseFirestore.getInstance();
        cargarGruposDelUsuario();

        return vista;
    }

    /**
     * Carga los grupos en los que el usuario está incluido usando el campo "members" del documento.
     * Esto evita múltiples lecturas y mejora el rendimiento.
     */
    private void cargarGruposDelUsuario() {
        FirebaseUser usuario = FirebaseAuth.getInstance().getCurrentUser();
        if (usuario == null) {
            // Puedes mostrar un mensaje o simplemente salir de la función
            return;
        }

        String idUsuario = usuario.getUid();

        CollectionReference gruposRef = baseDatos.collection("groups");

        listenerGrupos = gruposRef.addSnapshotListener((snapshot, error) -> {
            if (error != null || snapshot == null) return;

            listaDatosGrupos.clear();

            for (DocumentSnapshot docGrupo : snapshot.getDocuments()) {
                List<String> miembros = (List<String>) docGrupo.get("members");
                Log.d("DebugGroups", "Grupo: " + docGrupo.getString("name") + " miembros: " + docGrupo.get("members"));


                if (miembros != null && miembros.contains(idUsuario)) {
                    Log.d("GrupoVisible", "Grupo: " + docGrupo.getString("name") + ", UID en lista: " + idUsuario);
                    Group grupo = docGrupo.toObject(Group.class);
                    if (grupo != null) {
                        grupo.setId(docGrupo.getId());
                        listaDatosGrupos.add(grupo);
                    }
                }
            }

            adaptadorGrupos.notifyDataSetChanged();
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Detener el listener para evitar fugas de memoria
        if (listenerGrupos != null) {
            listenerGrupos.remove();
            listenerGrupos = null;
        }
    }
}
