package NetMind.amigoinvisible.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import NetMind.amigoinvisible.R;

public class RegisterActivity extends AppCompatActivity {

    private EditText campoNombre, campoCorreo, campoContrasena;
    private FirebaseAuth auth;
    private FirebaseFirestore baseDatos;
    private static final String TAG = "RegistroUsuario";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Referencias de los campos de entrada
        campoNombre = findViewById(R.id.editTextName);
        campoCorreo = findViewById(R.id.editTextEmail);
        campoContrasena = findViewById(R.id.editTextPassword);
        Button botonRegistrar = findViewById(R.id.btnRegister);

        // Inicialización de Firebase Auth y Firestore
        auth = FirebaseAuth.getInstance();
        baseDatos = FirebaseFirestore.getInstance();

        // Acción del botón de registro
        botonRegistrar.setOnClickListener(v -> registrarUsuario());
    }

    /**
     * Valida los campos y registra al usuario con Firebase Auth.
     */
    private void registrarUsuario() {
        String nombre = campoNombre.getText().toString().trim();
        String correo = campoCorreo.getText().toString().trim();
        String contrasena = campoContrasena.getText().toString().trim();

        if (TextUtils.isEmpty(nombre) || TextUtils.isEmpty(correo) || TextUtils.isEmpty(contrasena)) {
            Toast.makeText(this, R.string.mensaje_campos_obligatorios, Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear usuario con correo y contraseña
        auth.createUserWithEmailAndPassword(correo, contrasena)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser usuario = auth.getCurrentUser();
                        if (usuario != null) {
                            // Actualizar el nombre del usuario en su perfil de Firebase Auth
                            UserProfileChangeRequest actualizarPerfil = new UserProfileChangeRequest.Builder()
                                    .setDisplayName(nombre)
                                    .build();

                            usuario.updateProfile(actualizarPerfil)
                                    .addOnCompleteListener(profileTask -> {
                                        if (profileTask.isSuccessful()) {
                                            guardarUsuarioEnFirestore(usuario, nombre);
                                        } else {
                                            // Si falla el nombre, guardar igual pero sin nombre
                                            Toast.makeText(this, R.string.mensaje_error_actualizar_nombre, Toast.LENGTH_SHORT).show();
                                            Log.e(TAG, "Error al actualizar perfil: ", profileTask.getException());
                                            guardarUsuarioEnFirestore(usuario, "");
                                        }
                                    });
                        }
                    } else {
                        Toast.makeText(this, getString(R.string.mensaje_error_registro, task.getException().getMessage()), Toast.LENGTH_LONG).show();
                    }
                });
    }

    /**
     * Guarda los datos del usuario en Firestore.
     */
    private void guardarUsuarioEnFirestore(FirebaseUser usuario, String nombre) {
        Map<String, Object> datosUsuario = new HashMap<>();
        datosUsuario.put("displayName", nombre);
        datosUsuario.put("email", usuario.getEmail());
        datosUsuario.put("photoUrl", null);

        baseDatos.collection("users").document(usuario.getUid()).set(datosUsuario)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, R.string.mensaje_registro_exitoso, Toast.LENGTH_SHORT).show();
                    // Redirigir a la pantalla de bienvenida
                    startActivity(new Intent(this, WelcomeActivity.class));
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, R.string.mensaje_error_firestore, Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Error al guardar en Firestore", e);
                });
    }
}
