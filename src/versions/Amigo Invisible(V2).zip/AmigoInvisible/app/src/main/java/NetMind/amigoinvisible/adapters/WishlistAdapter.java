package NetMind.amigoinvisible.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

import NetMind.amigoinvisible.R;

public class WishlistAdapter extends RecyclerView.Adapter<WishlistAdapter.ViewHolder> {

    private final List<String> deseos;
    private final Context context;
    private final String groupId;
    private final FirebaseFirestore db = FirebaseFirestore.getInstance();

    public WishlistAdapter(List<String> deseos, Context context, String groupId) {
        this.deseos = deseos;
        this.context = context;
        this.groupId = groupId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_wishlist, parent, false);
        return new ViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String deseo = deseos.get(position);
        holder.textView.setText(deseo);

        // Abrir Amazon
        holder.textView.setOnClickListener(v -> {
            String query = Uri.encode(deseo + " Amazon");
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.amazon.es/s?k=" + query));
            context.startActivity(intent);
        });

        // Eliminar deseo
        holder.deleteIcon.setOnClickListener(v -> {
            deseos.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, deseos.size());

            // Actualizar en Firestore
            db.collection("groups").document(groupId)
                    .update("wishlist", deseos)
                    .addOnFailureListener(e ->
                            Toast.makeText(context, R.string.mensaje_error_deseo, Toast.LENGTH_SHORT).show()
                    );
        });
    }

    @Override
    public int getItemCount() {
        return deseos.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        ImageView deleteIcon;

        ViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textWishItem);
            deleteIcon = itemView.findViewById(R.id.btnDeleteWish);
        }
    }
}
