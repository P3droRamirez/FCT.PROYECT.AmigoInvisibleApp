package NetMind.amigoinvisible.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.models.Member;

/**
 * Adaptador para mostrar la lista de miembros de un grupo en un RecyclerView,
 * utilizando FirestoreRecyclerAdapter para integración en tiempo real con Firestore.
 */
public class MemberAdapter extends FirestoreRecyclerAdapter<Member, MemberAdapter.MemberViewHolder> {

    private final String idGrupo;

    /**
     * Constructor que recibe las opciones y el ID del grupo al que pertenecen los miembros.
     *
     * @param opciones Opciones de configuración para FirestoreRecyclerAdapter
     * @param idGrupo  ID del grupo Firestore donde están los miembros
     */
    public MemberAdapter(@NonNull FirestoreRecyclerOptions<Member> opciones, String idGrupo) {
        super(opciones);
        this.idGrupo = idGrupo;
    }

    /**
     * Asocia los datos de cada miembro al ViewHolder y configura la acción de eliminar.
     */
    @Override
    protected void onBindViewHolder(@NonNull MemberViewHolder holder, int position, @NonNull Member miembro) {
        holder.textoNombre.setText(miembro.getName());
        holder.textoCorreo.setText(miembro.getEmail());

        // Acción de eliminar con diálogo de confirmación
        holder.iconoEliminar.setOnClickListener(v -> {
            new AlertDialog.Builder(holder.itemView.getContext())
                    .setTitle(R.string.dialogo_titulo_eliminar_participante)
                    .setMessage(holder.itemView.getContext().getString(R.string.dialogo_mensaje_eliminar_participante, miembro.getName()))
                    .setPositiveButton(R.string.dialogo_boton_si, (dialog, which) -> {
                        FirebaseFirestore.getInstance()
                                .collection("groups")
                                .document(idGrupo)
                                .collection("members")
                                .document(getSnapshots().getSnapshot(holder.getAdapterPosition()).getId())
                                .delete()
                                .addOnSuccessListener(unused ->
                                        Toast.makeText(holder.itemView.getContext(), R.string.mensaje_participante_eliminado, Toast.LENGTH_SHORT).show()
                                );
                    })
                    .setNegativeButton(R.string.dialogo_boton_no, null)
                    .show();
        });
    }

    /**
     * Infla el layout de cada ítem del RecyclerView.
     */
    @NonNull
    @Override
    public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_member, parent, false);
        return new MemberViewHolder(vista);
    }

    /**
     * ViewHolder que representa visualmente un miembro en la lista.
     */
    static class MemberViewHolder extends RecyclerView.ViewHolder {
        TextView textoNombre, textoCorreo;
        ImageView iconoEliminar;

        public MemberViewHolder(@NonNull View itemView) {
            super(itemView);
            textoNombre = itemView.findViewById(R.id.textName);
            textoCorreo = itemView.findViewById(R.id.textEmail);
            iconoEliminar = itemView.findViewById(R.id.iconDelete);
        }
    }
}
