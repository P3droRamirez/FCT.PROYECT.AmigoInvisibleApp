package NetMind.amigoinvisible.models;

public class Group {
    private String id;
    private String name;
    private String owner;
    private int maxParticipants;
    private double budgetLimit;
    private String imageUrl;

    public Group() {
        // Necesario para Firestore
    }

    public Group(String id, String name, String owner, int maxParticipants, double budgetLimit, String imageUrl) {
        this.id = id;
        this.name = name;
        this.owner = owner;
        this.maxParticipants = maxParticipants;
        this.budgetLimit = budgetLimit;
        this.imageUrl = imageUrl;
    }

    // Getters y Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getOwner() {
        return owner;
    }

    public int getMaxParticipants() {
        return maxParticipants;
    }

    public double getBudgetLimit() {
        return budgetLimit;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
