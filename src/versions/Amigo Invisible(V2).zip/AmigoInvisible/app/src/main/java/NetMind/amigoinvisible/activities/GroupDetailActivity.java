package NetMind.amigoinvisible.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import NetMind.amigoinvisible.utils.GroupUtils;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.adapters.MemberAdapter;
import NetMind.amigoinvisible.models.Member;

public class GroupDetailActivity extends AppCompatActivity {
    // UI
    private TextView textoNombreGrupo, textoPresupuestoGrupo, textoContadorGrupo;
    private ImageView imageGroup;
    private MaterialButton botonAgregarMiembro;
    private RecyclerView recyclerMiembros;
    // Firebase
    private FirebaseFirestore baseDatos;
    private FirebaseAuth auth;
    private ListenerRegistration listenerMiembros;
    private MemberAdapter adaptadorMiembros;
    // Variables
    private String idGrupo;
    private boolean sePuedeAgregar = true;
    private static final int PICK_IMAGE_REQUEST = 102;
    private Uri nuevaImagenUri;
    private String ownerId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_detail);

        // Firebase
        baseDatos = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        idGrupo = getIntent().getStringExtra("groupId");

        // Referencias UI
        textoNombreGrupo = findViewById(R.id.textGroupNameDetail);
        textoPresupuestoGrupo = findViewById(R.id.textGroupBudgetDetail);
        textoContadorGrupo = findViewById(R.id.textGroupCountDetail);
        imageGroup = findViewById(R.id.imageGroupDetail);
        botonAgregarMiembro = findViewById(R.id.btnAddMember);
        MaterialButton botonSortear = findViewById(R.id.btnSort);
        MaterialButton botonChat = findViewById(R.id.btnChat);
        MaterialButton botonWishlist = findViewById(R.id.btnWishlist);
        recyclerMiembros = findViewById(R.id.recyclerGroupMembersDetail);
        MaterialButton botonVerAsignado = findViewById(R.id.btnViewAssigned);
        botonVerAsignado.setVisibility(View.GONE); // Oculto hasta que se detecte que ya hay asignado



        // Acciones de botones
        botonAgregarMiembro.setOnClickListener(v -> verificarYAgregarMiembro());
        botonSortear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_titulo_confirmar_sorteo)
                .setMessage(R.string.dialog_mensaje_confirmar_sorteo)
                .setPositiveButton(R.string.dialog_boton_realizar, (dialog, which) -> {
                    GroupUtils.realizarSorteo(
                            idGrupo,
                            () -> Toast.makeText(this, R.string.mensaje_sorteo_exito, Toast.LENGTH_SHORT).show(),
                            error -> Toast.makeText(this, getString(R.string.mensaje_error_sorteo, error), Toast.LENGTH_SHORT).show()
                    );
                })
                .setNegativeButton(R.string.dialog_boton_cancelar, null)
                .show()
        );
        botonChat.setOnClickListener(v -> {
            Intent intent = new Intent(this, GroupChatActivity.class);
            intent.putExtra("groupId", idGrupo);
            startActivity(intent);
        });
        botonWishlist.setOnClickListener(v -> {
            Intent intent = new Intent(this, WishlistActivity.class);
            intent.putExtra("groupId", idGrupo);
            startActivity(intent);
        });

        // Al hacer click en la imagen, si el usuario es el propietario, se abre el selector
        imageGroup.setOnClickListener(v -> {
            if (ownerId != null && auth.getCurrentUser() != null && ownerId.equals(auth.getCurrentUser().getUid())) {
                seleccionarNuevaImagen();
            } else {
                Toast.makeText(this, R.string.mensaje_solo_propietario_puede_cambiar_imagen, Toast.LENGTH_SHORT).show();
            }
        });

        baseDatos.collection("groups")
                .document(idGrupo)
                .collection("members")
                .document(auth.getCurrentUser().getUid())
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.contains("assignedTo")) {
                        botonVerAsignado.setVisibility(View.VISIBLE);
                    }
                });

        botonVerAsignado.setOnClickListener(v -> {
            Intent intent = new Intent(this, AssignedPersonActivity.class);
            intent.putExtra("groupId", idGrupo);
            startActivity(intent);
        });
        cargarInformacionGrupo();
        configurarRecyclerView();
    }

    /**
     * Selecciona una nueva imagen para el grupo
     */
    private void seleccionarNuevaImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Verifica que la selección fue exitosa y contiene una URI válida
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            nuevaImagenUri = data.getData();

            // Referencia a la ubicación donde se guardará la imagen en Firebase Storage
            StorageReference storageRef = FirebaseStorage.getInstance()
                    .getReference("group_images/" + idGrupo + ".jpg");

            // Sube la nueva imagen
            storageRef.putFile(nuevaImagenUri)
                    .addOnSuccessListener(taskSnapshot -> {
                        // Obtiene la URL de descarga una vez subida
                        storageRef.getDownloadUrl()
                                .addOnSuccessListener(uri -> {
                                    // Actualiza la URL en Firestore
                                    FirebaseFirestore.getInstance()
                                            .collection("groups")
                                            .document(idGrupo)
                                            .update("imageUrl", uri.toString())
                                            .addOnSuccessListener(unused -> {
                                                // Carga la imagen en la vista, forzando que Glide no use caché
                                                Glide.with(this)
                                                        .load(uri)
                                                        .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                                                        .skipMemoryCache(true)
                                                        .placeholder(R.drawable.ic_groups)
                                                        .error(R.drawable.ic_groups)
                                                        .into(imageGroup);

                                                Toast.makeText(this, R.string.mensaje_imagen_actualizada, Toast.LENGTH_SHORT).show();
                                            })
                                            .addOnFailureListener(e -> Toast.makeText(this, "No se pudo actualizar la imagen en Firestore", Toast.LENGTH_SHORT).show());
                                });
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error al subir la nueva imagen", Toast.LENGTH_SHORT).show();
                    });
        }
    }



    /**
     * Verifica si el grupo tiene cupo disponible y redirige a AddMemberActivity
     */
    private void verificarYAgregarMiembro() {
        baseDatos.collection("groups").document(idGrupo).collection("members")
                .get()
                .addOnSuccessListener(snapshots -> {
                    int cantidadActual = snapshots.size();
                    baseDatos.collection("groups").document(idGrupo)
                            .get()
                            .addOnSuccessListener(document -> {
                                Long maximo = document.getLong("maxParticipants");
                                if (maximo != null && cantidadActual >= maximo) {
                                    Toast.makeText(this, R.string.mensaje_grupo_completo, Toast.LENGTH_SHORT).show();
                                } else {
                                    Intent intent = new Intent(this, AddMemberActivity.class);
                                    intent.putExtra("groupId", idGrupo);
                                    startActivity(intent);
                                }
                            });
                });
    }

    /**
     * Obtiene y muestra los datos del grupo desde Firestore.
     * Además, suscribe a los cambios en la subcolección 'members'.
     */
    private void cargarInformacionGrupo() {
        baseDatos.collection("groups").document(idGrupo)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        String nombre = document.getString("name");
                        Double presupuesto = document.getDouble("budgetLimit");
                        Long maxMiembros = document.getLong("maxParticipants");
                        String imageUrl = document.getString("imageUrl");
                        ownerId = document.getString("owner");

                        textoNombreGrupo.setText(getString(R.string.text_group_name_placeholder, nombre));
                        textoPresupuestoGrupo.setText(getString(R.string.text_group_budget_placeholder, presupuesto != null ? presupuesto : 0));

                        if (imageUrl != null && !imageUrl.isEmpty()) {
                            Glide.with(this).load(imageUrl).placeholder(R.drawable.ic_groups).into(imageGroup);
                        } else {
                            imageGroup.setImageResource(R.drawable.ic_groups);
                        }

                        listenerMiembros = baseDatos.collection("groups").document(idGrupo)
                                .collection("members")
                                .addSnapshotListener((snapshots, error) -> {
                                    if (error != null || snapshots == null) return;
                                    int cantidad = snapshots.size();
                                    textoContadorGrupo.setText(getString(R.string.text_group_count_placeholder, cantidad, maxMiembros != null ? maxMiembros : 0));
                                    sePuedeAgregar = maxMiembros == null || cantidad < maxMiembros;
                                    botonAgregarMiembro.setAlpha(sePuedeAgregar ? 1f : 0.5f);
                                });
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, R.string.error_cargar_datos_grupo, Toast.LENGTH_SHORT).show());
    }

    /**
     * Configura el RecyclerView para mostrar miembros del grupo.
     */
    private void configurarRecyclerView() {
        Query consulta = baseDatos.collection("groups").document(idGrupo).collection("members");
        FirestoreRecyclerOptions<Member> opciones = new FirestoreRecyclerOptions.Builder<Member>()
                .setQuery(consulta, Member.class)
                .setLifecycleOwner(this)
                .build();

        adaptadorMiembros = new MemberAdapter(opciones, idGrupo);
        recyclerMiembros.setLayoutManager(new LinearLayoutManager(this));
        recyclerMiembros.setAdapter(adaptadorMiembros);
    }

    /**
     * Refresca el adaptador al volver a la pantalla.
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (adaptadorMiembros != null) {
            recyclerMiembros.setAdapter(null);
            adaptadorMiembros.stopListening();
            adaptadorMiembros.startListening();
            recyclerMiembros.setAdapter(adaptadorMiembros);
        }
    }

    /**
     * Activa el adaptador en el ciclo de vida.
     */
    @Override
    protected void onStart() {
        super.onStart();
        if (adaptadorMiembros != null) adaptadorMiembros.startListening();
    }

    /**
     * Detiene el adaptador y el listener en tiempo real para evitar fugas de memoria.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (adaptadorMiembros != null) adaptadorMiembros.stopListening();
        if (listenerMiembros != null) {
            listenerMiembros.remove();
            listenerMiembros = null;
        }
    }
}
