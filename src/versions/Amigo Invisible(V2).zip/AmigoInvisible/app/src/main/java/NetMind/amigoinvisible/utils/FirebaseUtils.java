package NetMind.amigoinvisible.utils;

import android.util.Log;
import androidx.annotation.Nullable;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import java.util.*;

public class FirebaseUtils {

    private static final String TAG = "FirebaseUtils";

    /**
     * Empareja automáticamente al usuario autenticado con todos los grupos en los que fue añadido por correo.
     * Evita duplicaciones, respeta el límite de participantes y actualiza el array members[] correctamente.
     */
    public static void emparejarUsuarioConGrupos(FirebaseUser usuario, @Nullable Runnable onComplete) {
        if (usuario == null || usuario.getEmail() == null) {
            if (onComplete != null) onComplete.run();
            return;
        }

        final String uid = usuario.getUid();
        final String correo = usuario.getEmail();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("groups").get().addOnSuccessListener(grupos -> {
            List<DocumentSnapshot> documentos = grupos.getDocuments();
            if (documentos.isEmpty()) {
                if (onComplete != null) onComplete.run();
                return;
            }

            final int total = documentos.size();
            final int[] procesados = {0};

            for (DocumentSnapshot grupoDoc : documentos) {
                String groupId = grupoDoc.getId();
                List<String> miembrosActuales = (List<String>) grupoDoc.get("members");
                Long maxParticipantes = grupoDoc.getLong("maxParticipants");

                if (miembrosActuales == null) miembrosActuales = new ArrayList<>();
                final List<String> miembrosFinales = new ArrayList<>(miembrosActuales);

                // Si el UID ya está en el array, solo nos aseguramos de que no falta como documento
                if (miembrosFinales.contains(uid)) {
                    Log.d("FirebaseUtils", "UID ya está en grupo " + groupId + ", se omite migración.");
                    if (++procesados[0] == total && onComplete != null) onComplete.run();
                    continue;
                }

                // Buscar por correo en subcolección "members"
                grupoDoc.getReference().collection("members")
                        .whereEqualTo("email", correo)
                        .get()
                        .addOnSuccessListener(miembrosCoincidentes -> {
                            boolean yaExiste = false;

                            for (DocumentSnapshot miembroDoc : miembrosCoincidentes.getDocuments()) {
                                String miembroId = miembroDoc.getId();

                                if (miembroId.equals(uid)) {
                                    Log.d("FirebaseUtils", "UID ya tiene doc en subcolección para grupo " + groupId);
                                    yaExiste = true;
                                    break;
                                }
                            }

                            if (yaExiste) {
                                // El documento ya existe, solo aseguramos que el UID esté en el array
                                if (!miembrosFinales.contains(uid)) {
                                    miembrosFinales.add(uid);
                                    grupoDoc.getReference().update("members", miembrosFinales);
                                    Log.d("FirebaseUtils", "UID añadido al array members[] de grupo " + groupId);
                                }
                            } else {
                                // Migrar datos desde otro doc de correo
                                for (DocumentSnapshot miembroDoc : miembrosCoincidentes.getDocuments()) {
                                    Map<String, Object> datosMiembro = miembroDoc.getData();
                                    if (datosMiembro == null) continue;

                                    grupoDoc.getReference().collection("members")
                                            .document(uid).set(datosMiembro)
                                            .addOnSuccessListener(aVoid -> {
                                                miembroDoc.getReference().delete();
                                                Log.d("FirebaseUtils", "Migrado miembro a UID " + uid);

                                                if (!miembrosFinales.contains(uid)) {
                                                    miembrosFinales.add(uid);
                                                    grupoDoc.getReference().update("members", miembrosFinales);
                                                    Log.d("FirebaseUtils", "UID añadido al array members[] de grupo " + groupId);
                                                }
                                            });
                                }
                            }

                            if (++procesados[0] == total && onComplete != null) {
                                onComplete.run();
                            }
                        })
                        .addOnFailureListener(e -> {
                            Log.e("FirebaseUtils", "Error buscando miembros en grupo " + groupId, e);
                            if (++procesados[0] == total && onComplete != null) {
                                onComplete.run();
                            }
                        });
            }
        }).addOnFailureListener(e -> {
            Log.e("FirebaseUtils", "Error accediendo a grupos", e);
            if (onComplete != null) onComplete.run();
        });
    }


    /**
     * Lleva el control del número de grupos procesados para ejecutar la acción final (onComplete)
     */
    private static void finalizarGrupo(int[] procesados, int total, @Nullable Runnable onComplete) {
        if (++procesados[0] == total && onComplete != null) {
            onComplete.run();
        }
    }
}
