package NetMind.amigoinvisible.activities;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.auth.api.identity.GetSignInIntentRequest;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.SignInCredential;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.utils.FirebaseUtils;

public class MainActivity extends AppCompatActivity {

    //private static final int REQUEST_PERMISSION_CODE = 1;
    private static final String TAG = "MainActivity";

    private FirebaseAuth autenticacionFirebase;
    private FirebaseFirestore baseDatosFirestore;

    private EditText campoCorreo, campoContrasena;

    private ActivityResultLauncher<IntentSenderRequest> lanzadorInicioGoogle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Inicialización de Firebase Auth y Firestore
        autenticacionFirebase = FirebaseAuth.getInstance();
        baseDatosFirestore = FirebaseFirestore.getInstance();

        // Referencias de los inputs
        campoCorreo = findViewById(R.id.emailInput);
        campoContrasena = findViewById(R.id.passwordInput);

        // Comprobamos si ya está logueado
        if (autenticacionFirebase.getCurrentUser() != null) {
            irAPantallaBienvenida();
        }

        // Setup de botones
        findViewById(R.id.btnLogIn).setOnClickListener(v -> iniciarSesionCorreo());
        findViewById(R.id.btnEmailSignIn).setOnClickListener(v -> iniciarSesionCorreo());
        findViewById(R.id.btnGoogleSignIn).setOnClickListener(v -> iniciarSesionGoogle());
        findViewById(R.id.txtRegistrate).setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));


        // Configuración de launcher para autenticación con Google
        lanzadorInicioGoogle = registerForActivityResult(
                new ActivityResultContracts.StartIntentSenderForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        procesarResultadoGoogle(result.getData());
                    }
                }
        );

        // Obtener el Token de FCM y mostrarlo en el log
        obtenerTokenFirebase();
    }


    /**
     * Obtiene el FCM Token del dispositivo y lo imprime en el log
     */
    private void obtenerTokenFirebase() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(tarea -> {
                    if (tarea.isSuccessful()) {
                        Log.d(TAG, "Token FCM: " + tarea.getResult());
                    } else {
                        Log.w(TAG, "Error al obtener token FCM", tarea.getException());
                    }
                });
    }

    /**
     * Inicia el flujo de autenticación con Google.
     */
    private void iniciarSesionGoogle() {
        GetSignInIntentRequest solicitudGoogle = GetSignInIntentRequest.builder()
                .setServerClientId(getString(R.string.default_web_client_id))
                .build();

        Identity.getSignInClient(this)
                .getSignInIntent(solicitudGoogle)
                .addOnSuccessListener(pendiente -> {
                    IntentSenderRequest solicitud = new IntentSenderRequest.Builder(pendiente.getIntentSender()).build();
                    lanzadorInicioGoogle.launch(solicitud);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al iniciar sesión con Google", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Inicio con Google fallido", e);
                });
    }

    /**
     * Maneja el resultado de Google SignIn.
     */
    private void procesarResultadoGoogle(Intent data) {
        try {
            SignInCredential credential = Identity.getSignInClient(this)
                    .getSignInCredentialFromIntent(data);
            String idToken = credential.getGoogleIdToken();
            if (idToken != null) {
                AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(idToken, null);
                autenticarConFirebase(firebaseCredential);
            }
        } catch (ApiException e) {
            Toast.makeText(this, "Error en autenticación con Google", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Google Sign-In error", e);
        }
    }

    /**
     * Autentica al usuario con Firebase usando el token de Google.
     */
    private void autenticarConFirebase(AuthCredential credential) {
        autenticacionFirebase.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful() && autenticacionFirebase.getCurrentUser() != null) {
                        verificarUsuario(autenticacionFirebase.getCurrentUser());
                    } else {
                        Toast.makeText(this, "Error en autenticación Firebase", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /**
     * Maneja el login con correo y contraseña (unificado).
     */
    private void iniciarSesionCorreo() {
        String correo = campoCorreo.getText().toString().trim();
        String contrasena = campoContrasena.getText().toString().trim();

        if (TextUtils.isEmpty(correo) || TextUtils.isEmpty(contrasena)) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        autenticacionFirebase.signInWithEmailAndPassword(correo, contrasena)
                .addOnSuccessListener(resultado -> {
                    FirebaseUser usuario = autenticacionFirebase.getCurrentUser();
                    if (usuario != null) {
                        verificarUsuario(usuario);
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al iniciar sesión: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Error login correo", e);
                });
    }

    /**
     * Comprueba si el usuario ya está en Firestore. Si no, lo guarda.
     */
    private void verificarUsuario(FirebaseUser usuario) {
        DocumentReference referenciaUsuario = baseDatosFirestore.collection("users").document(usuario.getUid());

        referenciaUsuario.get().addOnSuccessListener(documento -> {
            if (!documento.exists()) {
                Map<String, Object> nuevoUsuario = new HashMap<>();
                nuevoUsuario.put("nombre", usuario.getDisplayName() != null ? usuario.getDisplayName() : "");
                nuevoUsuario.put("correo", usuario.getEmail());
                nuevoUsuario.put("foto", usuario.getPhotoUrl() != null ? usuario.getPhotoUrl().toString() : "");

                referenciaUsuario.set(nuevoUsuario)
                        .addOnSuccessListener(aVoid -> Log.d(TAG, "Usuario creado"))
                        .addOnFailureListener(e -> Log.e(TAG, "Error guardando usuario", e));
            }

            // Emparejamos UID con grupos en los que estaba por correo
            FirebaseUtils.emparejarUsuarioConGrupos(usuario,() -> irAPantallaBienvenida());

        }).addOnFailureListener(e -> {
            Toast.makeText(this, getString(R.string.mensaje_error_firestore), Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Error Firestore", e);
        });
    }


    /**
     * Pasa a la pantalla principal una vez el usuario está autenticado.
     */
    private void irAPantallaBienvenida() {
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }

}
