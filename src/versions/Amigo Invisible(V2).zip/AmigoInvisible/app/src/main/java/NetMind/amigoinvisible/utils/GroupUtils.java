package NetMind.amigoinvisible.utils;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class GroupUtils {

    /**
     * Realiza el sorteo del amigo invisible.
     *
     * @param groupId ID del grupo donde se realiza el sorteo.
     * @param onSuccess Callback en caso de éxito.
     * @param onError Callback en caso de error, recibe mensaje de error.
     */
    public static void realizarSorteo(String groupId, Runnable onSuccess, java.util.function.Consumer<String> onError) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // 1. Obtener todos los miembros del grupo
        db.collection("groups").document(groupId).collection("members")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    List<DocumentSnapshot> miembros = new ArrayList<>(querySnapshot.getDocuments());

                    // Validar cantidad suficiente
                    if (miembros.size() < 2) {
                        onError.accept("Debe haber al menos 2 participantes para realizar el sorteo.");
                        return;
                    }

                    // 2. Preparar lista de asignación
                    List<String> idsDisponibles = new ArrayList<>();
                    for (DocumentSnapshot doc : miembros) {
                        idsDisponibles.add(doc.getId());
                    }

                    // 3. Mezclar y asignar asegurando que nadie se asigne a sí mismo
                    boolean sorteoValido = false;
                    int intentos = 0;
                    List<String> asignados = new ArrayList<>();

                    while (!sorteoValido && intentos < 20) {
                        Collections.shuffle(idsDisponibles);
                        sorteoValido = true;
                        asignados.clear();

                        for (int i = 0; i < miembros.size(); i++) {
                            String selfId = miembros.get(i).getId();
                            String asignadoId = idsDisponibles.get(i);
                            if (selfId.equals(asignadoId)) {
                                sorteoValido = false;
                                break;
                            }
                            asignados.add(asignadoId);
                        }
                        intentos++;
                    }

                    if (!sorteoValido) {
                        onError.accept("No se pudo completar el sorteo sin asignaciones repetidas.");
                        return;
                    }

                    // 4. Guardar asignaciones en cada miembro
                    for (int i = 0; i < miembros.size(); i++) {
                        String miembroId = miembros.get(i).getId();
                        String asignadoId = asignados.get(i);

                        DocumentReference ref = db.collection("groups").document(groupId)
                                .collection("members").document(miembroId);

                        HashMap<String, Object> actualizacion = new HashMap<>();
                        actualizacion.put("assignedTo", asignadoId);
                        ref.update(actualizacion);
                    }

                    onSuccess.run();
                })
                .addOnFailureListener(e -> onError.accept("Error al obtener los miembros: " + e.getMessage()));
    }
}
