package NetMind.amigoinvisible.services;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import NetMind.amigoinvisible.R;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "FCMService";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.d(TAG, "Mensaje recibido");

        // Verificar si hay datos en el mensaje
        if (!remoteMessage.getData().isEmpty()) {
            Log.d(TAG, "Datos: " + remoteMessage.getData());
            String title = remoteMessage.getData().get("title");
            String body = remoteMessage.getData().get("body");
            String imageUrl = remoteMessage.getData().get("image_url");

            Log.d(TAG, "Mensaje recibido: " + title + ", " + body + ", " + imageUrl);

            sendNotification(title, body, imageUrl);
        }
    }

    @Override
    public void onNewToken(@NonNull String token) {
        // Maneja el nuevo token aquí (puedes enviarlo a tu servidor si es necesario)
        Log.d(TAG, "Nuevo token: " + token);
        // Por ejemplo, puedes enviarlo a tu servidor para asociarlo con el usuario
        // sendTokenToServer(token);
    }

    @SuppressLint("MissingPermission")
    private void sendNotification(String title, String body, String imageUrl) {
        // Crear un canal de notificación si es necesario (solo para Android 8.0 y superior)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Default Channel";
            String description = "General notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("default_channel", name, importance);
            channel.setDescription(description);

            // Registrar el canal con el sistema
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        // Crear la notificación
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, "default_channel")
                .setSmallIcon(R.drawable.ic_notification)  // Icono de la notificación
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)  // La notificación se cancela cuando el usuario la toca
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        // Agregar una imagen si la hay
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Glide.with(this)
                    .asBitmap()
                    .load(imageUrl)
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            notificationBuilder.setStyle(new NotificationCompat.BigPictureStyle()
                                    .bigPicture(resource)
                                    .bigLargeIcon(resource)); // Aquí puedes pasar un ícono grande si lo necesitas
                            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(MyFirebaseMessagingService.this);
                            notificationManager.notify(0, notificationBuilder.build());
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }
                    });
        } else {
            // Si no hay imagen, solo mostramos la notificación con el título y texto
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
            notificationManager.notify(0, notificationBuilder.build());
        }
    }



}
