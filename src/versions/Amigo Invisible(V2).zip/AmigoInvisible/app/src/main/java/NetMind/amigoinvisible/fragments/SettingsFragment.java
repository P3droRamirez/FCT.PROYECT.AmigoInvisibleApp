package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.widget.Toast;
import androidx.preference.EditTextPreference;
import androidx.preference.PreferenceFragmentCompat;
import NetMind.amigoinvisible.R;

public class SettingsFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        // Carga las preferencias desde el archivo XML
        setPreferencesFromResource(R.xml.settings, rootKey);

        EditTextPreference preferenciaNombreUsuario = findPreference("username");

        if (preferenciaNombreUsuario != null) {
            preferenciaNombreUsuario.setOnPreferenceChangeListener((preference, nuevoValor) -> {
                String nuevoNombre = nuevoValor.toString();
                String mensaje = getString(R.string.nombre_usuario_actualizado, nuevoNombre);
                Toast.makeText(getContext(), mensaje, Toast.LENGTH_SHORT).show();
                return true; // Guarda el nuevo valor
            });
        }
    }
}
