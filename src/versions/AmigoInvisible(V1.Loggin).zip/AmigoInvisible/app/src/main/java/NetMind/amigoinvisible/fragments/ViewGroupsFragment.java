package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import NetMind.amigoinvisible.models.Group;
import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.viewholders.GroupViewHolder;


public class ViewGroupsFragment extends Fragment {

    private FirebaseFirestore db;
    private FirestoreRecyclerAdapter<Group, GroupViewHolder> adapter;

    public ViewGroupsFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_groups, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recyclerGroups);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        db = FirebaseFirestore.getInstance();
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        Query query = db.collection("groups").whereArrayContains("members", userId);

        FirestoreRecyclerOptions<Group> options = new FirestoreRecyclerOptions.Builder<Group>()
                .setQuery(query, Group.class)
                .setLifecycleOwner(this)
                .build();

        adapter = new FirestoreRecyclerAdapter<Group, GroupViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull GroupViewHolder holder, int position, @NonNull Group model) {
                holder.txtGroupName.setText(model.getName());
                holder.txtGroupBudget.setText("Presupuesto: €" + model.getBudgetLimit());

                holder.itemView.setOnClickListener(v -> {
                    // Abrir fragment de detalle aquí (opcional)
                });
            }

            @NonNull
            @Override
            public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_group_card, parent, false);
                return new GroupViewHolder(itemView);
            }
        };

        recyclerView.setAdapter(adapter);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
