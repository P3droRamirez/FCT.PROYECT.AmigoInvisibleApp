package NetMind.amigoinvisible.models;

public class Group {
    private String name;
    private double budgetLimit;

    public Group() {
        // Constructor vacío requerido por Firestore
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBudgetLimit() {
        return budgetLimit;
    }

    public void setBudgetLimit(double budgetLimit) {
        this.budgetLimit = budgetLimit;
    }
}
