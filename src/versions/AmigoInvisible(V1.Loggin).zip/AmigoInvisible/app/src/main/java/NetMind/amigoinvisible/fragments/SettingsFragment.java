package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.widget.Toast;

import androidx.preference.EditTextPreference;
import androidx.preference.PreferenceFragmentCompat;

import NetMind.amigoinvisible.R;

public class SettingsFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        // Carga la configuración desde settings.xml
        setPreferencesFromResource(R.xml.settings, rootKey);
        EditTextPreference usernamePref = findPreference("username");

        if (usernamePref != null) {
            usernamePref.setOnPreferenceChangeListener((preference, newValue) -> {
                String nuevoNombre = newValue.toString();
                Toast.makeText(getContext(), "Nuevo nombre: " + nuevoNombre, Toast.LENGTH_SHORT).show();
                return true; // Devuelve true para guardar el nuevo valor
            });
        }
    }
}
