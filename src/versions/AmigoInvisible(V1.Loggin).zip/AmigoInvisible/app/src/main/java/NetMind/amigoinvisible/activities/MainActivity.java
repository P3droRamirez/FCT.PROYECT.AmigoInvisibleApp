package NetMind.amigoinvisible.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.identity.GetSignInIntentRequest;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.SignInCredential;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import NetMind.amigoinvisible.R;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private EditText emailInput, passwordInput;

    private ActivityResultLauncher<IntentSenderRequest> googleSignInLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización de Firebase Auth y Firestore
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Referencias de los inputs
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);

        // Comprobamos si ya está logueado
        if (mAuth.getCurrentUser() != null) {
            goToWelcomeScreen();
        }

        // Setup de botones
        findViewById(R.id.btnLogIn).setOnClickListener(v -> loginWithEmail());
        findViewById(R.id.btnEmailSignIn).setOnClickListener(v -> loginWithEmail());
        findViewById(R.id.btnGoogleSignIn).setOnClickListener(v -> signInWithGoogle());
        findViewById(R.id.txtRegistrate).setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));


        // Configuración de launcher para autenticación con Google
        googleSignInLauncher = registerForActivityResult(
                new ActivityResultContracts.StartIntentSenderForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        handleGoogleResult(result.getData());
                    }
                }
        );
    }

    /**
     * Inicia el flujo de autenticación con Google.
     */
    private void signInWithGoogle() {
        GetSignInIntentRequest signInRequest = GetSignInIntentRequest.builder()
                .setServerClientId(getString(R.string.default_web_client_id))
                .build();

        Identity.getSignInClient(this)
                .getSignInIntent(signInRequest)
                .addOnSuccessListener(pendingIntent -> {
                    IntentSenderRequest intentSenderRequest =
                            new IntentSenderRequest.Builder(pendingIntent.getIntentSender()).build();
                    googleSignInLauncher.launch(intentSenderRequest);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al iniciar sesión con Google", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Google Sign-In failed", e);
                });
    }

    /**
     * Maneja el resultado de Google SignIn.
     */
    private void handleGoogleResult(Intent data) {
        try {
            SignInCredential credential = Identity.getSignInClient(this)
                    .getSignInCredentialFromIntent(data);
            String idToken = credential.getGoogleIdToken();
            if (idToken != null) {
                AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(idToken, null);
                authenticateWithFirebase(firebaseCredential);
            }
        } catch (ApiException e) {
            Toast.makeText(this, "Error en autenticación con Google", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Google Sign-In error", e);
        }
    }

    /**
     * Autentica al usuario con Firebase usando el token de Google.
     */
    private void authenticateWithFirebase(AuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful() && mAuth.getCurrentUser() != null) {
                        checkAndSaveUser(mAuth.getCurrentUser());
                    } else {
                        Toast.makeText(this, "Error en autenticación Firebase", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /**
     * Maneja el login con correo y contraseña (unificado).
     */
    private void loginWithEmail() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    FirebaseUser user = mAuth.getCurrentUser();
                    if (user != null) {
                        checkAndSaveUser(user);
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Inicio de sesión fallido: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Login email error", e);
                });
    }

    /**
     * Comprueba si el usuario ya está en Firestore. Si no, lo guarda.
     */
    private void checkAndSaveUser(FirebaseUser user) {
        DocumentReference userRef = db.collection("users").document(user.getUid());

        userRef.get().addOnSuccessListener(document -> {
            if (!document.exists()) {
                Map<String, Object> newUser = new HashMap<>();
                newUser.put("displayName", user.getDisplayName() != null ? user.getDisplayName() : "");
                newUser.put("email", user.getEmail());
                newUser.put("photoUrl", user.getPhotoUrl() != null ? user.getPhotoUrl().toString() : "");

                userRef.set(newUser)
                        .addOnSuccessListener(aVoid -> Log.d(TAG, "Usuario creado en Firestore"))
                        .addOnFailureListener(e -> Log.e(TAG, "Error al guardar usuario", e));
            }
            goToWelcomeScreen();
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Error al comprobar usuario", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Firestore get user error", e);
        });
    }

    /**
     * Pasa a la pantalla principal una vez el usuario está autenticado.
     */
    private void goToWelcomeScreen() {
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }
}
