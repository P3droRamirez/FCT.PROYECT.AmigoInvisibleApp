package NetMind.amigoinvisible.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.fragments.CreateGroupFragment;
import NetMind.amigoinvisible.fragments.MyGroupsFragment;
import NetMind.amigoinvisible.fragments.SettingsFragment;
import NetMind.amigoinvisible.fragments.ViewGroupsFragment;

public class WelcomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private FirebaseFirestore db;
    private StorageReference storageRef;

    private TextView welcomeText;
    private ImageView profileImage;

    private ActivityResultLauncher<String> imagePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        db = FirebaseFirestore.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference("profile_pictures");

        // Configurar Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        // Configuración del Drawer y NavigationView
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Header del menú lateral
        View headerView = navigationView.getHeaderView(0);
        welcomeText = headerView.findViewById(R.id.nav_header_name);
        TextView emailText = headerView.findViewById(R.id.nav_header_email);
        profileImage = headerView.findViewById(R.id.profile_image);

        // Mostrar info del usuario logueado
        if (currentUser != null) {
            String name = currentUser.getDisplayName() != null ? currentUser.getDisplayName() : "Usuario";
            welcomeText.setText("Bienvenido, " + name);
            emailText.setText(currentUser.getEmail());

            if (currentUser.getPhotoUrl() != null) {
                Glide.with(this)
                        .load(currentUser.getPhotoUrl())
                        .circleCrop()
                        .into(profileImage);
            }
        }

        // Fragment inicial
        if (savedInstanceState == null) {
            loadFragment(new ViewGroupsFragment());
            navigationView.setCheckedItem(R.id.nav_home);
        }

        // Abrir Drawer con botón hamburguesa
        toolbar.setNavigationOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        // Configurar selector de imágenes
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                this::uploadImageToFirebase
        );

        // Subir imagen de perfil al hacer click
        profileImage.setOnClickListener(v -> {
            Toast.makeText(this, "Selecciona una imagen de perfil", Toast.LENGTH_SHORT).show();
            imagePickerLauncher.launch("image/*");
        });
    }

    /**
     * Reemplaza el fragmento actual con uno nuevo.
     */
    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    /**
     * Maneja la selección del menú lateral.
     */
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            loadFragment(new ViewGroupsFragment());
        } else if (id == R.id.nav_create_group) {
            loadFragment(new CreateGroupFragment());
        } else if (id == R.id.nav_my_groups) {
            loadFragment(new MyGroupsFragment());
        } else if (id == R.id.nav_settings) {
            loadFragment(new SettingsFragment());
        } else if (id == R.id.nav_logout) {
            mAuth.signOut();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return true;
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    /**
     * Sube la imagen al storage, actualiza el perfil y la base de datos.
     */
    private void uploadImageToFirebase(Uri imageUri) {
        if (imageUri == null || currentUser == null) return;

        StorageReference fileRef = storageRef.child(currentUser.getUid() + "/profile.jpg");

        fileRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> fileRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    // Actualizar Firebase Auth
                    UserProfileChangeRequest updates = new UserProfileChangeRequest.Builder()
                            .setPhotoUri(uri)
                            .build();

                    currentUser.updateProfile(updates)
                            .addOnSuccessListener(unused -> {
                                Glide.with(this)
                                        .load(uri)
                                        .circleCrop()
                                        .into(profileImage);
                                Toast.makeText(this, "Foto actualizada", Toast.LENGTH_SHORT).show();

                                // Guardar URL en Firestore
                                Map<String, Object> update = new HashMap<>();
                                update.put("photoUrl", uri.toString());

                                db.collection("users").document(currentUser.getUid())
                                        .update(update);
                            });
                }))
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error al subir la imagen: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
