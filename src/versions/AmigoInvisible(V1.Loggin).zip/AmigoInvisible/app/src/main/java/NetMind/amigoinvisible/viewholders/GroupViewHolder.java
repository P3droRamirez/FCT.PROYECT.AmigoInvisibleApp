package NetMind.amigoinvisible.viewholders;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import NetMind.amigoinvisible.R;
import NetMind.amigoinvisible.models.Group;

public class GroupViewHolder extends RecyclerView.ViewHolder {

    public TextView txtGroupName, txtGroupBudget;

    public GroupViewHolder(@NonNull View itemView) {
        super(itemView);
        txtGroupName = itemView.findViewById(R.id.txtGroupName);
        txtGroupBudget = itemView.findViewById(R.id.txtGroupBudget);
    }

    public void bind(Group group) {
        txtGroupName.setText(group.getName());
        txtGroupBudget.setText("Presupuesto: €" + group.getBudgetLimit());
    }
}
