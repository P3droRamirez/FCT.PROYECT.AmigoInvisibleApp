package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import NetMind.amigoinvisible.R;

import java.util.HashMap;
import java.util.Map;

public class CreateGroupFragment extends Fragment {

    private EditText groupNameInput, maxParticipantsInput, budgetLimitInput;
    private FirebaseFirestore db;
    private FirebaseAuth auth;

    public CreateGroupFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_create_group, container, false);

        groupNameInput = view.findViewById(R.id.editTextGroupName);
        maxParticipantsInput = view.findViewById(R.id.editTextMaxParticipants);
        budgetLimitInput = view.findViewById(R.id.editTextBudgetLimit);
        MaterialButton createGroupButton = view.findViewById(R.id.btnFinishGroup);

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        createGroupButton.setOnClickListener(v -> {
            String name = groupNameInput.getText().toString().trim();
            String maxParticipantsStr = maxParticipantsInput.getText().toString().trim();
            String budgetStr = budgetLimitInput.getText().toString().trim();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(maxParticipantsStr) || TextUtils.isEmpty(budgetStr)) {
                Toast.makeText(getContext(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                return;
            }

            int maxParticipants;
            double budget;
            try {
                maxParticipants = Integer.parseInt(maxParticipantsStr);
                budget = Double.parseDouble(budgetStr);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Valores numéricos no válidos", Toast.LENGTH_SHORT).show();
                return;
            }

            String userId = auth.getCurrentUser().getUid();

            Map<String, Object> group = new HashMap<>();
            group.put("name", name);
            group.put("owner", userId);
            group.put("maxParticipants", maxParticipants);
            group.put("budgetLimit", budget);
            group.put("members", java.util.Collections.singletonList(userId));
            group.put("wishlist", new java.util.ArrayList<>());

            db.collection("groups").add(group)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(getContext(), "Grupo creado correctamente", Toast.LENGTH_SHORT).show();
                        requireActivity().getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_container, new ViewGroupsFragment())
                                .commit();

                    })
                    .addOnFailureListener(e -> Toast.makeText(getContext(), "Error al crear grupo", Toast.LENGTH_SHORT).show());
        });

        return view;
    }
}
