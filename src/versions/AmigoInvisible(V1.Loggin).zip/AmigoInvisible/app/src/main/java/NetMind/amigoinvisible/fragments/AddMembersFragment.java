package NetMind.amigoinvisible.fragments;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import NetMind.amigoinvisible.R;

public class AddMembersFragment extends Fragment {

    private static final String ARG_GROUP_ID = "group_id";
    private String groupId;

    private EditText nameInput, emailInput, wishlistInput;
    private FirebaseFirestore db;

    public static AddMembersFragment newInstance(String groupId) {
        AddMembersFragment fragment = new AddMembersFragment();
        Bundle args = new Bundle();
        args.putString(ARG_GROUP_ID, groupId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            groupId = getArguments().getString(ARG_GROUP_ID);
        }
        db = FirebaseFirestore.getInstance();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add_members, container, false);

        nameInput = view.findViewById(R.id.editTextMemberName);
        emailInput = view.findViewById(R.id.editTextMemberEmail);
        wishlistInput = view.findViewById(R.id.editTextWishlist);

        Button btnAddMember = view.findViewById(R.id.btnAddMember);
        Button btnFinish = view.findViewById(R.id.btnFinishGroup);

        btnAddMember.setOnClickListener(v -> addMemberToGroup());
        btnFinish.setOnClickListener(v -> requireActivity().onBackPressed());

        return view;
    }

    private void addMemberToGroup() {
        String name = nameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String wishlistRaw = wishlistInput.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email)) {
            Toast.makeText(getContext(), "Nombre y correo son obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> wishlist = wishlistRaw.isEmpty()
                ? List.of()
                : Arrays.asList(wishlistRaw.split("\\s*,\\s*"));  // Separar por comas

        Map<String, Object> memberData = new HashMap<>();
        memberData.put("name", name);
        memberData.put("email", email);
        memberData.put("wishlist", wishlist);

        db.collection("groups")
                .document(groupId)
                .collection("members")
                .add(memberData)
                .addOnSuccessListener(docRef -> {
                    Toast.makeText(getContext(), "Participante añadido", Toast.LENGTH_SHORT).show();
                    clearFields();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void clearFields() {
        nameInput.setText("");
        emailInput.setText("");
        wishlistInput.setText("");
    }
}
